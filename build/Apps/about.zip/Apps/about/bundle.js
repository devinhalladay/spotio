(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
module.exports = {
  "love_music": "Wir lieben Musik",
  "content_provided": "Inhalte bereitgestellt von",
  "copyright": "Copyright © {0} Spotify AB.<br/>Spotify® ist ein eingetragenes Warenzeichen der Spotify Group.",
  "upgrade.downloading": "Eine neue Version von Spotify wird heruntergeladen ...",
  "upgrade.downloaded": "Spotify wurde auf die Version aktualisiert. Bitte führe einen Neustart zur Installation aus.",
  "upgrade.pending": "Eine neue Version von Spotify ist verfügbar ({0}). {1}",
  "upgrade.pending_link": "Zum Herunterladen hier klicken."
};
},{}],2:[function(require,module,exports){
module.exports = {
  "love_music": "Λατρεύουμε τη μουσική",
  "content_provided": "Το περιεχόμενο παρέχεται από:",
  "copyright": "Copyright © {0} Spotify AB.<br/>Το Spotify® είναι σήμα κατατεθέν του ομίλου Spotify.",
  "upgrade.downloading": "Γίνεται λήψη νέας έκδοσης του Spotify...",
  "upgrade.downloaded": "Το Spotify ενημερώθηκε στην έκδοση {0}. Επανεκκίνησε για να γίνει η εγκατάσταση.",
  "upgrade.pending": "Μια νέα έκδοση του Spotify είναι διαθέσιμη ({0}). {1}",
  "upgrade.pending_link": "Κάνε κλικ εδώ για λήψη"
};
},{}],3:[function(require,module,exports){
module.exports = {
  "love_music": "We love music",
  "content_provided": "Content provided by",
  "copyright": "Copyright &copy; {0} Spotify AB.<br/>Spotify® is a registered trademark of the Spotify Group.",
  "upgrade.downloading": "Downloading a new version of Spotify...",
  "upgrade.downloaded": "Spotify has been updated to version {0}. Please restart to install.",
  "upgrade.pending": "A new version of Spotify is available ({0}). {1}",
  "upgrade.pending_link": "Click here to download"
};
},{}],4:[function(require,module,exports){
module.exports = {
  "love_music": "Nos encanta la música",
  "content_provided": "Contenido proporcionado por",
  "copyright": "Derechos de autor © {0} Spotify AB.<br>Spotify® es una marca comercial registrada de Spotify Group.",
  "upgrade.downloading": "Descargando una nueva versión de Spotify…",
  "upgrade.downloaded": "Spotify se ha actualizado a la versión {0}. Reinicia para instalarla.",
  "upgrade.pending": "Está disponible una nueva versión de Spotify ({0}). {1}",
  "upgrade.pending_link": "Haz clic aquí para descargarla"
};
},{}],5:[function(require,module,exports){
module.exports = {
  "love_music": "Nos encanta la música",
  "content_provided": "Contenido ofrecido por",
  "copyright": "Copyright © {0} Spotify AB.<br/>Spotify® es una marca comercial registrada del Grupo Spotify.",
  "upgrade.downloading": "Descargando una versión nueva de Spotify...",
  "upgrade.downloaded": "Spotify se ha actualizado a la versión {0}. Por favor, reinicia para instalar.",
  "upgrade.pending": "Hay disponible una versión nueva de Spotify ({0}). {1}",
  "upgrade.pending_link": "Haz click aquí para descargar"
};
},{}],6:[function(require,module,exports){
module.exports = {
  "love_music": "Rakastamme musiikkia",
  "content_provided": "Sisällön tarjoaa",
  "copyright": "Copyright © {0} Spotify AB.<br/>Spotify® on Spotify Groupin rekisteröity tavaramerkki.",
  "upgrade.downloading": "Ladataan Spotifyn uutta versiota...",
  "upgrade.downloaded": "Spotify on päivitetty versioon {0}. Asenna uusi versio käynnistämällä Spotify uudelleen.",
  "upgrade.pending": "Uusi Spotify-versio ({0}) on saatavilla. {1}",
  "upgrade.pending_link": "Lataa napsauttamalla tätä"
};
},{}],7:[function(require,module,exports){
module.exports = {
  "love_music": "La musique est notre passion",
  "content_provided": "Contenu offert par",
  "copyright": "© Spotify AB, {0}.<br/>SpotifyMD est une marque déposée de Spotify Group.",
  "upgrade.downloading": "Téléchargement d'une nouvelle version de Spotify...",
  "upgrade.downloaded": "Mise à jour de Spotify vers la version {0}. Veuillez redémarrer pour l'installer.",
  "upgrade.pending": "Une nouvelle version de Spotify est disponible ({0}). {1}",
  "upgrade.pending_link": "Cliquez ici pour la télécharger"
};
},{}],8:[function(require,module,exports){
module.exports = {
  "love_music": "Nous adorons la musique.",
  "content_provided": "Contenu fourni par",
  "copyright": "Copyright © {0} Spotify AB.<br>Spotify® est une marque déposée du groupe Spotify.",
  "upgrade.downloading": "Téléchargement de la nouvelle version de Spotify...",
  "upgrade.downloaded": "Spotify a été remplacé par la version mise à jour {0}. Redémarrez pour l'installer.",
  "upgrade.pending": "Une nouvelle version de Spotify est disponible ({0}). {1}",
  "upgrade.pending_link": "Cliquez ici pour télécharger."
};
},{}],9:[function(require,module,exports){
module.exports = {
  "love_music": "Imádjuk a zenét",
  "content_provided": "Tartalomszolgáltató:",
  "copyright": "Copyright © {0} Spotify AB.<br/>A Spotify® a Spotify Group bejegyzett védjegye.",
  "upgrade.downloading": "A Spotify újabb verziójának letöltése folyamatban...",
  "upgrade.downloaded": "Letöltődött a Spotify újabb, {0} jelű verziója. A telepítéshez indítsd újra a Spotifyt.",
  "upgrade.pending": "Megjelent a Spotify újabb, {0} jelű verziója. {1}",
  "upgrade.pending_link": "Kattints ide a letöltéshez"
};
},{}],10:[function(require,module,exports){
module.exports = {
  "love_music": "Kami suka musik",
  "content_provided": "Konten disediakan oleh",
  "copyright": "Hak cipta © {0} Spotify AB.<br/>Spotify® adalah merek dagang terdaftar dari Spotify Group.",
  "upgrade.downloading": "Men-download versi baru Spotify...",
  "upgrade.downloaded": "Spotify telah ditingkatkan ke versi {0}. Mulai ulang untuk menginstal.",
  "upgrade.pending": "Versi baru Spotify tersedia ({0}). {1}",
  "upgrade.pending_link": "Klik di sini untuk men-download"
};
},{}],11:[function(require,module,exports){
'use strict';

// This file will likely become a generated file in the future. Please
// avoid adding extra APIs or exports here.

var i18n = require('../../../libs/spotify-i18n')({
  'de': require('./de.lang'),
  'el': require('./el.lang'),
  'en': require('./en.lang'),
  'es': require('./es.lang'),
  'es-419': require('./es-419.lang'),
  'fi': require('./fi.lang'),
  'fr': require('./fr.lang'),
  'fr-CA': require('./fr-CA.lang'),
  'hu': require('./hu.lang'),
  'id': require('./id.lang'),
  'it': require('./it.lang'),
  'ja': require('./ja.lang'),
  'nl': require('./nl.lang'),
  'pl': require('./pl.lang'),
  'pt-BR': require('./pt-BR.lang'),
  'sv': require('./sv.lang'),
  'tr': require('./tr.lang'),
  'zh-Hant': require('./zh-Hant.lang'),
  'zsm': require('./zsm.lang')
});

module.exports = i18n;

},{"../../../libs/spotify-i18n":62,"./de.lang":1,"./el.lang":2,"./en.lang":3,"./es-419.lang":4,"./es.lang":5,"./fi.lang":6,"./fr-CA.lang":7,"./fr.lang":8,"./hu.lang":9,"./id.lang":10,"./it.lang":12,"./ja.lang":13,"./nl.lang":14,"./pl.lang":15,"./pt-BR.lang":16,"./sv.lang":17,"./tr.lang":18,"./zh-Hant.lang":19,"./zsm.lang":20}],12:[function(require,module,exports){
module.exports = {
  "love_music": "Amiamo la musica",
  "content_provided": "Contenuti forniti da",
  "copyright": "Copyright © {0} Spotify AB.<br/>Spotify® è un marchio registrato di Spotify Group.",
  "upgrade.downloading": "Download della nuova versione di Spotify in corso...",
  "upgrade.downloaded": "Spotify è stato aggiornato alla versione {0}. Riavvia per installare.",
  "upgrade.pending": "È disponibile una nuova versione di Spotify ({0}). {1}",
  "upgrade.pending_link": "Clicca qui per scaricarla"
};
},{}],13:[function(require,module,exports){
module.exports = {
  "love_music": "We love music",
  "content_provided": "コンテンツ提供:",
  "copyright": "Copyright © {0} Spotify AB.<br/>Spotify®はSpotifyグループの登録商標です。",
  "upgrade.downloading": "Spotifyの新しいバージョンをダウンロードしています...",
  "upgrade.downloaded": "Spotifyがバージョン{0}に更新されました。再起動してインストールしてください。",
  "upgrade.pending": "Spotifyの新しいバージョンが利用可能です({0})。{1}",
  "upgrade.pending_link": "こちらをクリックしてダウンロードしてください"
};
},{}],14:[function(require,module,exports){
module.exports = {
  "love_music": "Wij houden van muziek.",
  "content_provided": "Inhoud aangeboden door",
  "copyright": "Copyright © {0} Spotify AB.<br/>Spotify® is een geregistreerd handelsmerk van de Spotify Group.",
  "upgrade.downloading": "Een nieuwe versie van Spotify aan het downloaden...",
  "upgrade.downloaded": "Spotify is bijgewerkt naar de nieuwste versie {0}. Start opnieuw op om deze te installeren.",
  "upgrade.pending": "Een nieuwe versie ({0}) van Spotify is nu beschikbaar. {1}",
  "upgrade.pending_link": "Klik hier om te downloaden."
};
},{}],15:[function(require,module,exports){
module.exports = {
  "love_music": "Kochamy muzykę",
  "content_provided": "Zawartość przesłana przez",
  "copyright": "Copyright © {0} Spotify AB.<br/>Spotify® jest zastrzeżonym znakiem towarowym Spotify Group.",
  "upgrade.downloading": "Pobieranie nowej wersji Spotify...",
  "upgrade.downloaded": "Aplikacja Spotify została zaktualizowana do wersji {0}. Uruchom aplikację ponownie, aby zainstalować aktualizację.",
  "upgrade.pending": "Nowa wersja aplikacji Spotify jest już dostępna ({0}). {1}",
  "upgrade.pending_link": "Kliknij tutaj, aby ją pobrać"
};
},{}],16:[function(require,module,exports){
module.exports = {
  "love_music": "A música é nossa paixão",
  "content_provided": "Conteúdo fornecido por",
  "copyright": "Copyright © {0} Spotify AB.<br/>Spotify® é uma marca registrada do Spotify Group.",
  "upgrade.downloading": "Baixando uma nova versão do Spotify...",
  "upgrade.downloaded": "O Spotify foi atualizado para a versão {0}. Reinicie para instalar.",
  "upgrade.pending": "Há uma nova versão do Spotify disponível ({0}). {1}",
  "upgrade.pending_link": "Clique aqui para baixar"
};
},{}],17:[function(require,module,exports){
module.exports = {
  "love_music": "Vi älskar musik",
  "content_provided": "Innehållet tillhandahålls av",
  "copyright": "Copyright © {0} Spotify AB.<br/>Spotify® är ett registrerat varumärke som tillhör Spotify Group.",
  "upgrade.downloading": "Hämtar en ny version av Spotify …",
  "upgrade.downloaded": "Spotify har uppdaterats till version {0}. Starta om för att installera.",
  "upgrade.pending": "En ny version av Spotify är tillgänglig ({0}). {1}",
  "upgrade.pending_link": "Klicka här för att ladda ned"
};
},{}],18:[function(require,module,exports){
module.exports = {
  "love_music": "Müziği çok seviyoruz",
  "content_provided": "İçerikleri sağlayan:",
  "copyright": "Copyright © {0} Spotify AB.<br>Spotify®, Spotify Group'un kayıtlı ticari markasıdır.",
  "upgrade.downloading": "Spotify'ın yeni sürümü indiriliyor...",
  "upgrade.downloaded": "Spotify yeni sürüm {0} ile güncellendi. Yüklemek için lütfen yeniden başlat.",
  "upgrade.pending": "Spotify'ın yeni sürümü mevcut ({0}). {1}",
  "upgrade.pending_link": "İndirmek için buraya tıkla"
};
},{}],19:[function(require,module,exports){
module.exports = {
  "love_music": "我們熱愛音樂",
  "content_provided": " 內容由以下唱片公司提供：",
  "copyright": "Copyright © {0} Spotify AB.<br/>Spotify® 是 Spotify 集團的註冊商標。",
  "upgrade.downloading": "下載新版 Spotify 中…",
  "upgrade.downloaded": "Spotify 已更新至版本 {0}。請重新啟動以完成安裝。",
  "upgrade.pending": "Spotify 最新的版本 ({0}) 已推出。{1}",
  "upgrade.pending_link": "按一下這裡下載"
};
},{}],20:[function(require,module,exports){
module.exports = {
  "love_music": "Kami mengemari muzik",
  "content_provided": "Kandungan disediakan oleh",
  "copyright": "Hak cipta © {0} Spotify AB.<br/>Spotify® ialah tanda dagangan berdaftar bagi Spotify Group.",
  "upgrade.downloading": "Muat turun versi baru Spotify...",
  "upgrade.downloaded": "Spotify telah dikemas kini kepada versi {0}. Sila mulakan semula untuk memasang.",
  "upgrade.pending": "Versi baharu Spotify kini tersedia ({0}). {1}",
  "upgrade.pending_link": "Klik di sini untuk memuat turun"
};
},{}],21:[function(require,module,exports){
'use strict';

var i18n = require('../i18n');

function translate() {
  var items = [].slice.apply(document.querySelectorAll('[data-i18n]'));

  items.forEach(function (item) {
    item.innerHTML = i18n.get(item.getAttribute('data-i18n'));
  });
}

/**
 * Export public interface
 */
module.exports = translate;

},{"../i18n":11}],22:[function(require,module,exports){
'use strict';

var cosmos = require('spotify-cosmos-api');

var CLIPBOARD_ENDPOINT = 'sp://desktop/v1/clipboard';
var CONTAINER_CONTROL_ENDPOINT = 'sp://messages/v1/container/control';

/**
 * This method is used to set up selection and copying of text using keyboard
 * shortcuts. It's needed as these actions don't work out of the box within the
 * Zelda client.
 */
exports.setUpForElement = function (element) {
  var callback = function callback(error, response) {
    if (error) {
      return;
    }

    var body = response.getJSONBody();

    if (!body) {
      return;
    }

    if (body.type === 'copy') {
      var text = window.getSelection().toString();
      var request = new cosmos.Request('PUT', CLIPBOARD_ENDPOINT, null, text);

      cosmos.resolver.resolve(request);
    } else if (body.type === 'select_all') {
      var range = document.createRange();
      var selection = window.getSelection();

      range.selectNodeContents(element);
      selection.removeAllRanges();
      selection.addRange(range);
    }
  };

  cosmos.resolver.subscribe(CONTAINER_CONTROL_ENDPOINT, callback);
};

},{"spotify-cosmos-api":112}],23:[function(require,module,exports){
'use strict';

// Set up body scroll bar

var scrollbarEvents = require('../../../libs/spotify-events/scrollbar');
scrollbarEvents.attach();
scrollbarEvents.update();

// translate the html
require('./i18n')();

var showUpgradeStatus = require('./upgrade');

// Initialize locale.
require('../../../libs/spotify-handlebars/helpers/numeral').setLocale(window.__spotify.locale);

// Set copyright year
var i18n = require('../i18n');
var copyright = document.getElementById('copyright');
// Year should probably be set project-wide or be generated at compile time
copyright.innerHTML = i18n.get('copyright', 2016);

if (window.__spotify && window.__spotify.client === 'zelda') {
  // Show current version
  var versionString = window.__spotify.client_version || '';
  var element = document.getElementById('version');

  element.innerHTML = versionString;

  require('./keyboard-shortcut-handler.js').setUpForElement(element);

  // Show upgrade status
  showUpgradeStatus();
}

require('../../../libs/spotify-expose-dev-mode-debug-globals/bridge').init();
require('../../../libs/spotify-expose-dev-mode-debug-globals/cosmos').init();

},{"../../../libs/spotify-events/scrollbar":32,"../../../libs/spotify-expose-dev-mode-debug-globals/bridge":35,"../../../libs/spotify-expose-dev-mode-debug-globals/cosmos":36,"../../../libs/spotify-handlebars/helpers/numeral":61,"../i18n":11,"./i18n":21,"./keyboard-shortcut-handler.js":22,"./upgrade":24}],24:[function(require,module,exports){
'use strict';

var cosmos = require('spotify-cosmos-api');

var i18n = require('../i18n');

var upgradeDownloading = document.getElementById('upgrade-downloading');
var upgradeDownloaded = document.getElementById('upgrade-downloaded');
var upgradePending = document.getElementById('upgrade-pending');

upgradeDownloading.innerHTML = i18n.get('upgrade.downloading');
upgradeDownloaded.innerHTML = i18n.get('upgrade.downloaded', '<span id="downloaded-version"></span>');
upgradePending.innerHTML = i18n.get('upgrade.pending', '<span id="pending-version"></span>', '<a id="download-pending-version" href="#">' + i18n.get('upgrade.pending_link') + '</a>');

var showUpgradeStatus = function showUpgradeStatus() {
  addUpgradeLinkHandler();

  // The act of subscribing will return a snapshot immediately, so there's no
  // need to do a GET first.
  cosmos.resolver.subscribe('sp://desktop/v1/upgrade/status', function (error, response) {
    if (error) throw error;

    var data = response.getJSONBody();

    // Mock response data for testing
    /*
    data = {
      "pending": {
        "version": '1.2.3',
        "time_until_download": 123456789
      }
    };
    data = {
      "prepared": {
        "version": '2.3.4',
        "time_since_ready": 987654321
      }
    };
    */

    hideAllMessages();
    if (data.pending && data.pending.version) {
      showPendingMessage(data.pending);
    } else if (data.prepared && data.prepared.version) {
      showDownloadedMessage(data.prepared);
    }
  });
};

var hideAllMessages = function hideAllMessages() {
  upgradePending.className = '';
  upgradeDownloading.className = '';
  upgradeDownloaded.className = '';
};

var showPendingMessage = function showPendingMessage(status) {
  upgradePending.className = 'visible';
  document.getElementById('pending-version').innerHTML = status.version;
  console.log('New Spotify version pending:', status);
};

var showDownloadedMessage = function showDownloadedMessage(status) {
  upgradeDownloaded.className = 'visible';
  document.getElementById('downloaded-version').innerHTML = status.version;
  console.log('New Spotify version downloaded:', status);
};

var showDownloadingMessage = function showDownloadingMessage() {
  upgradeDownloading.className = 'visible';
};

var addUpgradeLinkHandler = function addUpgradeLinkHandler() {
  document.getElementById('download-pending-version').addEventListener('click', function (e) {
    e.preventDefault();

    cosmos.resolver.post('sp://desktop/v1/upgrade/download', function (error) {
      if (error) throw error;

      hideAllMessages();
      showDownloadingMessage();
    });
  });
};

module.exports = showUpgradeStatus;

},{"../i18n":11,"spotify-cosmos-api":112}],25:[function(require,module,exports){
'use strict';

// Base function that doesn't have any dependencies on it's own. Expects to get
// state (a plain, empty object) injected in addition to a bridge request
// function.
function cosmosRequest(state, bridge, opts, callback) {

  if (typeof opts.uri !== 'string') throw new Error('Expected uri to be string.');

  if (COSMOS_VERBS.indexOf(opts.method) === -1) throw new Error('Method must match valid verb in uppercase (GET, POST etc)');

  if (opts.body && typeof opts.body !== 'string') throw new Error('If body is provided it should be a string.');

  if (opts.headers && Object.prototype.toString.call(opts.headers) !== '[object Object]') throw new Error('Expected headers be a plain object.');

  var cosmosOptions = {
    action: opts.method,
    uri: opts.uri
  };
  if (opts.body) cosmosOptions.body = opts.body;
  if (opts.headers) cosmosOptions.headers = opts.headers;

  /* Cosmos requires each request to have a unique ID. Ideally, this would be
  uuids, but unfortunately, it is integers. This means that in apps that for
  some reason need to use spotify-cosmos-api, there would between the two
  counters if cosmosRequest started from 0. To make it safe for the two
  implemenations to co-exist if needed, we begin counting at
  significantly higher number: */
  state.requestIDCounter = state.requestIDCounter || TEN_PER_SECOND_FOR_A_YEAR;
  state.requestIDCounter++;

  var requestArguments = [state.requestIDCounter, cosmosOptions];

  var isCanceled = false;
  var stateRequestIDCounter = state.requestIDCounter;

  function cancelFunction() {
    isCanceled = true;
    bridge('cosmos_request_cancel', [stateRequestIDCounter]);
  }

  // run is a recursive function that does a bridge request and then keeps
  // pulling values after every response in the case of a subscription. In
  // case we are not subscribing, or the cancelFunction has been called,
  // run sends cosmos_request_cancel and terminates.
  function run(isFirst, requestIDCounter) {
    var messageName = isFirst ? 'cosmos_request_create' : 'cosmos_request_pull';
    bridge(messageName, requestArguments, function (error, responseString) {
      // The request to cancel may not have gotten to the bridge
      // before the original request got resolved,
      // so make sure not to continue if we detect it's been canceled.
      if (isCanceled) {
        return;
      }
      try {
        if (callback) {
          if (error) {
            callback(error);
          } else {
            callback(null, responseString);
          }
        }
      } finally {
        if (opts.method !== 'SUB') {
          // If the request was a non-SUB, tell core to clean up the request.
          // NOTE: Not sure if this is strictly necessary,
          // have not been to investigate in C++-land, so for now
          // we are just mimicing the behavior of spotify-cosmos-api.
          bridge('cosmos_request_cancel', [requestIDCounter]);
        } else if (!isCanceled) {
          // maybe canceled in above callback
          run(false, requestIDCounter);
        }
      }
    });
  }

  run(true, stateRequestIDCounter);

  return cancelFunction;
}

var TEN_PER_SECOND_FOR_A_YEAR = 10 * 60 * 60 * 24 * 365;

var COSMOS_VERBS = ['GET', 'HEAD', 'POST', 'PUT', 'SUB', 'PATCH', 'DELETE'];

module.exports = cosmosRequest;

},{}],26:[function(require,module,exports){
(function (global){
'use strict';

var debug = require('debug')('spotify-bridge-request');
var defer = require('spotify-deferred');

var cosmosBaseFunction = require('./cosmos');

// NOTE: Implicit global state.
var scheduledCoreFlush = false;
var cosmosState = null;

exports.cosmos = cosmos;
exports.cosmosJSON = cosmosJSON;
exports.request = request;
exports._request = _request;

function cosmos() {
  if (!cosmosState) cosmosState = {};

  var baseArguments = [cosmosState, request];
  var cancelFunction = cosmosBaseFunction.apply(null, baseArguments.concat(Array.prototype.slice.call(arguments)));
  return cancelFunction;
}

function _createCallbackWrapper(callback) {
  return function callbackWrapper(err, response) {
    if (!err) {
      var parsedResponse;
      try {
        parsedResponse = JSON.parse(response.body);
      } catch (e) {
        e.message = 'Failed to parse cosmos response: ' + e.message;
        callback(e);
        return;
      }
      callback(null, parsedResponse);
    } else {
      callback(err, response);
    }
  };
}

function cosmosJSON(opts, callback) {
  if (opts.body) {
    opts.body = JSON.stringify(opts.body);
  }
  var callbackWrapper = callback ? _createCallbackWrapper(callback) : null;
  var cancelFunction = cosmos(opts, callbackWrapper);
  return cancelFunction;
}

function request(name, opt_args, opt_callback) {
  var args = opt_args || [];
  var callback = getCallback(name, args, opt_callback);

  debug('req:' + name, args);

  exports._request(name, args, callback);

  if (name !== 'core_flush' && !scheduledCoreFlush) {
    scheduledCoreFlush = true;
    defer(flushCore);
  }

  return exports;
}

function _request(name, args, callback) {
  if (global && typeof global._getSpotifyModule === 'function') {
    global._getSpotifyModule('bridge').executeRequest(JSON.stringify({
      name: name,
      args: args
    }), {
      onSuccess: getSuccessHandler(callback),
      onFailure: getFailureHandler(callback, name, args)
    });
  }
}

function getCallback(name, args, opt_userCallback) {
  var userCallback = opt_userCallback || function () {};

  return function (error, data) {
    if (error) {
      if (error.name === 'timeout') {
        // Set the delay between 300ms and 400ms
        var delay = 300 + Math.floor(Math.random() * 100);

        debug('timeout', error.message);

        // Retry the request
        setTimeout(function () {
          request(name, args, userCallback);
        }, delay);
        return;
      }
    }

    debug('res:' + name, args, data);

    userCallback(error, data);
  };
}

function getSuccessHandler(requestCallback) {
  return function (data) {
    var parsed;

    debug('success', data);

    try {
      parsed = JSON.parse(data);
    } catch (error) {
      requestCallback(error);
    }

    if (parsed) {
      requestCallback(null, parsed);
    }
  };
}

function getFailureHandler(requestCallback, name, args) {
  return function (data) {
    var parsed;

    debug('failure', data);

    try {
      parsed = JSON.parse(data);
    } catch (error) {
      requestCallback(error);
    }

    if (parsed) {
      requestCallback(createError(name, args, parsed));
    }
  };
}

function createError(name, args, response) {
  var argsString = JSON.stringify(args);
  var debug = ' (bridge message: \'' + name + '\', args: ' + argsString + ')';
  var msg = response.message + debug;
  var error = new Error(msg);
  error.name = response.error;

  return error;
}

function flushCore() {
  scheduledCoreFlush = false;
  request('core_flush');
}

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"./cosmos":25,"debug":89,"spotify-deferred":115}],27:[function(require,module,exports){
/*
Event Center
*/'use strict';

var Emitter = require('prime/emitter');

module.exports = new Emitter();

},{"prime/emitter":104}],28:[function(require,module,exports){
'use strict';

/**
 * Module for handling clicks on the scroll bar track to scroll pages.
 *
 * @private
 */

var BezierEasing = require('bezier-easing');

var config = require('./config');

module.exports = {

  // Called from outside
  setHandler: function setHandler(eventName, scroller, handler) {
    if (eventName === 'clickEnd') {
      scroller._clickEndHandler = handler;
    }
  },

  scrollTo: function scrollTo(scroller, newPosition, useEasing, callback) {
    var startPosition = scroller.view.scrollTop;
    var positionDiff = newPosition - startPosition;

    var startTimestamp = Date.now();
    var totalTime = config.scrollToTransitionMs;

    if (!useEasing) {
      totalTime = config.scrollToLinearTransitionMs;
    }

    // Ease in/out quadratic
    var easing = new BezierEasing(0.455, 0.03, 0.515, 0.955);

    var tick = function tick() {
      var elapsedTime = Date.now() - startTimestamp;
      var totalPercentage = elapsedTime / totalTime;

      var currentPercentage = useEasing ? easing.get(totalPercentage) : totalPercentage;

      scroller.view.scrollTop = startPosition + positionDiff * currentPercentage;

      if (totalPercentage < 1) {
        // Must use setTimeout to not make it flicker. Setting scrollTop in
        // requestAnimationFrame will make it scroll and in the next frame allow
        // the scroll handlers to move elements, making it look very flickery.
        setTimeout(tick, config.frameMs);
      } else {
        scroller.view.scrollTop = startPosition + positionDiff;
        scroller.isClickScrollAnimating = false;
        if (callback) {
          callback();
        }
      }
    };

    scroller.isClickScrollAnimating = true;
    setTimeout(tick, config.frameMs);
  },

  holdClick: function holdClick(scroller) {
    var targetThumbEdge = scroller.clickTargetThumbTop;
    var newPosition = this.getNextScrollValue(scroller);
    var newThumbTop = newPosition / scroller.viewScrollHeight * scroller.viewHeight;
    var newThumbBottom = newThumbTop + scroller.thumbHeight;
    var direction = scroller.clickTargetDirection;

    var isValid = false;
    if (direction === 'up' && newThumbBottom > targetThumbEdge) {
      isValid = true;
    } else if (direction === 'down' && newThumbTop < targetThumbEdge) {
      isValid = true;
    }

    if (isValid) {
      var useEasing = false;

      this.scrollTo(scroller, newPosition, useEasing, function () {
        if (scroller.isClickScrolling) {
          this.holdClick(scroller);
        }
      }.bind(this));
    }
  },

  getNextScrollValue: function getNextScrollValue(scroller) {
    var change = scroller.viewHeight * config.clickScrollDistanceFactor;

    if (scroller.clickTargetDirection === 'up') {
      return scroller.view.scrollTop - change;
    }

    return scroller.view.scrollTop + change;
  },

  setMovementData: function setMovementData(scroller, clientY) {
    var trackTop = scroller.scrollBarTrack.getBoundingClientRect().top;
    var targetThumbEdge = clientY - trackTop;
    var direction = targetThumbEdge < scroller.thumbTop ? 'up' : 'down';

    scroller.clickTargetDirection = direction;
    scroller.clickTargetThumbTop = targetThumbEdge;
  },

  onClickHold: function onClickHold(scroller) {
    scroller.isClickScrolling = true;

    this.holdClick(scroller);
  },

  onMouseMove: function onMouseMove(scroller, event) {
    if (scroller.isMouseOver && event.target === scroller.scrollBarTrack) {
      this.setMovementData(scroller, event.clientY);

      if (scroller.isClickScrolling && !scroller.isClickScrollAnimating) {
        this.holdClick(scroller);
      }
    }
  },

  onMouseUp: function onMouseUp(scroller) {
    scroller.isClickScrolling = false;

    clearTimeout(scroller.clickHoldTimer);

    this.removeHandlers(scroller);

    if (scroller._clickEndHandler) {
      scroller._clickEndHandler();
    }
  },

  onTrackMouseDown: function onTrackMouseDown(scroller, event) {
    var isVisible = scroller.isVisible;
    var isPrimaryButton = event.button === 0;
    var isTargetTrack = event.target === scroller.scrollBarTrack;

    if (isVisible && isPrimaryButton && isTargetTrack) {
      var navigator = window.navigator;
      var isMac = navigator && navigator.userAgent.indexOf('Mac') > -1;
      var isWindows = navigator && navigator.userAgent.indexOf('Windows') > -1;

      if (isMac && event.altKey || isWindows && event.shiftKey) {
        var trackTop = scroller.scrollBarTrack.getBoundingClientRect().top;
        var targetThumbCenter = event.clientY - trackTop;
        var targetThumbTop = Math.max(0, Math.min(scroller.viewHeight - scroller.thumbHeight, targetThumbCenter - scroller.thumbHeight / 2));

        scroller.view.scrollTop = targetThumbTop / (scroller.viewHeight - scroller.thumbHeight) * (scroller.viewScrollHeight - scroller.viewHeight);
      } else {
        this.setMovementData(scroller, event.clientY);

        var targetPosition = this.getNextScrollValue(scroller);
        var useEasing = true;

        this.scrollTo(scroller, targetPosition, useEasing);

        this.addHandlers(scroller);

        scroller.clickHoldTimer = setTimeout(this.onClickHold.bind(this, scroller), config.scrollToTransitionMs + config.clickHoldDelayMs);
      }
    }
  },

  addHandlers: function addHandlers(scroller) {
    scroller._click_onMouseUp = this.onMouseUp.bind(this, scroller);
    scroller._click_onMouseMove = this.onMouseMove.bind(this, scroller);

    document.addEventListener('mouseup', scroller._click_onMouseUp, false);
    document.addEventListener('mousemove', scroller._click_onMouseMove, false);
  },

  removeHandlers: function removeHandlers(scroller) {
    document.removeEventListener('mouseup', scroller._click_onMouseUp, false);
    document.removeEventListener('mousemove', scroller._click_onMouseMove, false);
  },

  attach: function attach(scroller) {
    var onTrackMouseDown = this.onTrackMouseDown.bind(this, scroller);

    scroller.scrollBarTrack.addEventListener('mousedown', onTrackMouseDown, false);

    return function () {
      scroller.scrollBarTrack.removeEventListener('mousedown', onTrackMouseDown, false);
    };
  }

};

},{"./config":29,"bezier-easing":83}],29:[function(require,module,exports){
"use strict";

/**
 * Config with all timer values etc. Easy to have them all in one place, and it
 * also helps for testing, since the config can be used from there too.
 *
 * @private
 */

module.exports = {
  hideAfterMs: 750,
  showAfterMs: 500,

  // Sync with CSS transition duration
  hideTransitionMs: 500,

  expandDelayMs: 150,

  frameMs: 16,
  scrollToTransitionMs: 200,
  scrollToLinearTransitionMs: 120,
  clickHoldDelayMs: 500,
  clickScrollDistanceFactor: 0.95
};

},{}],30:[function(require,module,exports){
'use strict';

/**
 * Module for handling dragging the scroll bar thumb to scroll.
 *
 * @private
 */

module.exports = {

  // Called from outside
  setHandler: function setHandler(eventName, scroller, handler) {
    if (eventName === 'dragStart') {
      scroller._dragStartHandler = handler;
    } else if (eventName === 'dragEnd') {
      scroller._dragEndHandler = handler;
    }
  },

  onThumbMouseDown: function onThumbMouseDown(scroller, event) {
    if (event.button === 0 && scroller.isVisible) {
      scroller.isDragging = true;
      scroller.startDragMouseY = event.clientY;
      scroller.startDragThumbTop = scroller.thumbTop;

      this.addDragHandlers(scroller);

      if (scroller._dragStartHandler) {
        scroller._dragStartHandler();
      }
    }
  },

  onMouseUp: function onMouseUp(scroller, event) {
    if (scroller.isDragging) {
      scroller.isDragging = false;

      this.removeDragHandlers(scroller);

      if (scroller._dragEndHandler) {
        scroller._dragEndHandler();
      }
    }
  },

  onMouseMove: function onMouseMove(scroller, event) {
    var y = event.clientY;
    var startY = scroller.startDragMouseY;

    scroller.thumbTop = Math.max(0, Math.min(scroller.viewHeight - scroller.thumbHeight, scroller.startDragThumbTop + y - startY));

    scroller.view.scrollTop = scroller.thumbTop / (scroller.viewHeight - scroller.thumbHeight) * (scroller.viewScrollHeight - scroller.viewHeight);
  },

  addDragHandlers: function addDragHandlers(scroller) {
    scroller._drag_onMouseMove = this.onMouseMove.bind(this, scroller);
    scroller._drag_onMouseUp = this.onMouseUp.bind(this, scroller);

    document.addEventListener('mousemove', scroller._drag_onMouseMove, false);
    document.addEventListener('mouseup', scroller._drag_onMouseUp, false);
  },

  removeDragHandlers: function removeDragHandlers(scroller) {
    document.removeEventListener('mousemove', scroller._drag_onMouseMove, false);
    document.removeEventListener('mouseup', scroller._drag_onMouseUp, false);
  },

  attach: function attach(scroller) {
    var onThumbMouseDown = this.onThumbMouseDown.bind(this, scroller);

    scroller.scrollBarThumb.addEventListener('mousedown', onThumbMouseDown, false);

    return function () {
      scroller.scrollBarThumb.removeEventListener('mousedown', onThumbMouseDown, false);
    };
  }

};

},{}],31:[function(require,module,exports){
'use strict';

/**
 * Module for handling expanding the scroll bar width on hover.
 *
 * @private
 */

var config = require('./config');

module.exports = {

  expand: function expand(scroller) {
    clearTimeout(scroller.resetExpandedTimer);
    scroller.scrollBarTrack.classList.add('expanded');
  },

  collapse: function collapse(scroller) {
    scroller.scrollBarTrack.classList.remove('expanded');
  },

  // Called from outside
  onHide: function onHide(scroller) {
    if (!scroller.alwaysVisible) {
      clearTimeout(scroller.expandTimer);
      clearTimeout(scroller.resetExpandedTimer);

      scroller.resetExpandedTimer = setTimeout(this.collapse.bind(this, scroller), config.hideTransitionMs);
    }
  },

  onTrackMouseEnter: function onTrackMouseEnter(scroller, event) {
    if (event.target === scroller.scrollBarTrack) {
      if (scroller.isVisible) {
        clearTimeout(scroller.expandTimer);
        clearTimeout(scroller.resetExpandedTimer);
        scroller.expandTimer = setTimeout(function () {
          this.expand(scroller);
        }.bind(this), config.expandDelayMs);
      } else {
        this.expand(scroller);
      }
    }
  },

  onTrackMouseLeave: function onTrackMouseLeave(scroller, event) {
    if (event.target === scroller.scrollBarTrack) {
      if (scroller.isVisible) {
        clearTimeout(scroller.expandTimer);
      } else {
        this.collapse(scroller);
      }
    }
  },

  attach: function attach(scroller) {
    if (scroller.alwaysVisible) {
      this.expand(scroller);

      return function () {};
    } else {
      this.collapse(scroller);

      var onTrackMouseEnter = this.onTrackMouseEnter.bind(this, scroller);
      var onTrackMouseLeave = this.onTrackMouseLeave.bind(this, scroller);

      scroller.scrollBarTrack.addEventListener('mouseenter', onTrackMouseEnter, false);
      scroller.scrollBarTrack.addEventListener('mouseleave', onTrackMouseLeave, false);

      return function () {
        scroller.scrollBarTrack.removeEventListener('mouseenter', onTrackMouseEnter, false);
        scroller.scrollBarTrack.removeEventListener('mouseleave', onTrackMouseLeave, false);
      };
    }
  }

};

},{"./config":29}],32:[function(require,module,exports){
'use strict';

var glue = require('../../spotify-glue-cat');
var cosmos = require('spotify-cosmos-api');

var center = require('../center');
var drag = require('./drag');
var visibility = require('./visibility');
var position = require('./position');
var expansion = require('./expansion');
var click = require('./click');

var scrollers = [];
var scrollerStyle = null;

function Scroller(scrollView) {
  this.view = scrollView;
  this.setInitialState();
  this.addScrollBar();
  this.refresh();

  this.view.setAttribute('data-scroll-area-initialized', '');

  this._onResize = function () {
    this.refresh();
  }.bind(this);
  this._onScroll = function () {
    this.refreshScrollBar();
  }.bind(this);
  this._onThumbDragStart = function (event) {
    event.preventDefault();
    event.stopPropagation();
  };

  // Listen for the scroll event to update view size etc on scroll
  var scrollObject = this.isBody ? window : this.view;
  scrollObject.addEventListener('scroll', this._onScroll, false);

  // Listen for the window resize event, even for scroll areas that are not the
  // body scroll. Since we can't listen for resize events when elements resize,
  // we do a best effort of at least updating when the window resizes (which
  // might affect the size of the scroll area).
  window.addEventListener('resize', this._onResize, false);

  // Prevent dragndrop handling from spotify-events (it will be triggered
  // otherwise since we have to set the draggable attribute to not trigger
  // focus events).
  this.scrollBarThumb.addEventListener('dragstart', this._onThumbDragStart, true);

  this._detachVisibility = visibility.attach(this);
  this._detachPosition = position.attach(this);
  this._detachDrag = drag.attach(this);
  this._detachClick = click.attach(this);
  this._detachExpansion = expansion.attach(this);

  visibility.setHandler('show', this, function () {
    this.refresh();
  }.bind(this));

  visibility.setHandler('hide', this, function () {
    expansion.onHide(this);
  }.bind(this));

  // Events are sent when dragging to allow some use cases where you need to do
  // something while dragging. For example, when dragging the scroll bar in the
  // app sidebar and hovering over the main view, it will not trigger mousemove
  // events since the main view is an iframe. To counter that, zlink is
  // listening to these events and sets pointer-events on the content area.
  drag.setHandler('dragStart', this, function () {
    center.emit('scroll-thumb-drag-start', { id: this.viewId });
  }.bind(this));
  drag.setHandler('dragEnd', this, function () {
    visibility.onDragEnd(this);
    center.emit('scroll-thumb-drag-end', { id: this.viewId });
  }.bind(this));

  click.setHandler('clickEnd', this, function () {
    visibility.onClickEnd(this);
  }.bind(this));
}

Scroller.prototype.setInitialState = function () {
  var scrollerStyleToUse = scrollerStyle || window.__spotify.scroller_style;
  this.alwaysVisible = scrollerStyleToUse === 'always';

  this.scrollBarTrack = null;
  this.scrollBarThumb = null;

  this.isBody = this.view === document.body;
  this.viewId = this.view.getAttribute('data-scroll-area');
  this.viewHeight = 0;
  this.viewScrollHeight = 0;

  this.isVisible = false;
  this.isDragging = false;
  this.isMouseOver = false;
  this.isClickScrolling = false;
  this.isClickScrollAnimating = false;

  this.thumbTop = 0;
  this.thumbHeight = 0;

  this.clickTargetDirection = 'down';
  this.clickTargetThumbTop = 0;

  this.startDragMouseY = 0;
  this.startDragThumbTop = 0;

  this.hideTimer = 0;
  this.mouseOverShowTimer = 0;
};

Scroller.prototype.addScrollBar = function () {
  var track = document.createElement('div');
  var thumb = document.createElement('div');

  track.className = 'scrollbar-track';
  thumb.className = 'scrollbar-thumb';

  if (this.alwaysVisible) {
    track.className += ' always-visible';
  }

  // If the thumb is not set to draggable it will trigger focus events on
  // elements being dragged over. For example, dragging the thumb up to the
  // search input puts focus in the search input, which opens the suggest box.
  // Since we will find this element from the dragndrop module, we also need to
  // prevent any drag handling (find the drag listener further down).
  thumb.setAttribute('draggable', 'true');

  track.appendChild(thumb);
  this.view.appendChild(track);

  this.scrollBarTrack = track;
  this.scrollBarThumb = thumb;
};

Scroller.prototype.setViewSize = function () {
  // Hide the scroll bar while calculating sizes, so the scroll bar doesn't
  // interfere. This can happen if scrolled to the bottom of the scroll view and
  // the scroll height changes to be smaller. If the scroll bar is not hidden
  // while calculating the values here, the scrollHeight will not change, since
  // the scroll bar is taking up space.
  this.scrollBarTrack.style.display = 'none';

  if (this.isBody) {
    this.viewHeight = window.innerHeight || Infinity;
  } else {
    this.viewHeight = this.view.clientHeight || Infinity;
  }

  this.viewScrollHeight = this.view.scrollHeight;

  this.scrollBarTrack.style.display = 'block';
};

Scroller.prototype.setThumbSize = function () {
  var percentage = this.viewHeight / this.viewScrollHeight;
  this.thumbHeight = Math.max(40, this.viewHeight * percentage);
  this.scrollBarThumb.style.height = this.thumbHeight + 'px';
};

Scroller.prototype.setTrackPosition = function () {
  this.scrollBarTrack.style.transform = 'translate3d(0, ' + (this.view.scrollTop + 'px') + ', 0)';
};

Scroller.prototype.refresh = function () {
  this.refreshView();
  this.refreshScrollBar();
};

Scroller.prototype.refreshView = function () {
  this.setViewSize();
};

Scroller.prototype.refreshScrollBar = function () {
  this.setThumbSize();

  if (!this.isBody) {
    this.setTrackPosition();
  }
};

Scroller.prototype.update = function () {
  var oldViewHeight = this.viewHeight;
  var oldScrollHeight = this.viewScrollHeight;

  this.refresh();

  visibility.update(this);

  var newViewHeight = this.viewHeight;
  var newScrollHeight = this.viewScrollHeight;

  if (newViewHeight !== oldViewHeight || newScrollHeight !== oldScrollHeight) {
    visibility.highlight(this);
  }
};

Scroller.prototype.setScrollBarMode = function (mode) {
  this.alwaysVisible = mode === 'always';

  if (this.alwaysVisible) {
    this.scrollBarTrack.classList.add('always-visible');
  } else {
    this.scrollBarTrack.classList.remove('always-visible');
  }

  this._detachVisibility();
  this._detachPosition();
  this._detachDrag();
  this._detachClick();
  this._detachExpansion();

  this._detachVisibility = visibility.attach(this);
  this._detachPosition = position.attach(this);
  this._detachDrag = drag.attach(this);
  this._detachClick = click.attach(this);
  this._detachExpansion = expansion.attach(this);
};

Scroller.prototype.isInDOM = function () {
  var currentNode = this.view.parentNode;
  while (currentNode && currentNode !== document.documentElement) {
    currentNode = currentNode.parentNode;
  }

  // If we still have a current node after the loop, we found the document
  // element, which means it's in DOM.
  return !!currentNode;
};

Scroller.prototype.destroy = function () {
  var scrollObject = this.isBody ? window : this.view;

  scrollObject.removeEventListener('scroll', this._onScroll, false);

  window.removeEventListener('resize', this._onResize, false);

  this.scrollBarThumb.removeEventListener('dragstart', this._onThumbDragStart, true);

  this.view.removeAttribute('data-scroll-area-initialized', '');
  this.view.removeChild(this.scrollBarTrack);

  this._detachVisibility();
  this._detachPosition();
  this._detachDrag();
  this._detachClick();
  this._detachExpansion();
};

var isAttached = false;
var controlMessageSubscription;

exports.update = function (node) {
  if (!isAttached) {
    return;
  }

  // Clean up scrollers that are not in DOM anymore.
  scrollers = scrollers.filter(function (scroller) {
    if (!scroller.isInDOM()) {
      scroller.destroy();
      return false;
    }
    return true;
  });

  // Update all active scrollers
  for (var i = 0, l = scrollers.length; i < l; i++) {
    scrollers[i].update();
  }

  var selector = '[data-scroll-area]';
  var scrollViews = (node || document).querySelectorAll(selector);

  for (var i = 0, l = scrollViews.length; i < l; i++) {
    if (!scrollViews[i].hasAttribute('data-scroll-area-initialized')) {
      var scrollView = scrollViews[i];
      var isBody = scrollView === document.body;

      if (isBody && glue.getVersion() !== 2) {
        continue;
      }

      scrollers.push(new Scroller(scrollView));
    }
  }
};

exports.attach = function () {
  if (isAttached) return;
  isAttached = true;

  var setScrollBarMode = function setScrollBarMode(mode) {
    scrollerStyle = mode;

    for (var i = 0, l = scrollers.length; i < l; i++) {
      scrollers[i].setScrollBarMode(mode);
    }
  };

  controlMessageSubscription = cosmos.resolver.subscribe({
    url: 'sp://messages/v1/container/control'
  }, function (error, response) {
    if (!error) {
      var data = response.getJSONBody();
      if (data) {
        var styleWasChanged = true;
        switch (data.type) {
          case 'set_scroller_style_always_visible':
            setScrollBarMode('always');
            break;
          case 'set_scroller_style_overlay':
            setScrollBarMode('overlay');
            break;
          default:
            styleWasChanged = false;
        }

        // Fix a rendering bug in Chromium. When scroller style changes in the
        // system (changing system preference, connecting/disconnecting a mouse
        // etc), Chromium will render a white area where the scroll bar is
        // supposed to be. By adding and removing a class name we're triggering
        // a re-render and it will look good.
        //
        // https://jira.spotify.net/browse/KM-8285
        // http://crbug.com/538579
        if (styleWasChanged) {
          var performFix = function performFix() {
            var nodes = scrollers.map(function (scroller) {
              return scroller.view;
            });

            // Always include body to fix the main scroll, even if it doesn't
            // have a custom scroll bar.
            if (nodes.indexOf(document.body) === -1) {
              nodes.push(document.body);
            }

            for (var i = 0, l = nodes.length; i < l; i++) {
              nodes[i].classList.add('jmeBDLRW3CRWW3kZZaZ');
              nodes[i].classList.remove('jmeBDLRW3CRWW3kZZaZ');
            }
          };

          // Perform the fix twice (once with a delay), since it sometimes might
          // be slow and won't apply the fix on the first try.
          performFix();
          setTimeout(performFix, 1000);
        }
      }
    } else {
      controlMessageSubscription.cancel();
    }
  });
};

exports.detach = function () {
  if (!isAttached) return;
  isAttached = false;

  for (var i = 0, l = scrollers.length; i < l; i++) {
    scrollers[i].destroy();
  }
  scrollers.length = 0;

  scrollerStyle = null;

  if (controlMessageSubscription) {
    controlMessageSubscription.cancel();
    controlMessageSubscription = null;
  }
};

},{"../../spotify-glue-cat":57,"../center":27,"./click":28,"./drag":30,"./expansion":31,"./position":33,"./visibility":34,"spotify-cosmos-api":112}],33:[function(require,module,exports){
'use strict';

/**
 * Module for handling updating the scroll bar thumb position when scroll
 * position changes.
 *
 * @private
 */

module.exports = {

  setThumbPosition: function setThumbPosition(scroller) {
    if (scroller.viewScrollHeight === scroller.viewHeight) {
      scroller.thumbTop = 0;
    } else {
      scroller.thumbTop = scroller.view.scrollTop / (scroller.viewScrollHeight - scroller.viewHeight) * (scroller.viewHeight - scroller.thumbHeight);
    }

    scroller.scrollBarThumb.style.transform = 'translate3d(0, ' + (scroller.thumbTop + 'px') + ', 0)';
  },

  onScroll: function onScroll(scroller) {
    this.setThumbPosition(scroller);
  },

  attach: function attach(scroller) {
    var onScroll = this.onScroll.bind(this, scroller);

    var scrollObject = scroller.isBody ? window : scroller.view;
    scrollObject.addEventListener('scroll', onScroll, false);

    this.setThumbPosition(scroller);

    return function () {
      scrollObject.removeEventListener('scroll', onScroll, false);
    };
  }

};

},{}],34:[function(require,module,exports){
'use strict';

/**
 * Module for handling the visibility of the scroll bar, based on mouse position
 * and scroll events.
 *
 * @private
 */

var config = require('./config');

module.exports = {

  // Called from outside
  setHandler: function setHandler(eventName, scroller, handler) {
    if (eventName === 'show') {
      scroller._showHandler = handler;
    } else if (eventName === 'hide') {
      scroller._hideHandler = handler;
    }
  },

  refresh: function refresh(scroller) {
    if (scroller.viewScrollHeight > scroller.viewHeight) {
      this.showScrollBar(scroller);
    } else {
      this.hideScrollBar(scroller);
    }
  },

  showScrollBar: function showScrollBar(scroller) {
    if (scroller.isVisible) {
      return;
    }

    if (scroller.viewScrollHeight > scroller.viewHeight) {
      scroller.scrollBarTrack.classList.add('visible');
      scroller.isVisible = true;

      if (scroller._showHandler) {
        scroller._showHandler();
      }
    }
  },

  hideScrollBar: function hideScrollBar(scroller) {
    if (!scroller.isVisible || scroller.isDragging) {
      return;
    }

    scroller.scrollBarTrack.classList.remove('visible');
    scroller.isVisible = false;

    if (scroller._hideHandler) {
      scroller._hideHandler();
    }
  },

  startHideTimer: function startHideTimer(scroller) {
    this.stopHideTimer(scroller);
    scroller.hideTimer = setTimeout(this.hideScrollBar.bind(this, scroller), config.hideAfterMs);
  },

  stopHideTimer: function stopHideTimer(scroller) {
    clearTimeout(scroller.hideTimer);
  },

  // Called from outside
  onDragEnd: function onDragEnd(scroller) {
    if (!scroller.alwaysVisible && !scroller.isMouseOver) {
      this.startHideTimer(scroller);
    }
  },

  // Called from outside
  onClickEnd: function onClickEnd(scroller) {
    if (!scroller.alwaysVisible && !scroller.isMouseOver) {
      this.startHideTimer(scroller);
    }
  },

  onScroll: function onScroll(scroller) {
    if (!scroller.isVisible) {
      this.showScrollBar(scroller);
    }

    if (!scroller.isDragging && !scroller.isClickScrolling && !scroller.isMouseOver) {
      this.startHideTimer(scroller);
    }
  },

  onTrackMouseEnter: function onTrackMouseEnter(scroller, event) {
    if (event.target === scroller.scrollBarTrack) {
      scroller.isMouseOver = true;

      this.stopHideTimer(scroller);

      if (!scroller.isVisible) {
        scroller.mouseOverShowTimer = setTimeout(this.showScrollBar.bind(this, scroller), config.showAfterMs);
      }
    }
  },

  onTrackMouseLeave: function onTrackMouseLeave(scroller, event) {
    if (event.target === scroller.scrollBarTrack) {
      scroller.isMouseOver = false;

      if (!scroller.isDragging && !scroller.isClickScrolling) {
        clearTimeout(scroller.mouseOverShowTimer);

        if (scroller.isVisible) {
          this.startHideTimer(scroller);
        }
      }
    }
  },

  attach: function attach(scroller) {
    if (scroller.alwaysVisible) {
      this.refresh(scroller);

      return function () {};
    } else {
      this.hideScrollBar(scroller);

      var onScroll = this.onScroll.bind(this, scroller);
      var onTrackMouseEnter = this.onTrackMouseEnter.bind(this, scroller);
      var onTrackMouseLeave = this.onTrackMouseLeave.bind(this, scroller);

      var scrollObject = scroller.isBody ? window : scroller.view;
      scrollObject.addEventListener('scroll', onScroll, false);

      scroller.scrollBarTrack.addEventListener('mouseenter', onTrackMouseEnter, false);
      scroller.scrollBarTrack.addEventListener('mouseleave', onTrackMouseLeave, false);

      return function () {
        scrollObject.removeEventListener('scroll', onScroll, false);

        scroller.scrollBarTrack.removeEventListener('mouseenter', onTrackMouseEnter, false);
        scroller.scrollBarTrack.removeEventListener('mouseleave', onTrackMouseLeave, false);
      };
    }
  },

  update: function update(scroller) {
    if (scroller.alwaysVisible) {
      this.refresh(scroller);
    }
  },

  highlight: function highlight(scroller) {
    if (!scroller.alwaysVisible && !scroller.isVisible) {
      this.showScrollBar(scroller);
      this.startHideTimer(scroller);
    }
  }

};

},{"./config":29}],35:[function(require,module,exports){
(function (global){
'use strict';

exports.init = function () {
  require('./expose-debug-global').expose(global, 'bridge', require('../spotify-bridge-request'));
};

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"../spotify-bridge-request":26,"./expose-debug-global":37}],36:[function(require,module,exports){
(function (global){
'use strict';

exports.init = function () {
  require('./expose-debug-global').expose(global, 'cosmos', require('spotify-cosmos-api'));
};

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"./expose-debug-global":37,"spotify-cosmos-api":112}],37:[function(require,module,exports){
'use strict';

exports.expose = function (global, name, object) {
  if (global.__spotify && global.__spotify.developer_mode) {
    Object.defineProperty(global, name, {
      get: function get() {
        try {
          throw new Error();
        } catch (error) {
          if (!/injectedscript/i.test(error.stack)) {
            throw new Error('window.' + name + ' should only be accessed from the console');
          }
        }
        return object;
      },
      enumerable: true,
      configurable: true
    });
  }
};

},{}],38:[function(require,module,exports){
module.exports = {
  "Album": "Album",
  "AndMore": "und {0} weitere",
  "Artist": "Künstler",
  "By": "von",
  "Create Similar Playlist": "Ähnliche Playlist erstellen",
  "Filter": "Filter",
  "Follow": "Folgen",
  "Follower": "Follower",
  "FollowersLabel": "Followers",
  "Following": "Folge ich",
  "FollowingLabel": "Folge ich",
  "ListenersLabel": "Monatliche Hörer",
  "FollowsYou": "Folgt dir",
  "HoldToPreview": "Zum Reinhören gedrückt halten",
  "ListenCount": "{0} Mal abgespielt",
  "ListenReactionMulti": "{0} Hörer in Deinem Netzwerk",
  "ListenReactionSingle": "{0} hört sich das an",
  "LocalFile": "Lokale Datei",
  "More": "Mehr",
  "Pause": "Pause",
  "Play": "Play",
  "Playlist": "Playlist",
  "PressEnterToPlay": "Drück die Eingabetaste zum Abspielen",
  "Popularity": "Beliebtheit",
  "Remove": "Entfernen",
  "RemoveYourMusic": "Aus \"Deine Musik\" entfernen",
  "Save": "Speichern",
  "SaveYourMusic": "In \"Deine Musik\" speichern",
  "Saved": "Gespeichert",
  "Song": "Song",
  "StartRadio": "Radio starten",
  "Time": "Dauer",
  "Toplist": "Top-Songs",
  "Track": "Song",
  "Unfollow": "Nicht mehr folgen",
  "User": "Benutzer",
  "ViewAll": "Mehr Darstellung",
  "HoursShort": "{0} Std.",
  "MinutesShort": "{0} Min.",
  "SecondsShort": "{0} Sek.",
  "ErrorTitle": "Bei der Anzeige dieser Ansicht ist ein Fehler aufgetreten!",
  "ErrorMessage": "Diese Ansicht ist entweder nicht vorhanden oder es ist ein Fehler aufgetreten.",
  "OfflineTitle": "Diese Ansicht ist offline nicht verfügbar.",
  "OfflineMessage": "Geh zum Laden online."
};
},{}],39:[function(require,module,exports){
module.exports = {
  "Album": "Άλμπουμ",
  "AndMore": "και άλλοι {0}",
  "Artist": "Καλλιτέχνης",
  "By": "από",
  "Create Similar Playlist": "Δημιουργία παρόμοιας playlist",
  "Filter": "Φίλτρο",
  "Follow": "Ακολούθησε",
  "Follower": "Οπαδός",
  "FollowersLabel": "Οπαδοί",
  "Following": "Aκολουθείται",
  "FollowingLabel": "Aκολουθείται",
  "ListenersLabel": "Μηνιαίοι ακροατές",
  "FollowsYou": "Σε ακολουθεί",
  "HoldToPreview": "Πάτησε και κράτησε πατημένο για προεπισκόπηση",
  "ListenCount": "{0} αναπαραγωγές",
  "ListenReactionMulti": "{0} ακροατές στο δίκτυό σου",
  "ListenReactionSingle": "Ο χρήστης {0} ακούει αυτό",
  "LocalFile": "Τοπικό αρχείο",
  "More": "Περισσότερα",
  "Pause": "Παύση",
  "Play": "Αναπαραγωγή",
  "Playlist": "Λίστα",
  "PressEnterToPlay": "Πάτησε Enter για αναπαραγωγή",
  "Popularity": "Δημοφιλία",
  "Remove": "Αφαίρεση",
  "RemoveYourMusic": "Αφαίρεση από τη Mουσική σου",
  "Save": "Αποθήκευση",
  "SaveYourMusic": "Αποθήκευση στη Mουσική σου",
  "Saved": "Αποθηκεύτηκε",
  "Song": "Τραγούδι",
  "StartRadio": "Έναρξη ράδιο",
  "Time": "Διάρκεια",
  "Toplist": "Κορυφαία τραγούδια",
  "Track": "Τραγούδι",
  "Unfollow": "Άρση ακολούθησης",
  "User": "Χρήστης",
  "ViewAll": "Δες τα όλα",
  "HoursShort": "{0} ώρα",
  "MinutesShort": "{0} λεπ.",
  "SecondsShort": "{0} δευτ.",
  "ErrorTitle": "Προέκυψε σφάλμα κατά την προβολή αυτής της οθόνης!",
  "ErrorMessage": "Η συγκεκριμένη προβολή δεν υπάρχει ή προέκυψε κάποιο σφάλμα.",
  "OfflineTitle": "Αυτή η προβολή δεν είναι διαθέσιμη εκτός σύνδεσης!",
  "OfflineMessage": "Συνδέσου στο διαδίκτυο για να πραγματοποιηθεί φόρτωση."
};
},{}],40:[function(require,module,exports){
module.exports = {
  "Album": "Album",
  "AndMore": "and {0} more",
  "Artist": "Artist",
  "By": "by",
  "Create Similar Playlist": "Create Similar Playlist",
  "Filter": "Filter",
  "Follow": "Follow",
  "Follower": "Follower",
  "FollowersLabel": "Followers",
  "Following": "Following",
  "FollowingLabel": "Following",
  "ListenersLabel": "Monthly Listeners",
  "FollowsYou": "Follows You",
  "HoldToPreview": "Click and Hold to Preview",
  "ListenCount": "{0} plays",
  "ListenReactionMulti": "{0} listeners in your network",
  "ListenReactionSingle": "{0} listens to this",
  "LocalFile": "Local File",
  "More": "More",
  "Pause": "Pause",
  "Play": "Play",
  "Playlist": "Playlist",
  "PressEnterToPlay": "Press Enter to play",
  "Popularity": "Popularity",
  "Remove": "Remove",
  "RemoveYourMusic": "Remove from Your Music",
  "Save": "Save",
  "SaveYourMusic": "Save to Your Music",
  "Saved": "Saved",
  "Song": "Song",
  "StartRadio": "Start Radio",
  "Time": "Time",
  "Toplist": "Top songs",
  "Track": "Song",
  "Unfollow": "Unfollow",
  "User": "User",
  "ViewAll": "View All",
  "HoursShort": "{0} hr",
  "MinutesShort": "{0} min",
  "SecondsShort": "{0} sec",
  "ErrorTitle": "There was a problem displaying this view!",
  "ErrorMessage": "This view either does not exist or an error occurred.",
  "OfflineTitle": "This view is not available offline!",
  "OfflineMessage": "Please go online to load."
}
;
},{}],41:[function(require,module,exports){
module.exports = {
  "Album": "Álbum",
  "AndMore": "y {0} más",
  "Artist": "Artista",
  "By": "por",
  "Create Similar Playlist": "Crear playlist similar",
  "Filter": "Filtrar",
  "Follow": "Seguir",
  "Follower": "Seguidor",
  "FollowersLabel": "Seguidores",
  "Following": "Siguiendo",
  "FollowingLabel": "Siguiendo",
  "ListenersLabel": "Oyentes mensuales",
  "FollowsYou": "Te sigue",
  "HoldToPreview": "Haz clic y mantén pulsado para oír la muestra preliminar",
  "ListenCount": "{0} reproducciones",
  "ListenReactionMulti": "{0} oyentes en tu red",
  "ListenReactionSingle": "{0} escucha esto",
  "LocalFile": "Archivo local",
  "More": "Más",
  "Pause": "Pausa",
  "Play": "Reproducir",
  "Playlist": "Lista",
  "PressEnterToPlay": "Presiona Enter para reproducir",
  "Popularity": "Popularidad",
  "Remove": "Eliminar",
  "RemoveYourMusic": "Eliminar de Tu Música",
  "Save": "Guardar",
  "SaveYourMusic": "Guardar en Tu Música",
  "Saved": "Guardado",
  "Song": "Canción",
  "StartRadio": "Comenzar Radio",
  "Time": "Tiempo",
  "Toplist": "Canciones más reproducidas",
  "Track": "Canción",
  "Unfollow": "Dejar de seguir",
  "User": "Usuario",
  "ViewAll": "Ver todos",
  "HoursShort": "{0} hr",
  "MinutesShort": "{0} min",
  "SecondsShort": "{0} seg",
  "ErrorTitle": "Hubo un problema al mostrar esta vista.",
  "ErrorMessage": "Puede ser que esta vista no exista, o bien, que haya ocurrido un error.",
  "OfflineTitle": "Esta vista no está disponible sin conexión. ",
  "OfflineMessage": "Conéctate a la red para cargar."
};
},{}],42:[function(require,module,exports){
module.exports = {
  "Album": "Álbum",
  "AndMore": "y {0} más",
  "Artist": "Artista",
  "By": "por",
  "Create Similar Playlist": "Crear playlist similar",
  "Filter": "Filtrar",
  "Follow": "Seguir",
  "Follower": "Seguidor",
  "FollowersLabel": "Seguidores",
  "Following": "Siguiendo",
  "FollowingLabel": "Siguiendo",
  "ListenersLabel": "Oyentes mensuales",
  "FollowsYou": "Te sigue",
  "HoldToPreview": "Pulsa y mantén pulsado para oír la muestra preliminar",
  "ListenCount": "{0} reproducciones",
  "ListenReactionMulti": "{0} oyentes en tu red",
  "ListenReactionSingle": "{0} escucha esto",
  "LocalFile": "Archivo local",
  "More": "Más",
  "Pause": "Pausar",
  "Play": "Reproducir",
  "Playlist": "Lista",
  "PressEnterToPlay": "Pulsa Intro para reproducir",
  "Popularity": "Popularidad",
  "Remove": "Retirar",
  "RemoveYourMusic": "Eliminar de Tu música",
  "Save": "Guardar",
  "SaveYourMusic": "Guardar en Tu música",
  "Saved": "Guardada",
  "Song": "Canción",
  "StartRadio": "Comenzar radio",
  "Time": "Tiempo",
  "Toplist": "Canciones más escuchadas",
  "Track": "Canción",
  "Unfollow": "Dejar de seguir",
  "User": "Usuario",
  "ViewAll": "Ver todos",
  "HoursShort": "{0} hr",
  "MinutesShort": "{0} min",
  "SecondsShort": "{0} seg",
  "ErrorTitle": "Se ha producido un problema al mostrar esta vista.",
  "ErrorMessage": "Esta vista no existe o se ha producido un error.",
  "OfflineTitle": "Esta vista no está disponible sin conexión. ",
  "OfflineMessage": "Por favor, conéctate para cargar."
};
},{}],43:[function(require,module,exports){
module.exports = {
  "Album": "Albumi",
  "AndMore": "ja {0} muuta",
  "Artist": "Artisti",
  "By": "tekijältä",
  "Create Similar Playlist": "Luo samankaltainen soittolista",
  "Filter": "Suodatin",
  "Follow": "Seuraa",
  "Follower": "Seuraaja",
  "FollowersLabel": "Seuraajat",
  "Following": "Seurataan",
  "FollowingLabel": "Seurataan",
  "ListenersLabel": "Kuuntelijat kuukauden aikana",
  "FollowsYou": "Seuraa sinua",
  "HoldToPreview": "Kuuntele pätkä pitämällä tätä painettuna",
  "ListenCount": "{0} toistoa",
  "ListenReactionMulti": "{0} kuuntelijaa verkostossasi",
  "ListenReactionSingle": "{0} kuuntelee tätä",
  "LocalFile": "Paikallinen tiedosto",
  "More": "Lisää",
  "Pause": "Tauko",
  "Play": "Toista",
  "Playlist": "Soittolista",
  "PressEnterToPlay": "Toista painamalla Enter-näppäintä",
  "Popularity": "Suosio",
  "Remove": "Poista",
  "RemoveYourMusic": "Poista Omasta musiikista",
  "Save": "Tallenna",
  "SaveYourMusic": "Tallenna Omaan musiikkiin",
  "Saved": "Tallennettu",
  "Song": "Kappale",
  "StartRadio": "Käynnistä radio",
  "Time": "Kesto",
  "Toplist": "Suosituimmat kappaleet",
  "Track": "Kappale",
  "Unfollow": "Lopeta seuraaminen",
  "User": "Käyttäjä",
  "ViewAll": "Näytä kaikki",
  "HoursShort": "{0} h",
  "MinutesShort": "{0} min",
  "SecondsShort": "{0} s",
  "ErrorTitle": "Tämän näkymän näyttämisessä on ongelmia.",
  "ErrorMessage": "Tätä näkymää ei ole, tai tapahtui virhe.",
  "OfflineTitle": "Tätä näkymää ei voi käyttää offline-tilassa!",
  "OfflineMessage": "Siirry online-tilaan, jotta voit ladata."
};
},{}],44:[function(require,module,exports){
module.exports = {
  "Album": "Album",
  "AndMore": "et {0} autres",
  "Artist": "Artiste",
  "By": "par",
  "Create Similar Playlist": "Créer une liste de lecture semblable",
  "Filter": "Filtrer",
  "Follow": "Suivre",
  "Follower": "Abonné",
  "FollowersLabel": "Abonné",
  "Following": "Suivis",
  "FollowingLabel": "Suivis",
  "ListenersLabel": "Auditeurs mensuels",
  "FollowsYou": "Vous suit",
  "HoldToPreview": "Cliquez longuement pour avoir un aperçu",
  "ListenCount": "{0} écoutes",
  "ListenReactionMulti": "{0} auditeurs dans votre réseau",
  "ListenReactionSingle": "{0} écoute ceci",
  "LocalFile": "Fichier local",
  "More": "Plus",
  "Pause": "Pause",
  "Play": "Lecture",
  "Playlist": "Playlist",
  "PressEnterToPlay": "Appuyez sur Entrée pour faire la lecture",
  "Popularity": "Popularité",
  "Remove": "Supprimer",
  "RemoveYourMusic": "Supprimer de Votre musique",
  "Save": "Sauvegarder",
  "SaveYourMusic": "Enregistrer dans Votre musique",
  "Saved": "Sauvegardé",
  "Song": "Titre",
  "StartRadio": "Lancer la radio",
  "Time": "Durée",
  "Toplist": "Meilleures chansons",
  "Track": "Titre",
  "Unfollow": "Ne plus suivre",
  "User": "Utilisateur",
  "ViewAll": "Voir tout",
  "HoursShort": "{0} h",
  "MinutesShort": "{0} min",
  "SecondsShort": "{0} s",
  "ErrorTitle": "Un problème est survenu lors du chargement de cet affichage!",
  "ErrorMessage": "L'affichage n'existe pas ou une erreur s'est produite.",
  "OfflineTitle": "Cette vue n'est pas disponible hors ligne!",
  "OfflineMessage": "Veuillez accéder à Internet pour charger le contenu."
};
},{}],45:[function(require,module,exports){
module.exports = {
  "Album": "Album",
  "AndMore": "et {0} autres",
  "Artist": "Artiste",
  "By": "par",
  "Create Similar Playlist": "Créer une playlist similaire",
  "Filter": "Filtre",
  "Follow": "S'abonner",
  "Follower": "Abonné",
  "FollowersLabel": "Abonnés",
  "Following": "Abonné",
  "FollowingLabel": "Abonné",
  "ListenersLabel": "Nombres de personnes qui écoutent par mois",
  "FollowsYou": "Est abonné à vous",
  "HoldToPreview": "Cliquez longuement pour avoir un aperçu",
  "ListenCount": "{0} écoutes",
  "ListenReactionMulti": "{0} auditeurs dans votre réseau",
  "ListenReactionSingle": "{0} écoute ceci.",
  "LocalFile": "Fichier local",
  "More": "Plus",
  "Pause": "Pause",
  "Play": "Lire",
  "Playlist": "Playlist",
  "PressEnterToPlay": "Appuyez sur Entrée pour écouter",
  "Popularity": "Popularité",
  "Remove": "Supprimer",
  "RemoveYourMusic": "Supprimer de Ma musique",
  "Save": "Sauvegarder",
  "SaveYourMusic": "Sauvegarder dans Ma musique",
  "Saved": "Sauvegardé",
  "Song": "Titre",
  "StartRadio": "Ecouter la radio",
  "Time": "Durée",
  "Toplist": "Top titres",
  "Track": "Titre",
  "Unfollow": "Se désabonner",
  "User": "Utilisateur",
  "ViewAll": "Présentation tout",
  "HoursShort": "{0} h",
  "MinutesShort": "{0} min",
  "SecondsShort": "{0} s",
  "ErrorTitle": "Problème d'affichage !",
  "ErrorMessage": "Cet affichage n'existe pas ou une erreur s'est produite.",
  "OfflineTitle": "Cet affichage n'est pas disponible hors connexion.",
  "OfflineMessage": "Connectez-vous pour procéder au chargement."
};
},{}],46:[function(require,module,exports){
module.exports = {
  "Album": "Album",
  "AndMore": "és még {0} felhasználó",
  "Artist": "Előadó",
  "By": "tőle:",
  "Create Similar Playlist": "Hasonló műsorlista létrehozása",
  "Filter": "Szűrő",
  "Follow": "Követés",
  "Follower": "Követő",
  "FollowersLabel": "Követők",
  "Following": "Követések",
  "FollowingLabel": "Követések",
  "ListenersLabel": "Hallgatók havonta",
  "FollowsYou": "Téged követ",
  "HoldToPreview": "Tartsd nyomva a belehallgatáshoz",
  "ListenCount": "{0} lejátszás",
  "ListenReactionMulti": "{0} ismerősöd hallgatta meg",
  "ListenReactionSingle": "{0} már meghallgatta",
  "LocalFile": "Helyi fájl",
  "More": "Több",
  "Pause": "Szünet",
  "Play": "Lejátszás",
  "Playlist": "Lejátszási lista",
  "PressEnterToPlay": "Lejátszás az Enterrel",
  "Popularity": "Népszerűség",
  "Remove": "Eltávolítás",
  "RemoveYourMusic": "Törlés a Zenéid közül",
  "Save": "Mentés",
  "SaveYourMusic": "Mentés a Zenéid közé",
  "Saved": "Mentett",
  "Song": "Dal",
  "StartRadio": "Rádió bekapcsolása",
  "Time": "Idő",
  "Toplist": "Toplista",
  "Track": "Dal",
  "Unfollow": "Nem követem",
  "User": "Felhasználó",
  "ViewAll": "Mindent mutat",
  "HoursShort": "{0} óra",
  "MinutesShort": "{0} perc",
  "SecondsShort": "{0} mp",
  "ErrorTitle": "Egy hiba miatt nem jeleníthető meg ez az oldal",
  "ErrorMessage": "A kért nézet nem létezik, vagy valamilyen műszaki hiba történt.",
  "OfflineTitle": "Ez a nézet internetkapcsolat nélkül nem érhető el.",
  "OfflineMessage": "Csatlakozz az internethez, majd indítsd el."
};
},{}],47:[function(require,module,exports){
module.exports = {
  "Album": "Album",
  "AndMore": "dan {0} lagi",
  "Artist": "Artis",
  "By": "menurut",
  "Create Similar Playlist": "Buat Playlist Serupa",
  "Filter": "Filter",
  "Follow": "Ikuti",
  "Follower": "Pengikut",
  "FollowersLabel": "Pengikut",
  "Following": "Mengikuti",
  "FollowingLabel": "Mengikuti",
  "ListenersLabel": "Pendengar Bulanan",
  "FollowsYou": "Mengikutimu",
  "HoldToPreview": "Klik dan Tahan untuk Pratinjau",
  "ListenCount": "{0} permainan",
  "ListenReactionMulti": "{0} pendengar di jaringanmu",
  "ListenReactionSingle": "{0} mendengarkan ini",
  "LocalFile": "File Lokal",
  "More": "Lainnya",
  "Pause": "Jeda",
  "Play": "Play",
  "Playlist": "Playlist",
  "PressEnterToPlay": "Tekan Enter untuk memainkan",
  "Popularity": "Popularitas",
  "Remove": "Hapus",
  "RemoveYourMusic": "Hapus dari Musik Kamu",
  "Save": "Simpan",
  "SaveYourMusic": "Simpan ke Musik Kamu",
  "Saved": "Tersimpan",
  "Song": "Lagu",
  "StartRadio": "Mulai Radio",
  "Time": "Waktu",
  "Toplist": "Lagu teratas",
  "Track": "Lagu",
  "Unfollow": "Berhenti mengikuti",
  "User": "Pengguna",
  "ViewAll": "Lihat Semua",
  "HoursShort": "{0} jam",
  "MinutesShort": "{0} mnt",
  "SecondsShort": "{0} dtk",
  "ErrorTitle": "Ada masalah saat menampilkan tampilan ini!",
  "ErrorMessage": "Tampilan ini tidak ada atau terjadi kesalahan.",
  "OfflineTitle": "Tampilan ini tidak tersedia offline.",
  "OfflineMessage": "Alihkan ke online untuk memuat."
};
},{}],48:[function(require,module,exports){
module.exports = {
  "Album": "Album",
  "AndMore": "e altri {0}",
  "Artist": "Artista",
  "By": "per",
  "Create Similar Playlist": "Crea playlist simile",
  "Filter": "Filtra",
  "Follow": "Segui",
  "Follower": "Follower",
  "FollowersLabel": "Follower",
  "Following": "Following",
  "FollowingLabel": "Following",
  "ListenersLabel": "Ascoltatori questo mese",
  "FollowsYou": "Ti segue",
  "HoldToPreview": "Tieni premuto per un'anteprima",
  "ListenCount": "{0} riproduzioni",
  "ListenReactionMulti": "{0} ascoltatori nella tua rete",
  "ListenReactionSingle": "{0} ascolta questo",
  "LocalFile": "File locale",
  "More": "Più",
  "Pause": "Pausa",
  "Play": "Play",
  "Playlist": "Playlist",
  "PressEnterToPlay": "Premi Invio per riprodurre",
  "Popularity": "Popolarità",
  "Remove": "Rimuovi",
  "RemoveYourMusic": "Elimina da La tua musica",
  "Save": "Salva",
  "SaveYourMusic": "Salva in La tua musica",
  "Saved": "Salvato",
  "Song": "Brano",
  "StartRadio": "Crea una radio",
  "Time": "Durata",
  "Toplist": "Brani top",
  "Track": "Brano",
  "Unfollow": "Non seguire più",
  "User": "Utente",
  "ViewAll": "Visualizza tutto",
  "HoursShort": "{0} ore",
  "MinutesShort": "{0} min.",
  "SecondsShort": "{0} sec",
  "ErrorTitle": "Si è verificato un errore in questa vista.",
  "ErrorMessage": "La vista non esiste o si è verificato un errore.",
  "OfflineTitle": "Questa vista non è disponibile offline.",
  "OfflineMessage": "Passa online per caricare."
};
},{}],49:[function(require,module,exports){
module.exports = {
  "Album": "アルバム",
  "AndMore": "その他{0}人",
  "Artist": "アーティスト",
  "By": "/",
  "Create Similar Playlist": "同様のプレイリストを作成",
  "Filter": "フィルター",
  "Follow": "フォロー",
  "Follower": "フォロワー",
  "FollowersLabel": "フォロワー",
  "Following": "フォロー中",
  "FollowingLabel": "フォロー中",
  "ListenersLabel": "今月のリスナー",
  "FollowsYou": "あなたをフォローしています",
  "HoldToPreview": "プレビューするには、クリックを押しします",
  "ListenCount": "{0}回再生",
  "ListenReactionMulti": "ネットワーク内で{0}人が聴いています",
  "ListenReactionSingle": "{0}さんはこれを聴いています",
  "LocalFile": "ローカルファイル",
  "More": "詳細",
  "Pause": "一時停止",
  "Play": "曲の再生",
  "Playlist": "プレイリスト",
  "PressEnterToPlay": "再生するにはEnterキーを押します",
  "Popularity": "人気",
  "Remove": "削除",
  "RemoveYourMusic": "My Musicから削除",
  "Save": "保存",
  "SaveYourMusic": "My Musicに保存",
  "Saved": "保存済み",
  "Song": "ソング",
  "StartRadio": "Radioを開始",
  "Time": "時間",
  "Toplist": "トップ曲",
  "Track": "ソング",
  "Unfollow": "フォローをやめる",
  "User": "ユーザー",
  "ViewAll": "すべて表示",
  "HoursShort": "{0} 時間",
  "MinutesShort": "{0} 分",
  "SecondsShort": "{0} 秒",
  "ErrorTitle": "このビューを表示しようとしているときに問題が発生しました。",
  "ErrorMessage": "このビューが存在しないか、エラーが発生しました。",
  "OfflineTitle": "このページはオフラインで表示できません。",
  "OfflineMessage": "ロードするには、インターネットに接続してください。"
};
},{}],50:[function(require,module,exports){
module.exports = {
  "Album": "Album",
  "AndMore": "en {0} meer",
  "Artist": "Artiest",
  "By": "van",
  "Create Similar Playlist": "Vergelijkbare afspeellijst maken",
  "Filter": "Filter",
  "Follow": "Volgen",
  "Follower": "Volger",
  "FollowersLabel": "Volgers",
  "Following": "Volgend",
  "FollowingLabel": "Volgend",
  "ListenersLabel": "Luisteraars per maand",
  "FollowsYou": "Volgt jou",
  "HoldToPreview": "Klikken en vasthouden om een stukje te horen",
  "ListenCount": "{0} keer afgespeeld",
  "ListenReactionMulti": "{0} luisteraars in jouw netwerk",
  "ListenReactionSingle": "{0} luistert hiernaar",
  "LocalFile": "Lokaal bestand",
  "More": "Meer",
  "Pause": "Pauze",
  "Play": "Afspelen",
  "Playlist": "Afspeellijst",
  "PressEnterToPlay": "Druk op Enter om af te spelen",
  "Popularity": "Populariteit",
  "Remove": "Verwijderen",
  "RemoveYourMusic": "Verwijderen uit Jouw Muziek",
  "Save": "Opslaan",
  "SaveYourMusic": "Opslaan in Jouw Muziek",
  "Saved": "Opgeslagen",
  "Song": "Nummer",
  "StartRadio": "Radio starten",
  "Time": "Tijd",
  "Toplist": "Topnummers",
  "Track": "Nummer",
  "Unfollow": "Niet meer volgen",
  "User": "Gebruiker",
  "ViewAll": "Alles bekijken",
  "HoursShort": "{0} uur",
  "MinutesShort": "{0} min",
  "SecondsShort": "{0} sec",
  "ErrorTitle": "Er is een fout opgetreden bij het laden van deze weergave.",
  "ErrorMessage": "Deze weergave bestaat niet of er is een fout opgetreden.",
  "OfflineTitle": "Deze weergave is offline niet beschikbaar!",
  "OfflineMessage": "Ga online om te laden."
};
},{}],51:[function(require,module,exports){
module.exports = {
  "Album": "Album",
  "AndMore": "i {0} więcej",
  "Artist": "Wykonawca",
  "By": "według",
  "Create Similar Playlist": "Utwórz podobną playlistę",
  "Filter": "Filtruj",
  "Follow": "Obserwuj",
  "Follower": "Obserwujący",
  "FollowersLabel": "Obserwatorzy",
  "Following": "Obserwowana",
  "FollowingLabel": "Obserwowana",
  "ListenersLabel": "Słuchacze w tym miesiącu",
  "FollowsYou": "Obserwuje Cię",
  "HoldToPreview": "Aby odsłuchać, kliknij i przytrzymaj.",
  "ListenCount": "Liczba odtworzeń: {0}",
  "ListenReactionMulti": "Liczba słuchaczy w Twojej sieci: {0}",
  "ListenReactionSingle": "Użytkownik {0} słucha tego",
  "LocalFile": "Plik lokalny",
  "More": "Więcej",
  "Pause": "Pauza",
  "Play": "Odtwórz",
  "Playlist": "Playlista",
  "PressEnterToPlay": "Naciśnij Enter, aby odtworzyć",
  "Popularity": "Popularność",
  "Remove": "Usuń",
  "RemoveYourMusic": "Usuń z kolekcji Twoja muzyka",
  "Save": "Zapisz",
  "SaveYourMusic": "Zapisz w kolekcji Twoja muzyka",
  "Saved": "Zapisany",
  "Song": "Utwór",
  "StartRadio": "Włącz radio",
  "Time": "Czas",
  "Toplist": "Najpopularniejsze utwory",
  "Track": "Utwór",
  "Unfollow": "Przestań obserwować",
  "User": "Użytkownik",
  "ViewAll": "Wyświetl wszystko",
  "HoursShort": "{0} godz.",
  "MinutesShort": "{0} min",
  "SecondsShort": "{0} s",
  "ErrorTitle": "Podczas wyświetlania tego widoku wystąpił błąd!",
  "ErrorMessage": "Ten widok nie istnieje lub wystąpił błąd.",
  "OfflineTitle": "Ten widok jest niedostępny w trybie offline. ",
  "OfflineMessage": "Przejdź do trybu online, aby załadować."
};
},{}],52:[function(require,module,exports){
module.exports = {
  "Album": "Álbum",
  "AndMore": "e mais {0}",
  "Artist": "Artista",
  "By": "de",
  "Create Similar Playlist": "Criar playlist similar",
  "Filter": "Filtrar",
  "Follow": "Seguir",
  "Follower": "Seguidor",
  "FollowersLabel": "Seguidores",
  "Following": "Seguindo",
  "FollowingLabel": "Seguindo",
  "ListenersLabel": "Ouvintes mensais",
  "FollowsYou": "Segue você",
  "HoldToPreview": "Clique e segure para a prévia",
  "ListenCount": "{0} reproduções",
  "ListenReactionMulti": "{0} ouvintes na sua rede",
  "ListenReactionSingle": "{0} ouvem isso",
  "LocalFile": "Arquivo local",
  "More": "Mais",
  "Pause": "Pause",
  "Play": "Play",
  "Playlist": "Playlist",
  "PressEnterToPlay": "Pressione Enter para tocar",
  "Popularity": "Popularidade",
  "Remove": "Remover",
  "RemoveYourMusic": "Remover de Suas músicas",
  "Save": "Salvar",
  "SaveYourMusic": "Salvar em Suas músicas",
  "Saved": "Salvo",
  "Song": "Música",
  "StartRadio": "Abrir rádio",
  "Time": "Tempo",
  "Toplist": "Músicas mais tocadas",
  "Track": "Música",
  "Unfollow": "Deixar de seguir",
  "User": "Usuário",
  "ViewAll": "Ver tudo",
  "HoursShort": "{0} h",
  "MinutesShort": "{0} m",
  "SecondsShort": "{0} s",
  "ErrorTitle": "Tivemos um problema ao mostrar esta exibição!",
  "ErrorMessage": "A exibição não existe ou ocorreu um erro.",
  "OfflineTitle": "Essa visualização não está disponível offline!",
  "OfflineMessage": "Fique online para carregar."
};
},{}],53:[function(require,module,exports){
module.exports = {
  "Album": "Album",
  "AndMore": "och {0} till",
  "Artist": "Artist",
  "By": "av",
  "Create Similar Playlist": "Skapa en liknande spellista",
  "Filter": "Filtrera",
  "Follow": "Följ",
  "Follower": "Följare",
  "FollowersLabel": "Följare",
  "Following": "Följer",
  "FollowingLabel": "Följer",
  "ListenersLabel": "Lyssnare per månad",
  "FollowsYou": "Följer dig",
  "HoldToPreview": "Klicka och håll kvar för att förhandslyssna",
  "ListenCount": "{0} uppspelningar",
  "ListenReactionMulti": "{0} lyssnare i ditt nätverk",
  "ListenReactionSingle": "{0} lyssnar på detta",
  "LocalFile": "Lokal fil",
  "More": "Mer",
  "Pause": "Pausa",
  "Play": "Spela upp",
  "Playlist": "Spellista",
  "PressEnterToPlay": "Tryck på Retur om du vill lyssna",
  "Popularity": "Popularitet",
  "Remove": "Ta bort",
  "RemoveYourMusic": "Ta bort från Din Musik",
  "Save": "Spara",
  "SaveYourMusic": "Spara i Din Musik",
  "Saved": "Sparade",
  "Song": "Låt",
  "StartRadio": "Starta radio",
  "Time": "Tid",
  "Toplist": "Topplåtar",
  "Track": "Låt",
  "Unfollow": "Sluta följa",
  "User": "Användare",
  "ViewAll": "Visa alla",
  "HoursShort": "{0} tim",
  "MinutesShort": "{0} min",
  "SecondsShort": "{0} sek",
  "ErrorTitle": "Det uppstod ett fel när den här vyn skulle visas!",
  "ErrorMessage": "Den här vyn finns inte eller så uppstod ett fel.",
  "OfflineTitle": "Den här vyn är inte tillgänglig offline.",
  "OfflineMessage": "Anslut till internet om du vill läsa in appen."
};
},{}],54:[function(require,module,exports){
module.exports = {
  "Album": "Albüm",
  "AndMore": "ve {0} daha",
  "Artist": "Sanatçı",
  "By": "-",
  "Create Similar Playlist": "Benzer Çalma Listesi Oluştur",
  "Filter": "Filtrele",
  "Follow": "Takip Et",
  "Follower": "Takipçi",
  "FollowersLabel": "Takipçiler",
  "Following": "Takip Ediliyor",
  "FollowingLabel": "Takip Ediliyor",
  "ListenersLabel": "Aylık Dinleyici",
  "FollowsYou": "Seni Takip Ediyor",
  "HoldToPreview": "Basılı Tut ve Önizle",
  "ListenCount": "{0} dinleme",
  "ListenReactionMulti": "Ağında {0} dinleyici",
  "ListenReactionSingle": "{0} bunu dinliyor",
  "LocalFile": "Yerel Dosya",
  "More": "Daha fazla",
  "Pause": "Duraklat",
  "Play": "Çal",
  "Playlist": "Çalma listesi",
  "PressEnterToPlay": "Çalmak için Enter'a bas",
  "Popularity": "Popülerlik",
  "Remove": "Çıkar",
  "RemoveYourMusic": "Müziklerin'den çıkar",
  "Save": "Kaydet",
  "SaveYourMusic": "Müziklerin'e kaydet",
  "Saved": "Kaydedildi",
  "Song": "Şarkı",
  "StartRadio": "Radyoyu Başlat",
  "Time": "Saat",
  "Toplist": "En çok dinlenen şarkılar",
  "Track": "Şarkı",
  "Unfollow": "Takip Etmeyi Bırak",
  "User": "Kullanıcı",
  "ViewAll": "Tümünü Görüntüle",
  "HoursShort": "{0} sa",
  "MinutesShort": "{0} dk",
  "SecondsShort": "{0} sn",
  "ErrorTitle": "Bu öğe görüntülenirken bir sorun oluştu!",
  "ErrorMessage": "Bu görünüm yok veya bir hata oluştu.",
  "OfflineTitle": "Bu görünüm çevrimdışıyken kullanılamaz!",
  "OfflineMessage": "Yüklemek için lütfen çevrimiçi ol."
};
},{}],55:[function(require,module,exports){
module.exports = {
  "Album": "專輯",
  "AndMore": "還有 {0} 首",
  "Artist": "藝人",
  "By": "－",
  "Create Similar Playlist": "建立相似的播放清單",
  "Filter": "篩選",
  "Follow": "關注",
  "Follower": "粉絲",
  "FollowersLabel": "關注者",
  "Following": "正在關注",
  "FollowingLabel": "正在關注",
  "ListenersLabel": "每月聽眾",
  "FollowsYou": "關注你",
  "HoldToPreview": "按住即可預覽",
  "ListenCount": "播放了 {0} 次",
  "ListenReactionMulti": "在你的社群網路中有 {0} 名聽眾",
  "ListenReactionSingle": "{0} 收聽了這首歌曲",
  "LocalFile": "本機檔案",
  "More": "更多",
  "Pause": "暫停",
  "Play": "播放",
  "Playlist": "播放列表",
  "PressEnterToPlay": "請按 Enter 播放",
  "Popularity": "流行",
  "Remove": "移除",
  "RemoveYourMusic": "從你的音樂中移除",
  "Save": "儲存",
  "SaveYourMusic": "儲存至你的音樂",
  "Saved": "已儲存",
  "Song": "歌曲",
  "StartRadio": "啟用電臺",
  "Time": "時間",
  "Toplist": "當紅歌曲",
  "Track": "歌曲",
  "Unfollow": "取消關注",
  "User": "使用者",
  "ViewAll": "檢視全部",
  "HoursShort": "{0} 小時",
  "MinutesShort": "{0} 分鐘",
  "SecondsShort": "{0} 秒鐘",
  "ErrorTitle": "顯示這個畫面時出現問題。",
  "ErrorMessage": "這個畫面可能不存在或發生錯誤。",
  "OfflineTitle": "離線時無法使用這個檢視！",
  "OfflineMessage": "請上網以載入。"
};
},{}],56:[function(require,module,exports){
module.exports = {
  "Album": "Album",
  "AndMore": "dan {0} lagi",
  "Artist": "Artis",
  "By": "oleh",
  "Create Similar Playlist": "Cipta Senarai Main Serupa",
  "Filter": "Penapis",
  "Follow": "Ikut",
  "Follower": "Pengikut",
  "FollowersLabel": "Pengikut",
  "Following": "Mengikuti",
  "FollowingLabel": "Mengikuti",
  "ListenersLabel": "Pendengar Bulanan",
  "FollowsYou": "Megikuti Anda",
  "HoldToPreview": "Klik dan Tahan untuk Pratonton",
  "ListenCount": "{0} main",
  "ListenReactionMulti": "{0} pendengar dalam rangkaian anda",
  "ListenReactionSingle": "{0} mendengar ini",
  "LocalFile": "Fail Setempat",
  "More": "Lebih banyak",
  "Pause": "Jeda",
  "Play": "Main",
  "Playlist": "Senarai main",
  "PressEnterToPlay": "Tekan Enter untuk main",
  "Popularity": "Populariti",
  "Remove": "Keluarkan",
  "RemoveYourMusic": "Keluarkan daripada Muzik Anda",
  "Save": "Simpan",
  "SaveYourMusic": "Simpan ke Muzik Anda",
  "Saved": "Disimpan",
  "Song": "Lagu",
  "StartRadio": "Mulakan Radio",
  "Time": "Masa",
  "Toplist": "Lagu popular",
  "Track": "Lagu",
  "Unfollow": "Nyahikut",
  "User": "Pengguna",
  "ViewAll": "Lihat Semua",
  "HoursShort": "{0} jam",
  "MinutesShort": "{0} min",
  "SecondsShort": "{0} saat",
  "ErrorTitle": "Terdapat masalah memaparkan paparan ini!",
  "ErrorMessage": "Paparan ini sama ada tidak wujud atau ralat berlaku.",
  "OfflineTitle": "Paparan ini tidak tersedia di luar talian!",
  "OfflineMessage": "Sila ke online untuk memuatkan."
};
},{}],57:[function(require,module,exports){
'use strict';

exports.getVersion = require('./src/version').getVersion;
exports.gridOverlay = require('./src/gridOverlay');

},{"./src/gridOverlay":58,"./src/version":59}],58:[function(require,module,exports){
(function (global){
'use strict';

var cosmos = require('spotify-cosmos-api');

var DEFAULT_GRID_COLOR = 'rgba(251, 74, 131, 0.22)';
var DEFAULT_GRID_COLOR_HIGHLIGHT = 'rgba(251, 74, 131, 0.8)';
var GRID_BASELINE = 8;

var overlayElement = null;
var baselineHighlightElement = null;
var gridColor = '';
var highlightGridColor = '';
var gridModes = ['off', 'column', 'baseline'];
var currentModeIndex = 0;

/**
 * Listen for control messages to toggle the grid when a menu item is clicked
 * or a keyboard shortcut is pressed. This only happens if the user is a global
 * app developer.
 */
function listen() {
  var spotify = global.__spotify;
  var productState = spotify && spotify.product_state;
  var appDeveloperFlag = productState && productState['app-developer'];

  if (appDeveloperFlag === '3' || appDeveloperFlag === '7') {
    cosmos.resolver.subscribe({
      url: 'sp://messages/v1/container/control'
    }, function (error, response) {
      if (error) return;
      var data = response.getJSONBody();
      if (data && data.type === 'toggle_grid') {
        toggle();
      }
    });
  }
}

/**
 * Toggle the grid overlay.
 */
function toggle() {
  var newIndex = currentModeIndex + 1;
  if (newIndex > gridModes.length - 1) {
    newIndex = 0;
  }

  var mode = gridModes[newIndex];

  if (mode === 'off') {
    disable();
  } else {
    enable(mode);
  }
}

/**
 * Enable the grid overlay.
 *
 * @param {string} mode The grid mode to enable, 'column' or 'baseline'.
 */
function enable(mode) {
  if (!mode) {
    return;
  }

  if (gridModes[currentModeIndex] === mode) {
    return;
  }

  currentModeIndex = gridModes.indexOf(mode);

  if (overlayElement && overlayElement.parentNode) {
    overlayElement.parentNode.removeChild(overlayElement);
  }

  if (mode === 'baseline') {
    document.addEventListener('mousemove', onMouseMove, false);
  }

  overlayElement = createOverlayElement();

  document.body.appendChild(overlayElement);
}

/**
 * Disable the grid overlay.
 */
function disable() {
  if (gridModes[currentModeIndex] === 'off') {
    return;
  }

  if (overlayElement && overlayElement.parentNode) {
    overlayElement.parentNode.removeChild(overlayElement);
  }

  currentModeIndex = gridModes.indexOf('off');
  overlayElement = null;
  baselineHighlightElement = null;

  document.removeEventListener('mousemove', onMouseMove, false);
}

/**
 * Set the color used for each grid column or baseline line.
 *
 * @param {string} color Any valid CSS color.
 * @param {string=} highlightColor Any valid CSS color. Can be omitted for
 *     column grid.
 */
function setColor(color, highlightColor) {
  gridColor = color;
  highlightGridColor = highlightColor;
}

/**
 * Reset all state in this module.
 */
function reset() {
  overlayElement = null;
  baselineHighlightElement = null;
  gridColor = '';
  highlightGridColor = '';
  currentModeIndex = 0;
}

/**
 * Mouse move handler that highlights the hovered baseline line.
 *
 * @param {Event} event A mousemove event object.
 *
 * @private
 */
function onMouseMove(event) {
  if (!baselineHighlightElement) {
    baselineHighlightElement = document.createElement('div');
    baselineHighlightElement.className = 'grid-overlay-baseline-highlight';
    baselineHighlightElement.style.backgroundColor = highlightGridColor || DEFAULT_GRID_COLOR_HIGHLIGHT;
    overlayElement.appendChild(baselineHighlightElement);
  }

  // Calculate the Y position for the baseline line closest to the pointer
  var pointerPos = event.clientY + window.scrollY;
  var yLineAbove = Math.floor(pointerPos / GRID_BASELINE) * GRID_BASELINE;
  var y = yLineAbove + (pointerPos % GRID_BASELINE > 4 ? GRID_BASELINE : 0);

  baselineHighlightElement.style.top = y - 1 + 'px';
}

/**
 * Create the DOM nodes needed for the overlay, with the correct class names
 * and styles.
 *
 * @return {HTMLElement} The container element for the overlay.
 *
 * @private
 */
function createOverlayElement() {
  var color = gridColor || DEFAULT_GRID_COLOR;

  var container = document.createElement('div');
  container.className = 'grid-overlay container';

  if (gridModes[currentModeIndex] === 'column') {
    var row = document.createElement('div');
    row.className = 'grid-overlay-row row';
    container.appendChild(row);

    var sizeLabel = createSizeLabel();
    container.appendChild(sizeLabel);

    var columnClassNames = 'col-xs-1 col-sm-1 col-md-1 col-lg-1';

    for (var i = 0; i < 12; i++) {
      var column = document.createElement('div');
      column.className = 'grid-overlay-col-' + (i + 1) + ' ' + columnClassNames;

      column.style.backgroundColor = color;

      row.appendChild(column);
    }
  } else if (gridModes[currentModeIndex] === 'baseline') {
    container.classList.add('grid-overlay-baseline');

    var baselinePercentage = (GRID_BASELINE - 1) / GRID_BASELINE * 100 + '%';

    var backgroundImage = ['linear-gradient(', 'to bottom, ', 'transparent, ', 'transparent ' + baselinePercentage + ', ', color + ' ' + baselinePercentage, ')'].join('');

    container.style.backgroundImage = backgroundImage;

    // Because JSDOM is using the package 'cssstyle', which is stupid and
    // doesn't support gradients as values...
    container.style._backgroundImage = backgroundImage;
  }

  return container;
}

/**
 * Create the DOM nodes needed for the grid size label.
 *
 * @return {HTMLElement} A DOM node.
 *
 * @private
 */
function createSizeLabel() {
  var sizes = [{ name: 'Extra Small', id: 'xs' }, { name: 'Small', id: 'sm' }, { name: 'Medium', id: 'md' }, { name: 'Large', id: 'lg' }];

  var labelContainer = document.createElement('div');
  labelContainer.className = 'grid-overlay-label';

  sizes.forEach(function (size) {
    var label = document.createElement('span');
    label.className = 'visible-' + size.id;
    label.textContent = size.name;
    labelContainer.appendChild(label);
  });

  return labelContainer;
}

exports.listen = listen;
exports.toggle = toggle;
exports.enable = enable;
exports.disable = disable;
exports.setColor = setColor;
exports.reset = reset;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"spotify-cosmos-api":112}],59:[function(require,module,exports){
'use strict';

// This should be removed later when nothing is calling this method

exports.getVersion = function () {
  return 1;
};

},{}],60:[function(require,module,exports){
'use strict';

module.exports = {
  'de': require('../i18n/de.lang'),
  'el': require('../i18n/el.lang'),
  'en': require('../i18n/en.lang'),
  'es': require('../i18n/es.lang'),
  'es-419': require('../i18n/es-419.lang'),
  'fi': require('../i18n/fi.lang'),
  'fr': require('../i18n/fr.lang'),
  'fr-CA': require('../i18n/fr-CA.lang'),
  'hu': require('../i18n/hu.lang'),
  'id': require('../i18n/id.lang'),
  'it': require('../i18n/it.lang'),
  'ja': require('../i18n/ja.lang'),
  'nl': require('../i18n/nl.lang'),
  'pl': require('../i18n/pl.lang'),
  'pt-BR': require('../i18n/pt-BR.lang'),
  'sv': require('../i18n/sv.lang'),
  'tr': require('../i18n/tr.lang'),
  'zh-Hant': require('../i18n/zh-Hant.lang'),
  'zsm': require('../i18n/zsm.lang')
};

},{"../i18n/de.lang":38,"../i18n/el.lang":39,"../i18n/en.lang":40,"../i18n/es-419.lang":41,"../i18n/es.lang":42,"../i18n/fi.lang":43,"../i18n/fr-CA.lang":44,"../i18n/fr.lang":45,"../i18n/hu.lang":46,"../i18n/id.lang":47,"../i18n/it.lang":48,"../i18n/ja.lang":49,"../i18n/nl.lang":50,"../i18n/pl.lang":51,"../i18n/pt-BR.lang":52,"../i18n/sv.lang":53,"../i18n/tr.lang":54,"../i18n/zh-Hant.lang":55,"../i18n/zsm.lang":56}],61:[function(require,module,exports){
'use strict';

var isNumber = require('mout/lang/isNumber');

/**
 * If the first argument is a number, pipe it through spotify-numeral with an
 * optional format propety in the options hash, otherwise return it untouched.
 *
 * Example usage – results when using fr locale:
 *
 * {{numeral 1000}} -> '1 000'
 * {{numeral 1000 format='0,0.000'}} -> '1 000,000'
 * {{numeral 1000 format='$0,0.00'}} -> '€1 000,00'
 *
 * @param {Number|String} number - The number to format (or string to leave
 *     untouched).
 * @param {Object} [options] - The handlebars options object.
 * @param {Object} [options.hash] - The handlebars options hash object.
 * @param {String} [options.hash.format] - The optional format to pass to
 *     numeraljs.
 * @return {String} The formatted (or untouched) string.
 */
var numeralHelper = function numeralHelper(number, options) {
  var format = options && options.hash && options.hash.format;
  var numeral = numeralHelper._numeral;
  return isNumber(number) ? numeral(number).format(format) : number;
};

numeralHelper.displayName = 'numeral';

module.exports = numeralHelper;

// This is tricky, but is a way to allow for the locale to be injected
// from the consuming app instead of from within spotify-numeral, removing
// the dependency on spotify-quickstart.
module.exports.setLocale = function (locale) {
  numeralHelper._numeral = require('../../spotify-numeral')(locale);
};

},{"../../spotify-numeral":66,"mout/lang/isNumber":95}],62:[function(require,module,exports){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol ? "symbol" : typeof obj; };

var Translations = require('../spotify-translations');
var glueLocales = require('../spotify-glue-cat/strings');

module.exports = function (localeToStrings) {
  if (!localeToStrings || (typeof localeToStrings === 'undefined' ? 'undefined' : _typeof(localeToStrings)) !== 'object') {
    throw new Error('' + 'Locale strings must be a plain object. ' + 'See spotify-i18n/README.md');
  }

  function getClientLocale() {
    return typeof window !== 'undefined' && window.__spotify && window.__spotify.locale || 'en';
  }

  var locales = localeToStrings;
  var i18n = new Translations();
  i18n.injectData(locales[getClientLocale()] || {});

  return {
    locale: getClientLocale,
    get: i18n.get.bind(i18n),

    glueStrings: function glueStrings() {
      return glueLocales[getClientLocale()];
    },

    appStrings: function appStrings() {
      return locales[getClientLocale()];
    }
  };
};

},{"../spotify-glue-cat/strings":60,"../spotify-translations":82}],63:[function(require,module,exports){
'use strict';

var languages = require('./languages.json');

function lookup(language, to) {
  var lang = languages[language];
  if (lang[to]) {
    return lang[to];
  } else {
    return language;
  }
}

module.exports = lookup;
module.exports.all = function () {
  return Object.keys(languages);
};

},{"./languages.json":64}],64:[function(require,module,exports){
module.exports={
  "de": {
    "smartling": "de-DE"
  },
  "el": {
    "smartling": "el-GR"
  },
  "en": {
    "smartling": "en-GB"
  },
  "es": {
    "numeral": "es-ES",
    "smartling": "es-ES"
  },
  "es-419": {
    "moment": "es",
    "numeral": "es-ES",
    "smartling": "es-LA"
  },
  "fi": {
    "smartling": "fi-FI"
  },
  "fr": {
    "smartling": "fr-FR"
  },
  "fr-CA": {
    "smartling": "fr-CA",
    "moment": "fr-ca"
  },
  "hu": {
    "smartling": "hu-HU"
  },
  "id": {
    "smartling": "id-ID"
  },
  "it": {
    "smartling": "it-IT"
  },
  "ja": {
    "smartling": "ja-JP"
  },
  "nl": {
    "numeral": "nl-nl",
    "smartling": "nl-NL"
  },
  "pl": {
    "smartling": "pl-PL"
  },
  "pt-BR": {
    "moment": "pt-br",
    "numeral": "pt-br",
    "smartling": "pt-BR"
  },
  "sv": {
    "smartling": "sv-SE"
  },
  "tr": {
    "smartling": "tr-TR"
  },
  "zh-Hant": {
    "moment": "zh-tw",
    "smartling": "zh-TW"
  },
  "zsm": {
    "moment": "ms-my",
    "smartling": "ms-MY"
  }
}
},{}],65:[function(require,module,exports){
'use strict';

module.exports = function (numeral) {
  return {
    delimiters: {
      thousands: ',',
      decimal: '.'
    },
    abbreviations: {
      thousand: 'k',
      million: 'm',
      billion: 'b',
      trillion: 't'
    },
    ordinal: function ordinal(number) {
      var b = number % 10;
      return ~~(number % 100 / 10) === 1 ? 'th' : b === 1 ? 'st' : b === 2 ? 'nd' : b === 3 ? 'rd' : 'th';
    },
    currency: {
      symbol: '$'
    }
  };
};

},{}],66:[function(require,module,exports){
'use strict';

var numeral = require('./numeraljs/numeral');
var locales = require('../spotify-locales');

module.exports = function (currentLanguage) {

  // We need to explicitly require all languages listed in spotify-locales
  // so that Quickstart can access them at runtime
  // (dynamic paths can't be cached).
  var languages = {
    'de': require('./numeraljs/languages/de'),
    // Custom en.js file
    'en': require('./en')(numeral),
    // es-419 falls back to es-es in Numeral.js
    'es-ES': require('./numeraljs/languages/es-ES'),
    'fi': require('./numeraljs/languages/fi'),
    'fr': require('./numeraljs/languages/fr'),
    'fr-CA': require('./numeraljs/languages/fr-CA'),
    'hu': require('./numeraljs/languages/hu'),
    'id': require('./numeraljs/languages/id'),
    'it': require('./numeraljs/languages/it'),
    'ja': require('./numeraljs/languages/ja'),
    'nl-nl': require('./numeraljs/languages/nl-nl'),
    'pl': require('./numeraljs/languages/pl'),
    'pt-br': require('./numeraljs/languages/pt-br'),
    'sv': require('./numeraljs/languages/sv'),
    'tr': require('./numeraljs/languages/tr')
  };

  var numeralLocale = locales(currentLanguage, 'numeral');
  if (!languages[numeralLocale]) {
    numeralLocale = 'en';
  }
  numeral.language(numeralLocale, languages[numeralLocale]);
  numeral.language(numeralLocale);

  return numeral;
};

},{"../spotify-locales":63,"./en":65,"./numeraljs/languages/de":67,"./numeraljs/languages/es-ES":68,"./numeraljs/languages/fi":69,"./numeraljs/languages/fr":71,"./numeraljs/languages/fr-CA":70,"./numeraljs/languages/hu":72,"./numeraljs/languages/id":73,"./numeraljs/languages/it":74,"./numeraljs/languages/ja":75,"./numeraljs/languages/nl-nl":76,"./numeraljs/languages/pl":77,"./numeraljs/languages/pt-br":78,"./numeraljs/languages/sv":79,"./numeraljs/languages/tr":80,"./numeraljs/numeral":81}],67:[function(require,module,exports){
'use strict';

/*!
 * numeral.js language configuration
 * language : German (de) – generally useful in Germany, Austria, Luxembourg, Belgium
 * author : Marco Krage : https://github.com/sinky
 */
(function () {
    var language = {
        delimiters: {
            thousands: '.',
            decimal: ','
        },
        abbreviations: {
            thousand: 'k',
            million: 'm',
            billion: 'b',
            trillion: 't'
        },
        ordinal: function ordinal(number) {
            return '.';
        },
        currency: {
            symbol: '€'
        }
    };

    // Node
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = language;
    }
})();

},{}],68:[function(require,module,exports){
'use strict';

/*!
 * numeral.js language configuration
 * language : spanish Spain
 * author : Hernan Garcia : https://github.com/hgarcia
 */
(function () {
    var language = {
        delimiters: {
            thousands: '.',
            decimal: ','
        },
        abbreviations: {
            thousand: 'k',
            million: 'mm',
            billion: 'b',
            trillion: 't'
        },
        ordinal: function ordinal(number) {
            var b = number % 10;
            return b === 1 || b === 3 ? 'er' : b === 2 ? 'do' : b === 7 || b === 0 ? 'mo' : b === 8 ? 'vo' : b === 9 ? 'no' : 'to';
        },
        currency: {
            symbol: '€'
        }
    };

    // Node
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = language;
    }
})();

},{}],69:[function(require,module,exports){
'use strict';

/*!
 * numeral.js language configuration
 * language : Finnish
 * author : Sami Saada : https://github.com/samitheberber
 */
(function () {
    var language = {
        delimiters: {
            thousands: ' ',
            decimal: ','
        },
        abbreviations: {
            thousand: 'k',
            million: 'M',
            billion: 'G',
            trillion: 'T'
        },
        ordinal: function ordinal(number) {
            return '.';
        },
        currency: {
            symbol: '€'
        }
    };

    // Node
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = language;
    }
})();

},{}],70:[function(require,module,exports){
'use strict';

/*!
 * numeral.js language configuration
 * language : french (Canada) (fr-CA)
 * author : Léo Renaud-Allaire : https://github.com/renaudleo
 */
(function () {
    var language = {
        delimiters: {
            thousands: ' ',
            decimal: ','
        },
        abbreviations: {
            thousand: 'k',
            million: 'M',
            billion: 'G',
            trillion: 'T'
        },
        ordinal: function ordinal(number) {
            return number === 1 ? 'er' : 'e';
        },
        currency: {
            symbol: '$'
        }
    };

    // Node
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = language;
    }
})();

},{}],71:[function(require,module,exports){
'use strict';

/*!
 * numeral.js language configuration
 * language : french (fr)
 * author : Adam Draper : https://github.com/adamwdraper
 */
(function () {
    var language = {
        delimiters: {
            thousands: ' ',
            decimal: ','
        },
        abbreviations: {
            thousand: 'k',
            million: 'm',
            billion: 'b',
            trillion: 't'
        },
        ordinal: function ordinal(number) {
            return number === 1 ? 'er' : 'e';
        },
        currency: {
            symbol: '€'
        }
    };

    // Node
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = language;
    }
})();

},{}],72:[function(require,module,exports){
'use strict';

/*!
 * numeral.js language configuration
 * language : Hungarian (hu)
 * author : Peter Bakondy : https://github.com/pbakondy
 */
(function () {
    var language = {
        delimiters: {
            thousands: ' ',
            decimal: ','
        },
        abbreviations: {
            thousand: 'E', // ezer
            million: 'M', // millió
            billion: 'Mrd', // milliárd
            trillion: 'T' // trillió
        },
        ordinal: function ordinal(number) {
            return '.';
        },
        currency: {
            symbol: ' Ft'
        }
    };

    // Node
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = language;
    }
})();

},{}],73:[function(require,module,exports){
'use strict';

/*!
 * numeral.js language configuration
 * language : Indonesian (id)
 */
(function () {
    var language = {
        delimiters: {
            thousands: ',',
            decimal: '.'
        },
        abbreviations: {
            thousand: 'ribu',
            million: 'juta',
            billion: 'miliar',
            trillion: 'triliun'
        },
        ordinal: function ordinal(number) {
            // According to Spotify's internal Indonesian specialist,
            // there is no ordinal symbol in Indonesian (like st, nd, th, º, ª),
            // they just use the word (equivalent to writing: first, second,
            // third, instead of 1st, 2nd, 3rd). And as we don't have such
            // capability to translate all numbers to words, this function
            // returns an empty string and wherever there's a ordinal, it will
            // just show up as the cardinal number.
            return '';
        },
        currency: {
            symbol: 'Rp'
        }
    };

    // Node
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = language;
    }
})();

},{}],74:[function(require,module,exports){
'use strict';

/*!
 * numeral.js language configuration
 * language : italian Italy (it)
 * author : Giacomo Trombi : http://cinquepunti.it
 */
(function () {
    var language = {
        delimiters: {
            thousands: '.',
            decimal: ','
        },
        abbreviations: {
            thousand: 'mila',
            million: 'mil',
            billion: 'b',
            trillion: 't'
        },
        ordinal: function ordinal(number) {
            return 'º';
        },
        currency: {
            symbol: '€'
        }
    };

    // Node
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = language;
    }
})();

},{}],75:[function(require,module,exports){
'use strict';

/*!
 * numeral.js language configuration
 * language : japanese
 * author : teppeis : https://github.com/teppeis
 */
(function () {
    var language = {
        delimiters: {
            thousands: ',',
            decimal: '.'
        },
        abbreviations: {
            thousand: '千',
            million: '百万',
            billion: '十億',
            trillion: '兆'
        },
        ordinal: function ordinal(number) {
            return '.';
        },
        currency: {
            symbol: '¥'
        }
    };

    // Node
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = language;
    }
})();

},{}],76:[function(require,module,exports){
'use strict';

/*!
 * numeral.js language configuration
 * language : netherlands-dutch (nl-nl)
 * author : Dave Clayton : https://github.com/davedx
 */
(function () {
    var language = {
        delimiters: {
            thousands: '.',
            decimal: ','
        },
        abbreviations: {
            thousand: 'k',
            million: 'mln',
            billion: 'mrd',
            trillion: 'bln'
        },
        ordinal: function ordinal(number) {
            var remainder = number % 100;
            return number !== 0 && remainder <= 1 || remainder === 8 || remainder >= 20 ? 'ste' : 'de';
        },
        currency: {
            symbol: '€ '
        }
    };

    // Node
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = language;
    }
})();

},{}],77:[function(require,module,exports){
'use strict';

/*!
 * numeral.js language configuration
 * language : polish (pl)
 * author : Dominik Bulaj : https://github.com/dominikbulaj
 */
(function () {
    var language = {
        delimiters: {
            thousands: ' ',
            decimal: ','
        },
        abbreviations: {
            thousand: 'tys.',
            million: 'mln',
            billion: 'mld',
            trillion: 'bln'
        },
        ordinal: function ordinal(number) {
            return '.';
        },
        currency: {
            symbol: 'PLN'
        }
    };

    // Node
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = language;
    }
})();

},{}],78:[function(require,module,exports){
'use strict';

/*!
 * numeral.js language configuration
 * language : portuguese brazil (pt-br)
 * author : Ramiro Varandas Jr : https://github.com/ramirovjr
 */
(function () {
    var language = {
        delimiters: {
            thousands: '.',
            decimal: ','
        },
        abbreviations: {
            thousand: 'mil',
            million: 'milhões',
            billion: 'b',
            trillion: 't'
        },
        ordinal: function ordinal(number) {
            return 'º';
        },
        currency: {
            symbol: 'R$'
        }
    };

    // Node
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = language;
    }
})();

},{}],79:[function(require,module,exports){
'use strict';

/*!
 * numeral.js language configuration
 * language : swedish
 * author :
 */
(function () {
    var language = {
        delimiters: {
            thousands: ' ',
            decimal: ','
        },
        abbreviations: {
            thousand: 't',
            million: 'mn',
            billion: 'md',
            trillion: 'bn'
        },
        ordinal: function ordinal(number) {
            return '.';
        },
        currency: {
            symbol: 'SEK'
        }
    };

    // Node
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = language;
    }
})();

},{}],80:[function(require,module,exports){
'use strict';

/*!
 * numeral.js language configuration
 * language : turkish (tr)
 * author : Ecmel Ercan : https://github.com/ecmel, Erhan Gundogan : https://github.com/erhangundogan, Burak Yiğit Kaya: https://github.com/BYK
 */
(function () {
    var suffixes = {
        1: '\'inci',
        5: '\'inci',
        8: '\'inci',
        70: '\'inci',
        80: '\'inci',

        2: '\'nci',
        7: '\'nci',
        20: '\'nci',
        50: '\'nci',

        3: '\'üncü',
        4: '\'üncü',
        100: '\'üncü',

        6: '\'ncı',

        9: '\'uncu',
        10: '\'uncu',
        30: '\'uncu',

        60: '\'ıncı',
        90: '\'ıncı'
    },
        language = {
        delimiters: {
            thousands: '.',
            decimal: ','
        },
        abbreviations: {
            thousand: 'bin',
            million: 'milyon',
            billion: 'milyar',
            trillion: 'trilyon'
        },
        ordinal: function ordinal(number) {
            if (number === 0) {
                // special case for zero
                return '\'ıncı';
            }

            var a = number % 10,
                b = number % 100 - a,
                c = number >= 100 ? 100 : null;

            return suffixes[a] || suffixes[b] || suffixes[c];
        },
        currency: {
            symbol: '₺'
        }
    };

    // Node
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = language;
    }
})();

},{}],81:[function(require,module,exports){
'use strict';

/*!
 * numeral.js
 * version : 1.5.3
 * author : Adam Draper
 * license : MIT
 * http://adamwdraper.github.com/Numeral-js/
 */

(function () {

    /************************************
        Constants
    ************************************/

    var _numeral,
        VERSION = '1.5.3',

    // internal storage for language config files
    languages = {},
        currentLanguage = 'en',
        zeroFormat = null,
        defaultFormat = '0,0',

    // check for nodeJS
    hasModule = typeof module !== 'undefined' && module.exports;

    /************************************
        Constructors
    ************************************/

    // Numeral prototype object
    function Numeral(number) {
        this._value = number;
    }

    /**
     * Implementation of toFixed() that treats floats more like decimals
     *
     * Fixes binary rounding issues (eg. (0.615).toFixed(2) === '0.61') that present
     * problems for accounting- and finance-related software.
     */
    function toFixed(value, precision, roundingFunction, optionals) {
        var power = Math.pow(10, precision),
            optionalsRegExp,
            output;

        //roundingFunction = (roundingFunction !== undefined ? roundingFunction : Math.round);
        // Multiply up by precision, round accurately, then divide and use native toFixed():
        output = (roundingFunction(value * power) / power).toFixed(precision);

        if (optionals) {
            optionalsRegExp = new RegExp('0{1,' + optionals + '}$');
            output = output.replace(optionalsRegExp, '');
        }

        return output;
    }

    /************************************
        Formatting
    ************************************/

    // determine what type of formatting we need to do
    function formatNumeral(n, format, roundingFunction) {
        var output;

        // figure out what kind of format we are dealing with
        if (format.indexOf('$') > -1) {
            // currency!!!!!
            output = formatCurrency(n, format, roundingFunction);
        } else if (format.indexOf('%') > -1) {
            // percentage
            output = formatPercentage(n, format, roundingFunction);
        } else if (format.indexOf(':') > -1) {
            // time
            output = formatTime(n, format);
        } else {
            // plain ol' numbers or bytes
            output = formatNumber(n._value, format, roundingFunction);
        }

        // return string
        return output;
    }

    // revert to number
    function unformatNumeral(n, string) {
        var stringOriginal = string,
            thousandRegExp,
            millionRegExp,
            billionRegExp,
            trillionRegExp,
            suffixes = ['KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
            bytesMultiplier = false,
            power;

        if (string.indexOf(':') > -1) {
            n._value = unformatTime(string);
        } else {
            if (string === zeroFormat) {
                n._value = 0;
            } else {
                if (languages[currentLanguage].delimiters.decimal !== '.') {
                    string = string.replace(/\./g, '').replace(languages[currentLanguage].delimiters.decimal, '.');
                }

                // see if abbreviations are there so that we can multiply to the correct number
                thousandRegExp = new RegExp('[^a-zA-Z]' + languages[currentLanguage].abbreviations.thousand + '(?:\\)|(\\' + languages[currentLanguage].currency.symbol + ')?(?:\\))?)?$');
                millionRegExp = new RegExp('[^a-zA-Z]' + languages[currentLanguage].abbreviations.million + '(?:\\)|(\\' + languages[currentLanguage].currency.symbol + ')?(?:\\))?)?$');
                billionRegExp = new RegExp('[^a-zA-Z]' + languages[currentLanguage].abbreviations.billion + '(?:\\)|(\\' + languages[currentLanguage].currency.symbol + ')?(?:\\))?)?$');
                trillionRegExp = new RegExp('[^a-zA-Z]' + languages[currentLanguage].abbreviations.trillion + '(?:\\)|(\\' + languages[currentLanguage].currency.symbol + ')?(?:\\))?)?$');

                // see if bytes are there so that we can multiply to the correct number
                for (power = 0; power <= suffixes.length; power++) {
                    bytesMultiplier = string.indexOf(suffixes[power]) > -1 ? Math.pow(1024, power + 1) : false;

                    if (bytesMultiplier) {
                        break;
                    }
                }

                // do some math to create our number
                n._value = (bytesMultiplier ? bytesMultiplier : 1) * (stringOriginal.match(thousandRegExp) ? Math.pow(10, 3) : 1) * (stringOriginal.match(millionRegExp) ? Math.pow(10, 6) : 1) * (stringOriginal.match(billionRegExp) ? Math.pow(10, 9) : 1) * (stringOriginal.match(trillionRegExp) ? Math.pow(10, 12) : 1) * (string.indexOf('%') > -1 ? 0.01 : 1) * ((string.split('-').length + Math.min(string.split('(').length - 1, string.split(')').length - 1)) % 2 ? 1 : -1) * Number(string.replace(/[^0-9\.]+/g, ''));

                // round if we are talking about bytes
                n._value = bytesMultiplier ? Math.ceil(n._value) : n._value;
            }
        }
        return n._value;
    }

    function formatCurrency(n, format, roundingFunction) {
        var symbolIndex = format.indexOf('$'),
            openParenIndex = format.indexOf('('),
            minusSignIndex = format.indexOf('-'),
            space = '',
            spliceIndex,
            output;

        // check for space before or after currency
        if (format.indexOf(' $') > -1) {
            space = ' ';
            format = format.replace(' $', '');
        } else if (format.indexOf('$ ') > -1) {
            space = ' ';
            format = format.replace('$ ', '');
        } else {
            format = format.replace('$', '');
        }

        // format the number
        output = formatNumber(n._value, format, roundingFunction);

        // position the symbol
        if (symbolIndex <= 1) {
            if (output.indexOf('(') > -1 || output.indexOf('-') > -1) {
                output = output.split('');
                spliceIndex = 1;
                if (symbolIndex < openParenIndex || symbolIndex < minusSignIndex) {
                    // the symbol appears before the "(" or "-"
                    spliceIndex = 0;
                }
                output.splice(spliceIndex, 0, languages[currentLanguage].currency.symbol + space);
                output = output.join('');
            } else {
                output = languages[currentLanguage].currency.symbol + space + output;
            }
        } else {
            if (output.indexOf(')') > -1) {
                output = output.split('');
                output.splice(-1, 0, space + languages[currentLanguage].currency.symbol);
                output = output.join('');
            } else {
                output = output + space + languages[currentLanguage].currency.symbol;
            }
        }

        return output;
    }

    function formatPercentage(n, format, roundingFunction) {
        var space = '',
            output,
            value = n._value * 100;

        // check for space before %
        if (format.indexOf(' %') > -1) {
            space = ' ';
            format = format.replace(' %', '');
        } else {
            format = format.replace('%', '');
        }

        output = formatNumber(value, format, roundingFunction);

        if (output.indexOf(')') > -1) {
            output = output.split('');
            output.splice(-1, 0, space + '%');
            output = output.join('');
        } else {
            output = output + space + '%';
        }

        return output;
    }

    function formatTime(n) {
        var hours = Math.floor(n._value / 60 / 60),
            minutes = Math.floor((n._value - hours * 60 * 60) / 60),
            seconds = Math.round(n._value - hours * 60 * 60 - minutes * 60);
        return hours + ':' + (minutes < 10 ? '0' + minutes : minutes) + ':' + (seconds < 10 ? '0' + seconds : seconds);
    }

    function unformatTime(string) {
        var timeArray = string.split(':'),
            seconds = 0;
        // turn hours and minutes into seconds and add them all up
        if (timeArray.length === 3) {
            // hours
            seconds = seconds + Number(timeArray[0]) * 60 * 60;
            // minutes
            seconds = seconds + Number(timeArray[1]) * 60;
            // seconds
            seconds = seconds + Number(timeArray[2]);
        } else if (timeArray.length === 2) {
            // minutes
            seconds = seconds + Number(timeArray[0]) * 60;
            // seconds
            seconds = seconds + Number(timeArray[1]);
        }
        return Number(seconds);
    }

    function formatNumber(value, format, roundingFunction) {
        var negP = false,
            signed = false,
            optDec = false,
            abbr = '',
            abbrK = false,
            // force abbreviation to thousands
        abbrM = false,
            // force abbreviation to millions
        abbrB = false,
            // force abbreviation to billions
        abbrT = false,
            // force abbreviation to trillions
        abbrForce = false,
            // force abbreviation
        bytes = '',
            ord = '',
            abs = Math.abs(value),
            suffixes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
            min,
            max,
            power,
            w,
            precision,
            thousands,
            d = '',
            neg = false;

        // check if number is zero and a custom zero format has been set
        if (value === 0 && zeroFormat !== null) {
            return zeroFormat;
        } else {
            // see if we should use parentheses for negative number or if we should prefix with a sign
            // if both are present we default to parentheses
            if (format.indexOf('(') > -1) {
                negP = true;
                format = format.slice(1, -1);
            } else if (format.indexOf('+') > -1) {
                signed = true;
                format = format.replace(/\+/g, '');
            }

            // see if abbreviation is wanted
            if (format.indexOf('a') > -1) {
                // check if abbreviation is specified
                abbrK = format.indexOf('aK') >= 0;
                abbrM = format.indexOf('aM') >= 0;
                abbrB = format.indexOf('aB') >= 0;
                abbrT = format.indexOf('aT') >= 0;
                abbrForce = abbrK || abbrM || abbrB || abbrT;

                // check for space before abbreviation
                if (format.indexOf(' a') > -1) {
                    abbr = ' ';
                    format = format.replace(' a', '');
                } else {
                    format = format.replace('a', '');
                }

                if (abs >= Math.pow(10, 12) && !abbrForce || abbrT) {
                    // trillion
                    abbr = abbr + languages[currentLanguage].abbreviations.trillion;
                    value = value / Math.pow(10, 12);
                } else if (abs < Math.pow(10, 12) && abs >= Math.pow(10, 9) && !abbrForce || abbrB) {
                    // billion
                    abbr = abbr + languages[currentLanguage].abbreviations.billion;
                    value = value / Math.pow(10, 9);
                } else if (abs < Math.pow(10, 9) && abs >= Math.pow(10, 6) && !abbrForce || abbrM) {
                    // million
                    abbr = abbr + languages[currentLanguage].abbreviations.million;
                    value = value / Math.pow(10, 6);
                } else if (abs < Math.pow(10, 6) && abs >= Math.pow(10, 3) && !abbrForce || abbrK) {
                    // thousand
                    abbr = abbr + languages[currentLanguage].abbreviations.thousand;
                    value = value / Math.pow(10, 3);
                }
            }

            // see if we are formatting bytes
            if (format.indexOf('b') > -1) {
                // check for space before
                if (format.indexOf(' b') > -1) {
                    bytes = ' ';
                    format = format.replace(' b', '');
                } else {
                    format = format.replace('b', '');
                }

                for (power = 0; power <= suffixes.length; power++) {
                    min = Math.pow(1024, power);
                    max = Math.pow(1024, power + 1);

                    if (value >= min && value < max) {
                        bytes = bytes + suffixes[power];
                        if (min > 0) {
                            value = value / min;
                        }
                        break;
                    }
                }
            }

            // see if ordinal is wanted
            if (format.indexOf('o') > -1) {
                // check for space before
                if (format.indexOf(' o') > -1) {
                    ord = ' ';
                    format = format.replace(' o', '');
                } else {
                    format = format.replace('o', '');
                }

                ord = ord + languages[currentLanguage].ordinal(value);
            }

            if (format.indexOf('[.]') > -1) {
                optDec = true;
                format = format.replace('[.]', '.');
            }

            w = value.toString().split('.')[0];
            precision = format.split('.')[1];
            thousands = format.indexOf(',');

            if (precision) {
                if (precision.indexOf('[') > -1) {
                    precision = precision.replace(']', '');
                    precision = precision.split('[');
                    d = toFixed(value, precision[0].length + precision[1].length, roundingFunction, precision[1].length);
                } else {
                    d = toFixed(value, precision.length, roundingFunction);
                }

                w = d.split('.')[0];

                if (d.split('.')[1].length) {
                    d = languages[currentLanguage].delimiters.decimal + d.split('.')[1];
                } else {
                    d = '';
                }

                if (optDec && Number(d.slice(1)) === 0) {
                    d = '';
                }
            } else {
                w = toFixed(value, null, roundingFunction);
            }

            // format number
            if (w.indexOf('-') > -1) {
                w = w.slice(1);
                neg = true;
            }

            if (thousands > -1) {
                w = w.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1' + languages[currentLanguage].delimiters.thousands);
            }

            if (format.indexOf('.') === 0) {
                w = '';
            }

            return (negP && neg ? '(' : '') + (!negP && neg ? '-' : '') + (!neg && signed ? '+' : '') + w + d + (ord ? ord : '') + (abbr ? abbr : '') + (bytes ? bytes : '') + (negP && neg ? ')' : '');
        }
    }

    /************************************
        Top Level Functions
    ************************************/

    _numeral = function numeral(input) {
        if (_numeral.isNumeral(input)) {
            input = input.value();
        } else if (input === 0 || typeof input === 'undefined') {
            input = 0;
        } else if (!Number(input)) {
            input = _numeral.fn.unformat(input);
        }

        return new Numeral(Number(input));
    };

    // version number
    _numeral.version = VERSION;

    // compare numeral object
    _numeral.isNumeral = function (obj) {
        return obj instanceof Numeral;
    };

    // This function will load languages and then set the global language.  If
    // no arguments are passed in, it will simply return the current global
    // language key.
    _numeral.language = function (key, values) {
        if (!key) {
            return currentLanguage;
        }

        if (key && !values) {
            if (!languages[key]) {
                throw new Error('Unknown language : ' + key);
            }
            currentLanguage = key;
        }

        if (values || !languages[key]) {
            loadLanguage(key, values);
        }

        return _numeral;
    };

    // This function provides access to the loaded language data.  If
    // no arguments are passed in, it will simply return the current
    // global language object.
    _numeral.languageData = function (key) {
        if (!key) {
            return languages[currentLanguage];
        }

        if (!languages[key]) {
            throw new Error('Unknown language : ' + key);
        }

        return languages[key];
    };

    _numeral.language('en', {
        delimiters: {
            thousands: ',',
            decimal: '.'
        },
        abbreviations: {
            thousand: 'k',
            million: 'm',
            billion: 'b',
            trillion: 't'
        },
        ordinal: function ordinal(number) {
            var b = number % 10;
            return ~~(number % 100 / 10) === 1 ? 'th' : b === 1 ? 'st' : b === 2 ? 'nd' : b === 3 ? 'rd' : 'th';
        },
        currency: {
            symbol: '$'
        }
    });

    _numeral.zeroFormat = function (format) {
        zeroFormat = typeof format === 'string' ? format : null;
    };

    _numeral.defaultFormat = function (format) {
        defaultFormat = typeof format === 'string' ? format : '0.0';
    };

    /************************************
        Helpers
    ************************************/

    function loadLanguage(key, values) {
        languages[key] = values;
    }

    /************************************
        Floating-point helpers
    ************************************/

    // The floating-point helper functions and implementation
    // borrows heavily from sinful.js: http://guipn.github.io/sinful.js/

    /**
     * Array.prototype.reduce for browsers that don't support it
     * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/Reduce#Compatibility
     */
    if ('function' !== typeof Array.prototype.reduce) {
        Array.prototype.reduce = function (callback, opt_initialValue) {
            'use strict';

            if (null === this || 'undefined' === typeof this) {
                // At the moment all modern browsers, that support strict mode, have
                // native implementation of Array.prototype.reduce. For instance, IE8
                // does not support strict mode, so this check is actually useless.
                throw new TypeError('Array.prototype.reduce called on null or undefined');
            }

            if ('function' !== typeof callback) {
                throw new TypeError(callback + ' is not a function');
            }

            var index,
                value,
                length = this.length >>> 0,
                isValueSet = false;

            if (1 < arguments.length) {
                value = opt_initialValue;
                isValueSet = true;
            }

            for (index = 0; length > index; ++index) {
                if (this.hasOwnProperty(index)) {
                    if (isValueSet) {
                        value = callback(value, this[index], index, this);
                    } else {
                        value = this[index];
                        isValueSet = true;
                    }
                }
            }

            if (!isValueSet) {
                throw new TypeError('Reduce of empty array with no initial value');
            }

            return value;
        };
    }

    /**
     * Computes the multiplier necessary to make x >= 1,
     * effectively eliminating miscalculations caused by
     * finite precision.
     */
    function multiplier(x) {
        var parts = x.toString().split('.');
        if (parts.length < 2) {
            return 1;
        }
        return Math.pow(10, parts[1].length);
    }

    /**
     * Given a variable number of arguments, returns the maximum
     * multiplier that must be used to normalize an operation involving
     * all of them.
     */
    function correctionFactor() {
        var args = Array.prototype.slice.call(arguments);
        return args.reduce(function (prev, next) {
            var mp = multiplier(prev),
                mn = multiplier(next);
            return mp > mn ? mp : mn;
        }, -Infinity);
    }

    /************************************
        Numeral Prototype
    ************************************/

    _numeral.fn = Numeral.prototype = {

        clone: function clone() {
            return _numeral(this);
        },

        format: function format(inputString, roundingFunction) {
            return formatNumeral(this, inputString ? inputString : defaultFormat, roundingFunction !== undefined ? roundingFunction : Math.round);
        },

        unformat: function unformat(inputString) {
            if (Object.prototype.toString.call(inputString) === '[object Number]') {
                return inputString;
            }
            return unformatNumeral(this, inputString ? inputString : defaultFormat);
        },

        value: function value() {
            return this._value;
        },

        valueOf: function valueOf() {
            return this._value;
        },

        set: function set(value) {
            this._value = Number(value);
            return this;
        },

        add: function add(value) {
            var corrFactor = correctionFactor.call(null, this._value, value);
            function cback(accum, curr, currI, O) {
                return accum + corrFactor * curr;
            }
            this._value = [this._value, value].reduce(cback, 0) / corrFactor;
            return this;
        },

        subtract: function subtract(value) {
            var corrFactor = correctionFactor.call(null, this._value, value);
            function cback(accum, curr, currI, O) {
                return accum - corrFactor * curr;
            }
            this._value = [value].reduce(cback, this._value * corrFactor) / corrFactor;
            return this;
        },

        multiply: function multiply(value) {
            function cback(accum, curr, currI, O) {
                var corrFactor = correctionFactor(accum, curr);
                return accum * corrFactor * (curr * corrFactor) / (corrFactor * corrFactor);
            }
            this._value = [this._value, value].reduce(cback, 1);
            return this;
        },

        divide: function divide(value) {
            function cback(accum, curr, currI, O) {
                var corrFactor = correctionFactor(accum, curr);
                return accum * corrFactor / (curr * corrFactor);
            }
            this._value = [this._value, value].reduce(cback);
            return this;
        },

        difference: function difference(value) {
            return Math.abs(_numeral(this._value).subtract(value).value());
        }

    };

    /************************************
        Exposing Numeral
    ************************************/

    module.exports = _numeral;
}).call(undefined);

},{}],82:[function(require,module,exports){
'use strict';

function Translations() {
  this._data = {};

  // ensure that the context of the get method is always this object
  this.get = this.get.bind(this);
}

/**
 * Default implementation if the
 * locale is not loaded
 */
Translations.prototype.injectData = function (data) {
  this._data = data;
};

/**
 * Get a translation
 */
Translations.prototype.get = function (key, var_args) {
  var format = this._data.hasOwnProperty(key) ? this._data[key] : key;
  var args = arguments;

  return format.replace(/\{(\d+?)\}/g, function (str, num) {
    var value = args[+num + 1];

    // Do not change by a ||. A value of an empty string would make it fail.
    return typeof value !== 'undefined' ? value : str;
  });
};

/**
 * Gets the raw translations data
 * @return {Object} Locale object
 */
Translations.prototype.getData = function () {
  return this._data;
};

/**
 * Creates a translations instance with the specified data
 *
 * @param {Object} data Translations object
 * @return {Translations}
 */
Translations.createWithData = function (data) {
  var translations = new Translations();
  translations.injectData(data);
  return translations;
};

module.exports = Translations;

},{}],83:[function(require,module,exports){
/**
 * BezierEasing - use bezier curve for transition easing function
 * by Gaëtan Renaudeau 2014 - 2015 – MIT License
 *
 * Credits: is based on Firefox's nsSMILKeySpline.cpp
 * Usage:
 * var spline = BezierEasing([ 0.25, 0.1, 0.25, 1.0 ])
 * spline.get(x) => returns the easing value | x must be in [0, 1] range
 *
 */

// These values are established by empiricism with tests (tradeoff: performance VS precision)
var NEWTON_ITERATIONS = 4;
var NEWTON_MIN_SLOPE = 0.001;
var SUBDIVISION_PRECISION = 0.0000001;
var SUBDIVISION_MAX_ITERATIONS = 10;

var kSplineTableSize = 11;
var kSampleStepSize = 1.0 / (kSplineTableSize - 1.0);

var float32ArraySupported = typeof Float32Array === "function";

function A (aA1, aA2) { return 1.0 - 3.0 * aA2 + 3.0 * aA1; }
function B (aA1, aA2) { return 3.0 * aA2 - 6.0 * aA1; }
function C (aA1)      { return 3.0 * aA1; }

// Returns x(t) given t, x1, and x2, or y(t) given t, y1, and y2.
function calcBezier (aT, aA1, aA2) {
  return ((A(aA1, aA2)*aT + B(aA1, aA2))*aT + C(aA1))*aT;
}

// Returns dx/dt given t, x1, and x2, or dy/dt given t, y1, and y2.
function getSlope (aT, aA1, aA2) {
  return 3.0 * A(aA1, aA2)*aT*aT + 2.0 * B(aA1, aA2) * aT + C(aA1);
}

function binarySubdivide (aX, aA, aB, mX1, mX2) {
  var currentX, currentT, i = 0;
  do {
    currentT = aA + (aB - aA) / 2.0;
    currentX = calcBezier(currentT, mX1, mX2) - aX;
    if (currentX > 0.0) {
      aB = currentT;
    } else {
      aA = currentT;
    }
  } while (Math.abs(currentX) > SUBDIVISION_PRECISION && ++i < SUBDIVISION_MAX_ITERATIONS);
  return currentT;
}

function newtonRaphsonIterate (aX, aGuessT, mX1, mX2) {
  for (var i = 0; i < NEWTON_ITERATIONS; ++i) {
    var currentSlope = getSlope(aGuessT, mX1, mX2);
    if (currentSlope === 0.0) return aGuessT;
    var currentX = calcBezier(aGuessT, mX1, mX2) - aX;
    aGuessT -= currentX / currentSlope;
  }
  return aGuessT;
}

/**
 * points is an array of [ mX1, mY1, mX2, mY2 ]
 */
function BezierEasing (points, b, c, d) {
  if (arguments.length === 4) {
    return new BezierEasing([ points, b, c, d ]);
  }
  if (!(this instanceof BezierEasing)) return new BezierEasing(points);

  if (!points || points.length !== 4) {
    throw new Error("BezierEasing: points must contains 4 values");
  }
  for (var i=0; i<4; ++i) {
    if (typeof points[i] !== "number" || isNaN(points[i]) || !isFinite(points[i])) {
      throw new Error("BezierEasing: points should be integers.");
    }
  }
  if (points[0] < 0 || points[0] > 1 || points[2] < 0 || points[2] > 1) {
    throw new Error("BezierEasing x values must be in [0, 1] range.");
  }

  this._str = "BezierEasing("+points+")";
  this._css = "cubic-bezier("+points+")";
  this._p = points;
  this._mSampleValues = float32ArraySupported ? new Float32Array(kSplineTableSize) : new Array(kSplineTableSize);
  this._precomputed = false;

  this.get = this.get.bind(this);
}

BezierEasing.prototype = {

  get: function (x) {
    var mX1 = this._p[0],
      mY1 = this._p[1],
      mX2 = this._p[2],
      mY2 = this._p[3];
    if (!this._precomputed) this._precompute();
    if (mX1 === mY1 && mX2 === mY2) return x; // linear
    // Because JavaScript number are imprecise, we should guarantee the extremes are right.
    if (x === 0) return 0;
    if (x === 1) return 1;
    return calcBezier(this._getTForX(x), mY1, mY2);
  },

  getPoints: function() {
    return this._p;
  },

  toString: function () {
    return this._str;
  },

  toCSS: function () {
    return this._css;
  },

  // Private part

  _precompute: function () {
    var mX1 = this._p[0],
      mY1 = this._p[1],
      mX2 = this._p[2],
      mY2 = this._p[3];
    this._precomputed = true;
    if (mX1 !== mY1 || mX2 !== mY2)
      this._calcSampleValues();
  },

  _calcSampleValues: function () {
    var mX1 = this._p[0],
      mX2 = this._p[2];
    for (var i = 0; i < kSplineTableSize; ++i) {
      this._mSampleValues[i] = calcBezier(i * kSampleStepSize, mX1, mX2);
    }
  },

  /**
   * getTForX chose the fastest heuristic to determine the percentage value precisely from a given X projection.
   */
  _getTForX: function (aX) {
    var mX1 = this._p[0],
      mX2 = this._p[2],
      mSampleValues = this._mSampleValues;

    var intervalStart = 0.0;
    var currentSample = 1;
    var lastSample = kSplineTableSize - 1;

    for (; currentSample !== lastSample && mSampleValues[currentSample] <= aX; ++currentSample) {
      intervalStart += kSampleStepSize;
    }
    --currentSample;

    // Interpolate to provide an initial guess for t
    var dist = (aX - mSampleValues[currentSample]) / (mSampleValues[currentSample+1] - mSampleValues[currentSample]);
    var guessForT = intervalStart + dist * kSampleStepSize;

    var initialSlope = getSlope(guessForT, mX1, mX2);
    if (initialSlope >= NEWTON_MIN_SLOPE) {
      return newtonRaphsonIterate(aX, guessForT, mX1, mX2);
    } else if (initialSlope === 0.0) {
      return guessForT;
    } else {
      return binarySubdivide(aX, intervalStart, intervalStart + kSampleStepSize, mX1, mX2);
    }
  }
};

// CSS mapping
BezierEasing.css = {
  "ease":        BezierEasing.ease      = BezierEasing(0.25, 0.1, 0.25, 1.0),
  "linear":      BezierEasing.linear    = BezierEasing(0.00, 0.0, 1.00, 1.0),
  "ease-in":     BezierEasing.easeIn    = BezierEasing(0.42, 0.0, 1.00, 1.0),
  "ease-out":    BezierEasing.easeOut   = BezierEasing(0.00, 0.0, 0.58, 1.0),
  "ease-in-out": BezierEasing.easeInOut = BezierEasing(0.42, 0.0, 0.58, 1.0)
};

module.exports = BezierEasing;

},{}],84:[function(require,module,exports){
'use strict';

exports.message = require('./src/message');
exports.request = require('./src/request');
exports.response = require('./src/response');
exports.playerstate = require('./src/player_state');

},{"./src/message":85,"./src/player_state":86,"./src/request":87,"./src/response":88}],85:[function(require,module,exports){
/**
 * A set of Message headers.
 *
 * @name exports.Headers
 * @typedef {Object.<string, string>}
 */
exports.Headers;

/**
 * A body of a Request-Response.
 *
 * @name exports.Body
 * @typedef {*}
 */
exports.Body;

/**
 * A serialized Message object.
 *
 * @name Spotify.Cosmos.SerializedMessage
 * @typedef {{
 *   uri: Spotify.Cosmos.URI,
 *   headers: Spotify.Cosmos.Headers,
 *   body: Spotify.Cosmos.Body
 * }}
 */
exports.SerializedMessage;

/**
 * Encapsulates a message.
 *
 * A message is an entity that has a URI, headers and a body.
 *
 * @constructs Spotify.Cosmos.Message
 * @param {Spotify.Cosmos.URI} uri The URI of the message
 * @param {Spotify.Cosmos.Headers=} opt_headers The optional headers of the
 *     message.
 * @param {Spotify.Cosmos.Body=} opt_body The optional body of the message.
 */
function Message(uri, opt_headers, opt_body) {
  if (uri == null)
    throw new TypeError('Invalid `uri` argument for Message.');

  /**
   * The URI of the Message.
   *
   * @type {Spotify.Cosmos.URI}
   * @protected
   */
  this._uri = uri;

  /**
   * The headers of the Message.
   *
   * @type {Spotify.Cosmos.Headers}
   * @protected
   */
  this._headers = {};

  /**
   * The body of the Message.
   *
   * @type {Spotify.Cosmos.Body}
   * @protected
   */
  this._body = this._encodeBody(opt_body || '');

  if (opt_headers) this._setHeaders(opt_headers);
}
exports.Message = Message;

/**
 * Creates a new Message from a SerializedMessage object.
 *
 * @param {Spotify.Cosmos.SerializedMessage} object The serialized request.
 * @return {Spotify.Cosmos.Message|null} The new Message object or null.
 */
Message.fromObject = function(object) {
  return (object && object.uri) ?
    new Message(
        object.uri,
        object.headers,
        object.body
    ) : null;
};

/**
 * Encodes a message body to a string.
 *
 * @param {*} body The value for the body.
 * @return {string} The body encoded as a string.
 */
Message.prototype._encodeBody = function(body) {
  if (typeof body != 'string') {
    body = JSON.stringify(body);
  }
  return body;
};

/**
 * Returns the URI of the message.
 *
 * @return {Spotify.Cosmos.URI} The URI of the message.
 */
Message.prototype.getURI = function() {
  return this._uri;
};

/**
 * Returns the mimetype of the message.
 *
 * @return {Spotify.Cosmos.MimeType} The mimetype of the message.
 */
Message.prototype.getMimeType = function() {
  return this._headers['accept'];
};

/**
 * Returns the value of a message's headers.
 *
 * @param {string} name The name of the header.
 * @return {string|null} The header value or null if the header wasn't set.
 */
Message.prototype.getHeader = function(name) {
  return this._headers[name.toLowerCase()] || null;
};

/**
 * Returns the headers of the message.
 *
 * @return {Spotify.Cosmos.Headers} The headers of the message.
 */
Message.prototype.getHeaders = function() {
  var _headers = this._headers;
  var headers = {};
  for (var name in _headers) {
    if (!_headers.hasOwnProperty(name)) continue;
    headers[name] = _headers[name];
  }
  return headers;
};

/**
 * Sets a bunch of headers to the message's headers.
 *
 * @param {Spotify.Cosmos.Headers} headers The headers to set to the message.
 * @protected
 */
Message.prototype._setHeaders = function(headers) {
  var _headers = this._headers;
  for (var name in headers) {
    if (!headers.hasOwnProperty(name)) continue;
    _headers[name.toLowerCase()] = headers[name];
  }
  return this;
};

/**
 * Returns the body of the message.
 *
 * @return {Spotify.Cosmos.Body} The body of the message.
 */
Message.prototype.getBody = function() {
  return this._body;
};

/**
 * Returns the body as a JSON object.
 *
 * @return {Object|null} The body of the message parsed as a JSON value. Can
 *     be null if the body is not a proper JSON string.
 */
Message.prototype.getJSONBody = function() {
  try {
    return JSON.parse(this._body);
  } catch(e) {
    return null;
  }
};

/**
 * Creates a new Message instance with data copied from the current instance.
 *
 * @param {Spotify.Cosmos.Headers=} opt_headers The optional headers of the
 *     message.
 * @param {Spotify.Cosmos.Body=} opt_body The optional body of the message.
 */
Message.prototype.copy = function(opt_headers, opt_body) {
  return new Message(
      this._uri,
      this._copyHeaders(opt_headers),
      typeof opt_body != 'undefined' ? opt_body : this._body
  );
};

/**
 * Copies the headers of the message.
 *
 * @param {Spotify.Cosmos.Headers=} opt_headers The optional headers of the
 *     message.
 * @return {Spotify.Cosmos.Headers} The headers of the message.
 */
Message.prototype._copyHeaders = function(opt_headers) {
  var headers;
  if (opt_headers) {
    var _headers = this._headers;
    var name;
    headers = {};
    for (name in _headers) {
      if (!_headers.hasOwnProperty(name)) continue;
      headers[name] = _headers[name];
    }
    for (name in opt_headers) {
      if (!opt_headers.hasOwnProperty(name)) continue;
      headers[name.toLowerCase()] = opt_headers[name];
    }
  } else {
    headers = this._headers;
  }
  return headers;
};

/**
 * Serializes the message into a plain object.
 *
 * @return {Spotify.Cosmos.SerializedMessage} The serialized object.
 */
Message.prototype.serialize = function() {
  return this.toJSON();
};

/**
 * Returns a JSON-object representation of the message.
 *
 * @return {Object} The JSON representation of the message.
 */
Message.prototype.toJSON = function() {
  return {
    uri: this._uri,
    headers: this._headers,
    body: this._body
  };
};

},{}],86:[function(require,module,exports){
var inherit = require('spotify-inheritance').inherit;

/**
 * PlayerState is used for two distinct purposes: Pushing new state to the
 * player (this is done when you request to play a completely new context with
 * 'play' method) and retrieving player state updates.
 *
 * Changing properties on PlayerState objects will not change the state of
 * the player unless you pass it to the 'play' method.
 *
 * @param {Object} stateData the data for the playerState.
 */
function PlayerState(stateData) {
  Serializable.call(this, [
    'action',
    'context',
    'tracks',
    'index',
    'playing',
    'loading',
    'track',
    'position',
    'duration',
    'volume',
    'options',
    'play_origin',
    'next_page_url',
    'prev_page_url'
  ]);

  stateData = stateData || {};
  /**
   * What kind of the action player should perform.
   * It's set directly before sending the request.
   * @type {String}
   */
  this.action = stateData.action;

  /**
   * Spotify uri describing the context that
   * will be played e.g playlist, album or artist.
   * Example: spotify:artist:4XaUmUGjidSklcDHxv3XWf,
   * spotify:user:daftpunkofficial:playlist:5nrg0D90OlFyveVfrQD0zE,
   * spotify:album:2nXJkqkS1tIKIyhBcFMmwz
   *
   * @type {String}
   */
  this.context = stateData.context;

  /**
   * The list of tracks uris to play in the given context.
   * Example: [
   *    spotify:track:0bXpmJyHHYPk6QBFj25bYF,
   *    spotify:track:6DXFVsLcEvOTSrkG9G1Cb1,
   *    spotify:track:6rxEjkoar48SssZePbtb2x
   * ]
   *
   * @type {Array.<String>}
   */
  this.tracks = stateData.tracks;

  /**
   * Which element on the this.tracks list should
   * be played.
   *
   * @type {Number}
   */
  this.index = stateData.index;

  /**
   * Is the player currently playing
   */
  this.playing = stateData.playing;
  this.loading = stateData.loading;

  /**
   * Current track URI
   * @type {String}
   */
  this.track = stateData.track;


  this.position = stateData.position;

  this.volume = stateData.volume;

  /**
   * Current track duration in miliseconds?
   * @type {Number}
   */
  this.duration = stateData.duration;

  /**
   * See PlayOptions description
   * @type {cosmos-bindings-js/scripts/player_state~PlayOptions}
   */
  this.options = new PlayOptions(stateData.options);

  /**
   * See PlayOrigin description
   * @type {cosmos-bindings-js/scripts/player_state~PlayOrigin}
   */
  this.play_origin = new PlayOrigin(stateData.play_origin);

  /**
   * Before the list of tracks that are to be played ends, a request will be sent
   * to this URL, which is supposed to return a list of tracks. That list of
   * tracks will then be appended to the list of tracks in the context.
   *
   * The response payload of the next_page_url should look like this:
   *
   * {
   *   "tracks": [
   *     { "track": "spotify:track:$TRACK-ID1", "context": "spotify:album:$ALBUM-ID1" },
   *     { "track": "spotify:track:$TRACK-ID2", "context": "spotify:album:$ALBUM-ID1" },
   *     { "track": "spotify:track:$TRACK-ID3", "context": "spotify:album:$ALBUM-ID1" },
   *   ],
   *   "next_page_url": "...", // Optional
   *   "prev_page_url": "..." // Optional
   * }
   *
   * May be null, which is the same as a URL that would return an empty list
   * of tracks (but with null, no network request is made).
   */
  this.next_page_url = stateData.next_page_url;

  /**
   * Like `next_page_url`, but for going backwards in the context.
   */
  this.prev_page_url = stateData.prev_page_url;
}
inherit(PlayerState, Serializable);

/**
 * Ovverides prototype method.
 * Converts play options and origin to
 * serializable to make sure only correct data
 * is returned.
 * @return {Object} Data associated with player state.
 */
PlayerState.prototype.serialize = function() {
  if (this.options && !(this.options instanceof PlayOptions)) {
    this.options = new PlayOptions(this.options);
  }

  if (this.play_origin && !(this.play_origin instanceof PlayOrigin)) {
    this.play_origin = new PlayOrigin(this.play_origin);
  }

  return this.constructor.prototype.serialize.call(this);
};

/**
 * Possible player actions.
 */
PlayerState.ACTIONS = {
  UNKNOWN: 'unknown',
  PLAY: 'play',
  UPDATE: 'update',
  STOP: 'stop',
  RESUME: 'resume',
  PAUSE: 'pause',
  SKIP_PREV: 'skip_prev',
  SKIP_NEXT: 'skip_next'
};

function PlayOrigin(data) {
  Serializable.call(this, [
    'source',
    'source_context',
    'reason',
    'referrer',
    'referrer_version',
    'referrer_vendor'
  ]);

  data = data || {};

  /**
   * What kind of playlist did we play from?
   *
   * The default value of this property is "unknown". Must have a value.
   *
   * Valid values include 'album', 'artist', 'extlink', 'playlist', 'playqueue',
   * 'radio', 'search', 'unknown'.
   *
   * For an up to date list of valid values, see `PLAY_SOURCES` in
   * https://git.spotify.net/cgit.cgi/log-parser.git/tree/spotify/log_parser/messages_specs.py
   */
  this.source = data.source || 'unknown';

  /**
   * The uri of the view that initiated the playback.
   */
  this.source_context = data.source_context || 'unknown';

  /**
   * Why was the song started?
   *
   * The default value of this property is "unknown". Must have a value.
   *
   * A list of valid values that might be used by features:
   *
   * unknown    = Client doesn't know
   * clickrow   = A row in the song list was clicked/opened
   * playbtn    = The play button was pressed
   * urlopen    = A Url was opened
   *
   * For a complete and up to date list of valid values, see `PLAY_REASONS` in
   * https://git.spotify.net/cgit.cgi/log-parser.git/tree/spotify/log_parser/messages_specs.py
   */
  this.reason = data.reason || 'unknown';

  /**
   * Either a remote site or a spotify app which initiated the request.
   *
   * NOTE: This normally should be a readonly property and not be set
   * explicitly in the PlayerState as the Player will overwrite it when sending the request.
   */
  this.referrer = data.referrer || 'unknown';

  /**
   * The version of the referrer, where applicable. It usually makes sense to
   * set this value to the version of the JS app version, for instance "0.7.5".
   *
   * NOTE: This normally should be a readonly property and not be set
   * explicitly in the PlayerState as the Player will overwrite it when sending the request.
   */
  this.referrer_version = data.referrer_version || 'unknown';

  /**
   * The vendor of the referrer, where applicable.
   * For example com.soundrop, com.spotify.
   *
   * NOTE: This normally should be a readonly property and not be set
   * explicitly in the PlayerState as the Player will overwrite it when sending the request.
   */
  this.referrer_vendor = data.referrer_vendor || 'unknown';
}
inherit(PlayOrigin, Serializable);

/**
 * What kind of options user has
 * with the player. By default
 * all 'can_*' properties are set to true.
 * You might want to restrict some of them
 * in the special cases like ads (no skipping)
 * or radio no skipping prev.
 * @constructor
 * @param {Object} options The options data.
 */
function PlayOptions(options) {
  Serializable.call(this, [
    'repeat',
    'shuffle',
    'can_repeat',
    'can_shuffle',
    'can_skip_prev',
    'can_skip_next',
    'can_seek',
    'use_dmca_rules'
  ]);
  options = options || {};

  /**
   * True if repeat (repeat all, not single track repeat) is (or is to be) enabled.
   *
   * Default value is false
   */
  this.repeat = options.repeat !== undefined ? options.repeat : false;

  /**
   * True if shuffle is (or is to be) enabled.
   *
   * Default value is false
   */
  this.shuffle = options.shuffle !== undefined ? options.shuffle : false;

  /**
   * True if this context can be repeated. This would be false for instance in the
   * case of radio.
   *
   * Default value is true.
   */
  this.can_repeat = options.can_repeat !== undefined ? options.can_repeat : true;

  /**
   * True if this context can be shuffled. This would be false for instance in the
   * case of radio.
   *
   * Default value is true.
   */
  this.can_shuffle = options.can_shuffle !== undefined ? options.can_shuffle : true;

  /**
   * True if the user is (or should be) allowed to skip to the previous track.
   *
   * Default value is true.
   */
  this.can_skip_prev = options.can_skip_prev !== undefined ? options.can_skip_prev : true;

  /**
   * True if the user is (or should be) allowed to skip to the next track.
   *
   * Default value is true.
   */
  this.can_skip_next = options.can_skip_next !== undefined ? options.can_skip_next : true;

  /**
   * True if the user is (or should be) allowed to seek to a certain time in the
   * currently playing track.
   *
   * Default value is true.
   */
  this.can_seek = options.can_seek !== undefined ? options.can_seek : true;

  /**
   * True if the track player should automatically apply DMCA rules when playing.
   * DMCA rules should be enabled for users that have free radio in the US, and
   * controls how many tracks the user are allowed to skip etc.
   *
   * Default value is false.
   */
  this.use_dmca_rules = options.use_dmca_rules !== undefined ? options.use_dmca_rules : false;
}
inherit(PlayOptions, Serializable);

/**
 * The object accepting only defined properties.
 * To make sure only valid properties are passed
 * always use 'serialize()' when object value needed.
 * @constructor
 * @param {Array.<string>} allowedProps The list of the properties
 * that are supported for the object.
 */
function Serializable(allowedProps) {
  this._props = allowedProps || [];
}

/**
 * The JSON representation of the object.
 * @return {Object} Data associated with current player state.
 */
Serializable.prototype.serialize = function() {
  var data = {};
  var prop;

  for (var i = 0, l = this._props.length; i < l; i++) {
    prop = this._props[i];
    if (this[prop] !== undefined) {
      if (this[prop] instanceof Serializable) {
        data[prop] = this[prop].serialize();
      } else {
        data[prop] = this[prop];
      }
    }
  }

  return data;
};

exports.PlayerState = PlayerState;

},{"spotify-inheritance":117}],87:[function(require,module,exports){
var inherit = require('spotify-inheritance').inherit;

var Message = require('./message').Message;

/**
 * Request actions.
 *
 * @name exports.Action
 * @enum {string}
 */
exports.Action = {
  DELETE: 'DELETE',
  GET: 'GET',
  HEAD: 'HEAD',
  POST: 'POST',
  PUT: 'PUT',
  SUB: 'SUB',
  PATCH: 'PATCH'
};

/**
 * A serialized Request object.
 *
 * @name Spotify.Cosmos.SerializedRequest
 * @typedef {{
 *   uri: Spotify.Cosmos.URI,
 *   headers: Spotify.Cosmos.Headers,
 *   body: Spotify.Cosmos.Body
 * }}
 */
exports.SerializedRequest;

/**
 * Encapsulates a request to the handlers.
 *
 * Instances of this class are "immutable" and should not be changed.
 *
 * @constructs Spotify.Cosmos.Request
 * @extends Spotify.Cosmos.Message
 * @param {Spotify.Cosmos.Action} action The action of the request.
 * @param {Spotify.Cosmos.URI} uri The URI of the request
 * @param {Spotify.Cosmos.Headers=} opt_headers The optional headers of the
 *     request.
 * @param {Spotify.Cosmos.Body=} opt_body The optional body of the request.
 */
function Request(action, uri, opt_headers, opt_body) {
  if (!(this instanceof Request))
    return new Request(action, uri, opt_headers, opt_body);
  if (!action)
    throw new TypeError('Invalid `action` argument for Request.');
  Message.call(this, uri, opt_headers, opt_body);

  /**
   * The action of the request.
   *
   * @type {Spotify.Cosmos.Action}
   * @protected
   */
  this._action = action;
}
inherit(Request, Message);
exports.Request = Request;

/**
 * Creates a new Request from a SerializedRequest object.
 *
 * @param {Spotify.Cosmos.SerializedRequest} object The serialized request.
 * @return {Spotify.Cosmos.Request|null} The new Request object or null.
 */
Request.fromObject = function(object) {
  return (object && object.action && object.uri) ?
    new Request(
        object.action,
        object.uri,
        object.headers,
        object.body
    ) : null;
};

/**
 * Returns the action of the request.
 *
 * @return {Spotify.Cosmos.Action} The action of the request.
 */
Request.prototype.getAction = function() {
  return this._action;
};

/**
 * @inheritDoc
 */
Request.prototype.copy = function(opt_headers, opt_body) {
  return new Request(
      this._action,
      this._uri,
      this._copyHeaders(opt_headers),
      typeof opt_body != 'undefined' ? opt_body : this._body
  );
};

/**
 * @inheritDoc
 */
Request.prototype.toJSON = function() {
  return {
    action: this._action,
    uri: this._uri,
    headers: this._headers,
    body: this._body
  };
};



},{"./message":85,"spotify-inheritance":117}],88:[function(require,module,exports){
var inherit = require('spotify-inheritance').inherit;

var Message = require('./message').Message;

/**
 * Statuscode.
 * The statuses with negative numbers are reserved for
 * errors that originate within the cosmos library.
 *
 * @name exports.StatusCode
 * @enum {number}
 */
exports.StatusCode = {
  OK: 200,
  CREATED: 201,
  ACCEPTED: 202,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  METHOD_NOT_ALLOWED: 405,
  TIMED_OUT: 408,
  CONFLICT: 409,
  GONE: 410,
  INTERNAL_SERVER_ERROR: 500,
  NOT_IMPLEMENTED: 501,
  BAD_GATEWAY: 502,
  SERVICE_UNAVAILABLE: 503,

  /** Something went wrong, but the exact reason is not known. */
  ERROR_UNKNOWN: -100,

  /** A resource allocation required to complete the request failed. */
  ERROR_ALLOCATION_FAILED: -101,

  /** The body could not be decoded because it does
   not conform to the encoding header field. */
  ERROR_INVALID_ENCODING: -102,

  /** The router detected an infinite loop while processing the request. */
  ERROR_INFINITE_LOOP: -103,

  /** No endpoint resolver that could handle the request was found. */
  ERROR_RESOLVER_NOT_FOUND: -104
};

/**
 * A serialized Response object.
 *
 * @name Spotify.Cosmos.SerializedResponse
 * @typedef {{
 *   uri: Spotify.Cosmos.URI,
 *   status: Spotify.Cosmos.StatusCode,
 *   headers: Spotify.Cosmos.Headers,
 *   body: Spotify.Cosmos.Body
 * }}
 */
exports.SerializedResponse;

/**
 * Encapsulates a response from the handlers.
 *
 * @constructs Spotify.Cosmos.Response
 * @extends Spotify.Cosmos.Message
 * @param {Spotify.Cosmos.URI} uri The URI of the response
 * @param {Spotify.Cosmos.StatusCode} status The status of the response.
 * @param {Spotify.Cosmos.Headers=} opt_headers The optional headers of the
 *     response.
 * @param {Spotify.Cosmos.Body=} opt_body The optional body of the response.
 */
function Response(uri, status, opt_headers, opt_body) {
  if (!(this instanceof Response))
    return new Response(uri, status, opt_headers, opt_body, opt_requestURI);
  if (typeof status == 'undefined' || status == null)
    throw new TypeError('Invalid `status` argument for Response.');

  Message.call(this, uri, opt_headers, opt_body);

  /**
   * The Status of the Response.
   *
   * @type {Spotify.Cosmos.StatusCode}
   * @protected
   */
  this._status = status;
}
inherit(Response, Message);
exports.Response = Response;

/**
 * Creates a new Response from a SerializedResponse object.
 *
 * @param {Spotify.Cosmos.SerializedResponse} object The serialized response.
 * @return {Spotify.Cosmos.Response|null} The new Response object or null.
 */
Response.fromObject = function(object) {
  return (object && object.uri && object.status) ?
    new Response(
        object.uri,
        object.status,
        object.headers,
        object.body
    ) : null;
};

/**
 * @inheritDoc
 */
Response.prototype.getMimeType = function() {
  return this._headers['content-type'];
};

/**
 * Returns the status code of the Response.
 *
 * @return {Spotify.Cosmos.StatusCode} The status code of the response.
 */
Response.prototype.getStatusCode = function() {
  return this._status;
};

/**
 * @inheritDoc
 */
Response.prototype.copy = function(opt_headers, opt_body) {
  return new Response(
      this._uri,
      this._status,
      this._copyHeaders(opt_headers),
      typeof opt_body != 'undefined' ? opt_body : this._body
  );
};

/**
 * @inheritDoc
 */
Response.prototype.toJSON = function() {
  return {
    uri: this._uri,
    status: this._status,
    headers: this._headers,
    body: this._body
  };
};


},{"./message":85,"spotify-inheritance":117}],89:[function(require,module,exports){

/**
 * This is the web browser implementation of `debug()`.
 *
 * Expose `debug()` as the module.
 */

exports = module.exports = require('./debug');
exports.log = log;
exports.formatArgs = formatArgs;
exports.save = save;
exports.load = load;
exports.useColors = useColors;
exports.storage = 'undefined' != typeof chrome
               && 'undefined' != typeof chrome.storage
                  ? chrome.storage.local
                  : localstorage();

/**
 * Colors.
 */

exports.colors = [
  'lightseagreen',
  'forestgreen',
  'goldenrod',
  'dodgerblue',
  'darkorchid',
  'crimson'
];

/**
 * Currently only WebKit-based Web Inspectors, Firefox >= v31,
 * and the Firebug extension (any Firefox version) are known
 * to support "%c" CSS customizations.
 *
 * TODO: add a `localStorage` variable to explicitly enable/disable colors
 */

function useColors() {
  // is webkit? http://stackoverflow.com/a/16459606/376773
  return ('WebkitAppearance' in document.documentElement.style) ||
    // is firebug? http://stackoverflow.com/a/398120/376773
    (window.console && (console.firebug || (console.exception && console.table))) ||
    // is firefox >= v31?
    // https://developer.mozilla.org/en-US/docs/Tools/Web_Console#Styling_messages
    (navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) && parseInt(RegExp.$1, 10) >= 31);
}

/**
 * Map %j to `JSON.stringify()`, since no Web Inspectors do that by default.
 */

exports.formatters.j = function(v) {
  return JSON.stringify(v);
};


/**
 * Colorize log arguments if enabled.
 *
 * @api public
 */

function formatArgs() {
  var args = arguments;
  var useColors = this.useColors;

  args[0] = (useColors ? '%c' : '')
    + this.namespace
    + (useColors ? ' %c' : ' ')
    + args[0]
    + (useColors ? '%c ' : ' ')
    + '+' + exports.humanize(this.diff);

  if (!useColors) return args;

  var c = 'color: ' + this.color;
  args = [args[0], c, 'color: inherit'].concat(Array.prototype.slice.call(args, 1));

  // the final "%c" is somewhat tricky, because there could be other
  // arguments passed either before or after the %c, so we need to
  // figure out the correct index to insert the CSS into
  var index = 0;
  var lastC = 0;
  args[0].replace(/%[a-z%]/g, function(match) {
    if ('%%' === match) return;
    index++;
    if ('%c' === match) {
      // we only are interested in the *last* %c
      // (the user may have provided their own)
      lastC = index;
    }
  });

  args.splice(lastC, 0, c);
  return args;
}

/**
 * Invokes `console.log()` when available.
 * No-op when `console.log` is not a "function".
 *
 * @api public
 */

function log() {
  // this hackery is required for IE8/9, where
  // the `console.log` function doesn't have 'apply'
  return 'object' === typeof console
    && console.log
    && Function.prototype.apply.call(console.log, console, arguments);
}

/**
 * Save `namespaces`.
 *
 * @param {String} namespaces
 * @api private
 */

function save(namespaces) {
  try {
    if (null == namespaces) {
      exports.storage.removeItem('debug');
    } else {
      exports.storage.debug = namespaces;
    }
  } catch(e) {}
}

/**
 * Load `namespaces`.
 *
 * @return {String} returns the previously persisted debug modes
 * @api private
 */

function load() {
  var r;
  try {
    r = exports.storage.debug;
  } catch(e) {}
  return r;
}

/**
 * Enable namespaces listed in `localStorage.debug` initially.
 */

exports.enable(load());

/**
 * Localstorage attempts to return the localstorage.
 *
 * This is necessary because safari throws
 * when a user disables cookies/localstorage
 * and you attempt to access it.
 *
 * @return {LocalStorage}
 * @api private
 */

function localstorage(){
  try {
    return window.localStorage;
  } catch (e) {}
}

},{"./debug":90}],90:[function(require,module,exports){

/**
 * This is the common logic for both the Node.js and web browser
 * implementations of `debug()`.
 *
 * Expose `debug()` as the module.
 */

exports = module.exports = debug;
exports.coerce = coerce;
exports.disable = disable;
exports.enable = enable;
exports.enabled = enabled;
exports.humanize = require('ms');

/**
 * The currently active debug mode names, and names to skip.
 */

exports.names = [];
exports.skips = [];

/**
 * Map of special "%n" handling functions, for the debug "format" argument.
 *
 * Valid key names are a single, lowercased letter, i.e. "n".
 */

exports.formatters = {};

/**
 * Previously assigned color.
 */

var prevColor = 0;

/**
 * Previous log timestamp.
 */

var prevTime;

/**
 * Select a color.
 *
 * @return {Number}
 * @api private
 */

function selectColor() {
  return exports.colors[prevColor++ % exports.colors.length];
}

/**
 * Create a debugger with the given `namespace`.
 *
 * @param {String} namespace
 * @return {Function}
 * @api public
 */

function debug(namespace) {

  // define the `disabled` version
  function disabled() {
  }
  disabled.enabled = false;

  // define the `enabled` version
  function enabled() {

    var self = enabled;

    // set `diff` timestamp
    var curr = +new Date();
    var ms = curr - (prevTime || curr);
    self.diff = ms;
    self.prev = prevTime;
    self.curr = curr;
    prevTime = curr;

    // add the `color` if not set
    if (null == self.useColors) self.useColors = exports.useColors();
    if (null == self.color && self.useColors) self.color = selectColor();

    var args = Array.prototype.slice.call(arguments);

    args[0] = exports.coerce(args[0]);

    if ('string' !== typeof args[0]) {
      // anything else let's inspect with %o
      args = ['%o'].concat(args);
    }

    // apply any `formatters` transformations
    var index = 0;
    args[0] = args[0].replace(/%([a-z%])/g, function(match, format) {
      // if we encounter an escaped % then don't increase the array index
      if (match === '%%') return match;
      index++;
      var formatter = exports.formatters[format];
      if ('function' === typeof formatter) {
        var val = args[index];
        match = formatter.call(self, val);

        // now we need to remove `args[index]` since it's inlined in the `format`
        args.splice(index, 1);
        index--;
      }
      return match;
    });

    if ('function' === typeof exports.formatArgs) {
      args = exports.formatArgs.apply(self, args);
    }
    var logFn = enabled.log || exports.log || console.log.bind(console);
    logFn.apply(self, args);
  }
  enabled.enabled = true;

  var fn = exports.enabled(namespace) ? enabled : disabled;

  fn.namespace = namespace;

  return fn;
}

/**
 * Enables a debug mode by namespaces. This can include modes
 * separated by a colon and wildcards.
 *
 * @param {String} namespaces
 * @api public
 */

function enable(namespaces) {
  exports.save(namespaces);

  var split = (namespaces || '').split(/[\s,]+/);
  var len = split.length;

  for (var i = 0; i < len; i++) {
    if (!split[i]) continue; // ignore empty strings
    namespaces = split[i].replace(/\*/g, '.*?');
    if (namespaces[0] === '-') {
      exports.skips.push(new RegExp('^' + namespaces.substr(1) + '$'));
    } else {
      exports.names.push(new RegExp('^' + namespaces + '$'));
    }
  }
}

/**
 * Disable debug output.
 *
 * @api public
 */

function disable() {
  exports.enable('');
}

/**
 * Returns true if the given mode name is enabled, false otherwise.
 *
 * @param {String} name
 * @return {Boolean}
 * @api public
 */

function enabled(name) {
  var i, len;
  for (i = 0, len = exports.skips.length; i < len; i++) {
    if (exports.skips[i].test(name)) {
      return false;
    }
  }
  for (i = 0, len = exports.names.length; i < len; i++) {
    if (exports.names[i].test(name)) {
      return true;
    }
  }
  return false;
}

/**
 * Coerce `val`.
 *
 * @param {Mixed} val
 * @return {Mixed}
 * @api private
 */

function coerce(val) {
  if (val instanceof Error) return val.stack || val.message;
  return val;
}

},{"ms":102}],91:[function(require,module,exports){


    /**
     * Array forEach
     */
    function forEach(arr, callback, thisObj) {
        if (arr == null) {
            return;
        }
        var i = -1,
            len = arr.length;
        while (++i < len) {
            // we iterate over sparse items since there is no way to make it
            // work properly on IE 7-8. see #64
            if ( callback.call(thisObj, arr[i], i, arr) === false ) {
                break;
            }
        }
    }

    module.exports = forEach;



},{}],92:[function(require,module,exports){


    /**
     * Array.indexOf
     */
    function indexOf(arr, item, fromIndex) {
        fromIndex = fromIndex || 0;
        if (arr == null) {
            return -1;
        }

        var len = arr.length,
            i = fromIndex < 0 ? len + fromIndex : fromIndex;
        while (i < len) {
            // we iterate over sparse items since there is no way to make it
            // work properly on IE 7-8. see #64
            if (arr[i] === item) {
                return i;
            }

            i++;
        }

        return -1;
    }

    module.exports = indexOf;


},{}],93:[function(require,module,exports){
var mixIn = require('../object/mixIn');

    /**
     * Create Object using prototypal inheritance and setting custom properties.
     * - Mix between Douglas Crockford Prototypal Inheritance <http://javascript.crockford.com/prototypal.html> and the EcmaScript 5 `Object.create()` method.
     * @param {object} parent    Parent Object.
     * @param {object} [props] Object properties.
     * @return {object} Created object.
     */
    function createObject(parent, props){
        function F(){}
        F.prototype = parent;
        return mixIn(new F(), props);

    }
    module.exports = createObject;



},{"../object/mixIn":100}],94:[function(require,module,exports){
var kindOf = require('./kindOf');
    /**
     * Check if value is from a specific "kind".
     */
    function isKind(val, kind){
        return kindOf(val) === kind;
    }
    module.exports = isKind;


},{"./kindOf":96}],95:[function(require,module,exports){
var isKind = require('./isKind');
    /**
     */
    function isNumber(val) {
        return isKind(val, 'Number');
    }
    module.exports = isNumber;


},{"./isKind":94}],96:[function(require,module,exports){


    var _rKind = /^\[object (.*)\]$/,
        _toString = Object.prototype.toString,
        UNDEF;

    /**
     * Gets the "kind" of value. (e.g. "String", "Number", etc)
     */
    function kindOf(val) {
        if (val === null) {
            return 'Null';
        } else if (val === UNDEF) {
            return 'Undefined';
        } else {
            return _rKind.exec( _toString.call(val) )[1];
        }
    }
    module.exports = kindOf;


},{}],97:[function(require,module,exports){
var hasOwn = require('./hasOwn');

    var _hasDontEnumBug,
        _dontEnums;

    function checkDontEnum(){
        _dontEnums = [
                'toString',
                'toLocaleString',
                'valueOf',
                'hasOwnProperty',
                'isPrototypeOf',
                'propertyIsEnumerable',
                'constructor'
            ];

        _hasDontEnumBug = true;

        for (var key in {'toString': null}) {
            _hasDontEnumBug = false;
        }
    }

    /**
     * Similar to Array/forEach but works over object properties and fixes Don't
     * Enum bug on IE.
     * based on: http://whattheheadsaid.com/2010/10/a-safer-object-keys-compatibility-implementation
     */
    function forIn(obj, fn, thisObj){
        var key, i = 0;
        // no need to check if argument is a real object that way we can use
        // it for arrays, functions, date, etc.

        //post-pone check till needed
        if (_hasDontEnumBug == null) checkDontEnum();

        for (key in obj) {
            if (exec(fn, obj, key, thisObj) === false) {
                break;
            }
        }


        if (_hasDontEnumBug) {
            var ctor = obj.constructor,
                isProto = !!ctor && obj === ctor.prototype;

            while (key = _dontEnums[i++]) {
                // For constructor, if it is a prototype object the constructor
                // is always non-enumerable unless defined otherwise (and
                // enumerated above).  For non-prototype objects, it will have
                // to be defined on this object, since it cannot be defined on
                // any prototype objects.
                //
                // For other [[DontEnum]] properties, check if the value is
                // different than Object prototype value.
                if (
                    (key !== 'constructor' ||
                        (!isProto && hasOwn(obj, key))) &&
                    obj[key] !== Object.prototype[key]
                ) {
                    if (exec(fn, obj, key, thisObj) === false) {
                        break;
                    }
                }
            }
        }
    }

    function exec(fn, obj, key, thisObj){
        return fn.call(thisObj, obj[key], key, obj);
    }

    module.exports = forIn;



},{"./hasOwn":99}],98:[function(require,module,exports){
var hasOwn = require('./hasOwn');
var forIn = require('./forIn');

    /**
     * Similar to Array/forEach but works over object properties and fixes Don't
     * Enum bug on IE.
     * based on: http://whattheheadsaid.com/2010/10/a-safer-object-keys-compatibility-implementation
     */
    function forOwn(obj, fn, thisObj){
        forIn(obj, function(val, key){
            if (hasOwn(obj, key)) {
                return fn.call(thisObj, obj[key], key, obj);
            }
        });
    }

    module.exports = forOwn;



},{"./forIn":97,"./hasOwn":99}],99:[function(require,module,exports){


    /**
     * Safer Object.hasOwnProperty
     */
     function hasOwn(obj, prop){
         return Object.prototype.hasOwnProperty.call(obj, prop);
     }

     module.exports = hasOwn;



},{}],100:[function(require,module,exports){
var forOwn = require('./forOwn');

    /**
    * Combine properties from all the objects into first one.
    * - This method affects target object in place, if you want to create a new Object pass an empty object as first param.
    * @param {object} target    Target Object
    * @param {...object} objects    Objects to be combined (0...n objects).
    * @return {object} Target Object.
    */
    function mixIn(target, objects){
        var i = 0,
            n = arguments.length,
            obj;
        while(++i < n){
            obj = arguments[i];
            if (obj != null) {
                forOwn(obj, copyProp, target);
            }
        }
        return target;
    }

    function copyProp(val, key){
        this[key] = val;
    }

    module.exports = mixIn;


},{"./forOwn":98}],101:[function(require,module,exports){


    /**
     * Get current time in miliseconds
     */
    function now(){
        // yes, we defer the work to another function to allow mocking it
        // during the tests
        return now.get();
    }

    now.get = (typeof Date.now === 'function')? Date.now : function(){
        return +(new Date());
    };

    module.exports = now;



},{}],102:[function(require,module,exports){
/**
 * Helpers.
 */

var s = 1000;
var m = s * 60;
var h = m * 60;
var d = h * 24;
var y = d * 365.25;

/**
 * Parse or format the given `val`.
 *
 * Options:
 *
 *  - `long` verbose formatting [false]
 *
 * @param {String|Number} val
 * @param {Object} options
 * @return {String|Number}
 * @api public
 */

module.exports = function(val, options){
  options = options || {};
  if ('string' == typeof val) return parse(val);
  return options.long
    ? long(val)
    : short(val);
};

/**
 * Parse the given `str` and return milliseconds.
 *
 * @param {String} str
 * @return {Number}
 * @api private
 */

function parse(str) {
  str = '' + str;
  if (str.length > 10000) return;
  var match = /^((?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|years?|yrs?|y)?$/i.exec(str);
  if (!match) return;
  var n = parseFloat(match[1]);
  var type = (match[2] || 'ms').toLowerCase();
  switch (type) {
    case 'years':
    case 'year':
    case 'yrs':
    case 'yr':
    case 'y':
      return n * y;
    case 'days':
    case 'day':
    case 'd':
      return n * d;
    case 'hours':
    case 'hour':
    case 'hrs':
    case 'hr':
    case 'h':
      return n * h;
    case 'minutes':
    case 'minute':
    case 'mins':
    case 'min':
    case 'm':
      return n * m;
    case 'seconds':
    case 'second':
    case 'secs':
    case 'sec':
    case 's':
      return n * s;
    case 'milliseconds':
    case 'millisecond':
    case 'msecs':
    case 'msec':
    case 'ms':
      return n;
  }
}

/**
 * Short format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */

function short(ms) {
  if (ms >= d) return Math.round(ms / d) + 'd';
  if (ms >= h) return Math.round(ms / h) + 'h';
  if (ms >= m) return Math.round(ms / m) + 'm';
  if (ms >= s) return Math.round(ms / s) + 's';
  return ms + 'ms';
}

/**
 * Long format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */

function long(ms) {
  return plural(ms, d, 'day')
    || plural(ms, h, 'hour')
    || plural(ms, m, 'minute')
    || plural(ms, s, 'second')
    || ms + ' ms';
}

/**
 * Pluralization helper.
 */

function plural(ms, n, name) {
  if (ms < n) return;
  if (ms < n * 1.5) return Math.floor(ms / n) + ' ' + name;
  return Math.ceil(ms / n) + ' ' + name + 's';
}

},{}],103:[function(require,module,exports){
(function (process,global){
/*
defer
*/"use strict"

var kindOf  = require("mout/lang/kindOf"),
    now     = require("mout/time/now"),
    forEach = require("mout/array/forEach"),
    indexOf = require("mout/array/indexOf")

var callbacks = {
    timeout: {},
    frame: [],
    immediate: []
}

var push = function(collection, callback, context, defer){

    var iterator = function(){
        iterate(collection)
    }

    if (!collection.length) defer(iterator)

    var entry = {
        callback: callback,
        context: context
    }

    collection.push(entry)

    return function(){
        var io = indexOf(collection, entry)
        if (io > -1) collection.splice(io, 1)
    }
}

var iterate = function(collection){
    var time = now()

    forEach(collection.splice(0), function(entry) {
        entry.callback.call(entry.context, time)
    })
}

var defer = function(callback, argument, context){
    return (kindOf(argument) === "Number") ? defer.timeout(callback, argument, context) : defer.immediate(callback, argument)
}

if (global.process && process.nextTick){

    defer.immediate = function(callback, context){
        return push(callbacks.immediate, callback, context, process.nextTick)
    }

} else if (global.setImmediate){

    defer.immediate = function(callback, context){
        return push(callbacks.immediate, callback, context, setImmediate)
    }

} else if (global.postMessage && global.addEventListener){

    addEventListener("message", function(event){
        if (event.source === global && event.data === "@deferred"){
            event.stopPropagation()
            iterate(callbacks.immediate)
        }
    }, true)

    defer.immediate = function(callback, context){
        return push(callbacks.immediate, callback, context, function(){
            postMessage("@deferred", "*")
        })
    }

} else {

    defer.immediate = function(callback, context){
        return push(callbacks.immediate, callback, context, function(iterator){
            setTimeout(iterator, 0)
        })
    }

}

var requestAnimationFrame = global.requestAnimationFrame ||
    global.webkitRequestAnimationFrame ||
    global.mozRequestAnimationFrame ||
    global.oRequestAnimationFrame ||
    global.msRequestAnimationFrame ||
    function(callback) {
        setTimeout(callback, 1e3 / 60)
    }

defer.frame = function(callback, context){
    return push(callbacks.frame, callback, context, requestAnimationFrame)
}

var clear

defer.timeout = function(callback, ms, context){
    var ct = callbacks.timeout

    if (!clear) clear = defer.immediate(function(){
        clear = null
        callbacks.timeout = {}
    })

    return push(ct[ms] || (ct[ms] = []), callback, context, function(iterator){
        setTimeout(iterator, ms)
    })
}

module.exports = defer

}).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"_process":106,"mout/array/forEach":91,"mout/array/indexOf":92,"mout/lang/kindOf":96,"mout/time/now":101}],104:[function(require,module,exports){
/*
Emitter
*/"use strict"

var indexOf = require("mout/array/indexOf"),
    forEach = require("mout/array/forEach")

var prime = require("./index"),
    defer = require("./defer")

var slice = Array.prototype.slice;

var Emitter = prime({

    constructor: function(stoppable){
        this._stoppable = stoppable
    },

    on: function(event, fn){
        var listeners = this._listeners || (this._listeners = {}),
            events = listeners[event] || (listeners[event] = [])

        if (indexOf(events, fn) === -1) events.push(fn)

        return this
    },

    off: function(event, fn){
        var listeners = this._listeners, events
        if (listeners && (events = listeners[event])){

            var io = indexOf(events, fn)
            if (io > -1) events.splice(io, 1)
            if (!events.length) delete listeners[event];
            for (var l in listeners) return this
            delete this._listeners
        }
        return this
    },

    emit: function(event){
        var self = this,
            args = slice.call(arguments, 1)

        var emit = function(){
            var listeners = self._listeners, events
            if (listeners && (events = listeners[event])){
                forEach(events.slice(0), function(event){
                    var result = event.apply(self, args)
                    if (self._stoppable) return result
                })
            }
        }

        if (args[args.length - 1] === Emitter.EMIT_SYNC){
            args.pop()
            emit()
        } else {
            defer(emit)
        }

        return this
    }

})

Emitter.EMIT_SYNC = {}

module.exports = Emitter

},{"./defer":103,"./index":105,"mout/array/forEach":91,"mout/array/indexOf":92}],105:[function(require,module,exports){
/*
prime
 - prototypal inheritance
*/"use strict"

var hasOwn = require("mout/object/hasOwn"),
    mixIn  = require("mout/object/mixIn"),
    create = require("mout/lang/createObject"),
    kindOf = require("mout/lang/kindOf")

var hasDescriptors = true

try {
    Object.defineProperty({}, "~", {})
    Object.getOwnPropertyDescriptor({}, "~")
} catch (e){
    hasDescriptors = false
}

// we only need to be able to implement "toString" and "valueOf" in IE < 9
var hasEnumBug = !({valueOf: 0}).propertyIsEnumerable("valueOf"),
    buggy      = ["toString", "valueOf"]

var verbs = /^constructor|inherits|mixin$/

var implement = function(proto){
    var prototype = this.prototype

    for (var key in proto){
        if (key.match(verbs)) continue
        if (hasDescriptors){
            var descriptor = Object.getOwnPropertyDescriptor(proto, key)
            if (descriptor){
                Object.defineProperty(prototype, key, descriptor)
                continue
            }
        }
        prototype[key] = proto[key]
    }

    if (hasEnumBug) for (var i = 0; (key = buggy[i]); i++){
        var value = proto[key]
        if (value !== Object.prototype[key]) prototype[key] = value
    }

    return this
}

var prime = function(proto){

    if (kindOf(proto) === "Function") proto = {constructor: proto}

    var superprime = proto.inherits

    // if our nice proto object has no own constructor property
    // then we proceed using a ghosting constructor that all it does is
    // call the parent's constructor if it has a superprime, else an empty constructor
    // proto.constructor becomes the effective constructor
    var constructor = (hasOwn(proto, "constructor")) ? proto.constructor : (superprime) ? function(){
        return superprime.apply(this, arguments)
    } : function(){}

    if (superprime){

        mixIn(constructor, superprime)

        var superproto = superprime.prototype
        // inherit from superprime
        var cproto = constructor.prototype = create(superproto)

        // setting constructor.parent to superprime.prototype
        // because it's the shortest possible absolute reference
        constructor.parent = superproto
        cproto.constructor = constructor
    }

    if (!constructor.implement) constructor.implement = implement

    var mixins = proto.mixin
    if (mixins){
        if (kindOf(mixins) !== "Array") mixins = [mixins]
        for (var i = 0; i < mixins.length; i++) constructor.implement(create(mixins[i].prototype))
    }

    // implement proto and return constructor
    return constructor.implement(proto)

}

module.exports = prime

},{"mout/lang/createObject":93,"mout/lang/kindOf":96,"mout/object/hasOwn":99,"mout/object/mixIn":100}],106:[function(require,module,exports){
// shim for using process in browser

var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

(function () {
  try {
    cachedSetTimeout = setTimeout;
  } catch (e) {
    cachedSetTimeout = function () {
      throw new Error('setTimeout is not defined');
    }
  }
  try {
    cachedClearTimeout = clearTimeout;
  } catch (e) {
    cachedClearTimeout = function () {
      throw new Error('clearTimeout is not defined');
    }
  }
} ())
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = cachedSetTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    cachedClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        cachedSetTimeout(drainQueue, 0);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };

},{}],107:[function(require,module,exports){
/*jslint node: true */

'use strict';

var ClientRequest = require('./request').ClientRequest;

/**
 * An autoincremented id that is used to distinguish Resolver instances.
 *
 * @type {number}
 * @private
 */
var resolverUID = 0;

/**
 * A resolver takes a request for a resources and sends it through the
 * transport.
 *
 * @constructs Resolver
 */
function Resolver() {
  if (!(this instanceof Resolver))
    return new Resolver();

  /**
   * The resolver's id.
   *
   * @type {number}
   * @protected
   */
  this._id = resolverUID++;

  /**
   * An incrementing ID used for tracking requests.
   *
   * @type {number}
   * @protected
   */
  this._requestID = 0;

  /**
   * Storage for the sent request handlers waiting for a response.
   *
   * @type {Object.<string, function>}
   * @protected
   */
  this._handlers = {};
}
exports.Resolver = Resolver;

/**
 * Adds a handler to the internal storage.
 *
 * @param {number} requestID The identifier for the request.
 * @param {ClientRequest} handler The handler for the request.
 * @protected
 */
Resolver.prototype._addHandler = function(requestID, handler) {
  this._handlers[requestID] = handler;
  return this;
};

/**
 * Removes a handler from the internal storage.
 *
 * @param {number} requestID The identifier for the request.
 * @protected
 */
Resolver.prototype._removeHandler = function(requestID) {
  this._handlers[requestID] = null;
  return this;
};

/**
 * Sends a request through the transport.
 *
 * Subclasses of this class need to implement this method.
 *
 * @param {number} requestID The id of the request.
 * @param {Object} data The payload data for the request.
 * @protected
 */
Resolver.prototype._sendRequest = function(requestID, data) {
  throw new Error('Resolver _sendRequest not implemented.');
};

/**
 * Handles a response from the transport.
 *
 * @param {Object} response The response from the transport.
 * @protected
 */
Resolver.prototype._handleResponse = function(response) {
  throw new Error('Resolver _handleResponse not implemented.');
};

/**
 * Dispatches a request handler with some data.
 *
 * @param {number} requestID The request handler to dispatch.
 * @param {Object} data The response data to send back.
 * @protected
 */
Resolver.prototype._dispatchResponse = function(requestID, requestType, data) {
  var handler = this._handlers[requestID];
  if (!handler) return;
  handler._handleResponse(requestType, data);
};

/**
 * Resolves a request (represented by the data) through the transport.
 *
 * @param {Object} data The data representing the request.
 * @param {function} onsuccess The success handler for the request.
 * @param {function} onerror The error handler for the request.
 */
Resolver.prototype._resolve = function(data, onsuccess, onerror) {
  if (!data || !onsuccess || !onerror ||
      typeof onsuccess != 'function' || typeof onerror != 'function')
    throw new TypeError('Invalid argument length for `resolve`.');

  var requestID = ++this._requestID;
  var request = new ClientRequest(this, requestID, data, onsuccess, onerror);

  this._addHandler(requestID, request);

  request.onClose = this._removeHandler.bind(this);
  request.open();

  return request;
};

/**
 * Resolves a single request (represented by the data) through the transport.
 *
 * @param {Object} data The data representing the request.
 * @param {function} onsuccess The success handler for the request.
 * @param {function} onerror The error handler for the request.
 */
Resolver.prototype.resolve = function(data, onsuccess, onerror) {
  throw new Error('Resolver resolve not implemented.');
};

/**
 * Resolves a subscription request (represented by the data) through the transport.
 *
 * @param {Object} data The data representing the request.
 * @param {function} onsuccess The success handler for the request.
 * @param {function} onerror The error handler for the request.
 */
Resolver.prototype.subscribe = function(data, onsuccess, onerror) {
  throw new Error('Resolver subscribe not implemented.');
};

},{"./request":111}],108:[function(require,module,exports){
(function (global){
/*jslint node: true */

'use strict';

var defer = require('spotify-deferred');
var Resolver = require('./bootstrap').Resolver;

/**
 * A mock resolver for a nodejs environment.
 *
 * This resolver uses regular callbacks as a transport.
 *
 * @constructs Cosmos.MockResolver
 * @extends Cosmos.Resolver
 */
function MockResolver() {
  if (!(this instanceof MockResolver))
    return new MockResolver();
  Resolver.call(this);

  // rebind the _handleResponse method so that we can reuse it for both
  // addEventListener and removeEventListener
  this._handleResponse = this._handleResponse.bind(this);

  /**
   * The identifier for request messages.
   *
   * @type {string}
   * @protected
   */
  this._requestMessageType = 'cosmos-request';

  /**
   * The identifier for response messages.
   *
   * @type {string}
   * @protected
   */
  this._responseMessageType = 'cosmos-response';

  /**
   * Prefix for the requests ids to prevent clashes
   * with bridge requests in webplayer
   *
   * @type {string}
   * @private
   */
  this._requestIdPrefix = 'cosmos_';

  this._handlersMap = {};

  // attach the handler
  this.attach();
}
MockResolver.prototype = new Resolver();
MockResolver.prototype.constructor = MockResolver;
exports.MockResolver = MockResolver;

/**
 * @inheritDoc
 */
MockResolver.prototype._sendRequest = function(requestName, requestID, data) {
  var self = this;

  var message = {
    type: this._requestMessageType,
    resolver: this._id,
    id: this._requestIdPrefix + requestID,
    name: requestName,
    payload: data.serialize ? data.serialize() : data
  };

  if (!this._handlersMap[data._action]) {
    return;
  }

  if (!this._handlersMap[data._action][data._uri]) {
    return;
  }

  this._handlersMap[data._action][data._uri](data, function (status, resp) {
    message.payload = {
      body: typeof resp !== 'undefined' ? resp : status,
      uri: data._uri,
      status: typeof resp !== 'undefined' ? status : 200
    };
    message.type = self._responseMessageType;

    var response = {
      data: message
    };
    self._handleResponse(response);
  });
};

/**
 * @inheritDoc
 */
MockResolver.prototype._handleResponse = function(response) {
  var data = response.data;
  if (typeof data == 'string') {
    try {
      data = JSON.parse(response.data);
    } catch (e) {
      return;
    }
  }
  if (data.type != this._responseMessageType ||
      data.resolver != this._id ||
      !data.payload) return;
  var id = data.id || '';
  var requestID = parseInt(id.replace(this._requestIdPrefix, ''), 10);
  var requestName = data.name || '';
  if (!requestID || !requestName) return;
  this._dispatchResponse(requestID, requestName, data.payload);
};

/**
 * Attaches the resolver so that it could process calls from the window object.
 */
MockResolver.prototype.attach = function() {
  var win = global.window;
  if (win) {
    win._cosmosRequest = this.resolve.bind(this);
  }
};

/**
 * Detaches the resolver so that it doesn't process calls from the window object.
 */
MockResolver.prototype.detach = function() {
  var win = global.window;
  if (win) {
    delete win._cosmosRequest;
  }
};

/**
 * Specific method for the mock resolver to add request handlers
 *
 * @param {string}   method       Type of method (GET, POST, PUT, SUB)
 * @param {string}   uri          Request to handle
 * @param {Function} fn           Function that handles the request
 */
MockResolver.prototype.addHandler = function(method, uri, fn) {
  if (!this._handlersMap[method]) {
    this._handlersMap[method] = {};
  }

  this._handlersMap[method][uri] = fn;
};

/**
 * Specific method for the mock resolver to remove a specific request handler
 *
 * @param {string}   method       Type of method (GET, POST, PUT, SUB)
 * @param {string}   uri          Request to handle
 */
MockResolver.prototype.removeHandler = function(method, uri) {
  if (!this._handlersMap[method]) {
    return;
  }

  if (this._handlersMap[method][uri]) {
    delete this._handlersMap[method][uri];
  }
};

/**
 * Specific method for the mock resolver to remove all handlers
 */
MockResolver.prototype.clearHandlers = function() {
  this._handlersMap = {};
};

/**
 * Resolves a single request (represented by the data) through the transport.
 * Single requests need to be closed immediately after the response is
 * received.
 *
 * @param {Object} data The data representing the request.
 * @param {function} onsuccess The success handler for the request.
 * @param {function} onerror The error handler for the request.
 */
MockResolver.prototype.resolve = function(data, onsuccess, onerror) {
  function onResult(callback, response) {
    defer(callback.bind(this, response));
    request.close();
  }

  var request = this._resolve(data, onResult.bind(this, onsuccess), onResult.bind(this, onerror));
  return request;
};

/**
 * Resolves a  subscription request (represented by the data) through the transport.
 * Subscriptions stay open until they're explicitly closed.
 * Every time the request returns some data pull for next
 * batch is sent.
 *
 * @param {Object} data The data representing the request.
 * @param {function} onsuccess The success handler for the request.
 * @param {function} onerror The error handler for the request.
 */
MockResolver.prototype.subscribe = function(data, onsuccess, onerror) {
  return this._resolve(data, onsuccess, onerror);
};

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"./bootstrap":107,"spotify-deferred":113}],109:[function(require,module,exports){
(function (global){
/*jslint node: true */

'use strict';

var SpotifyApi = global.SpotifyApi;
var useApiRequest = !!(SpotifyApi && SpotifyApi.api &&
    typeof SpotifyApi.api.request === 'function');

var Resolver = require('./bootstrap').Resolver;
var defer = require('spotify-deferred');

/**
 * A resolver for a native environment.
 *
 * This resolver uses the Stitch bridge as a transport
 *
 * @constructs Cosmos.NativeResolver
 * @extends Cosmos.Resolver
 * @param {Object} spBridge Spotify CPP/JS bridge
 */
function NativeResolver(spBridge) {
  if (!(this instanceof NativeResolver))
    return new NativeResolver();
  if (!spBridge) {
    throw new TypeError('Missing `spBridge` parameter');
  }
  Resolver.call(this);

  this._bridge = spBridge;

  this._deferredFlush = false;
}
NativeResolver.prototype = new Resolver();
NativeResolver.prototype.constructor = NativeResolver;
exports.NativeResolver = NativeResolver;

/**
 * Prepare bridge flush.
 * TODO: Move to the separate module
 */
NativeResolver.prototype._prepareCoreFlush = function() {
  if (!this._deferredFlush) {
    this._deferredFlush = true;
    this._defer(this, this._flushRequests);
  }
};

/**
 * Flush bridge requests.
 * TODO: Move to the separate module
 */
NativeResolver.prototype._flushRequests = function() {
  this._deferredFlush = false;
  var flushMsg = JSON.stringify({ name: 'core_flush', args: []});
  this._sendBridgeRequest(flushMsg, {
    onSuccess: function() {},
    onFailure: function() {}
  });
};

/**
 * Defer the function call.
 * TODO: Move to the separate module
 */
NativeResolver.prototype._defer = function(context, callback) {
  defer(callback.bind(context));
};

/**
 * If SpotifyApi is loaded, use api requests to send messages to bridge
 * TODO: Use proxy that will handle Cosmos/Stitch calls for the resolver.
 */
NativeResolver.prototype._sendRequest = function(requestName, requestId, data) {
  var self = this;
  data = (data.serialize ? data.serialize() : data);

  var args = [requestId, data];
  var caller = { self: this, id: requestId, type: requestName };

  if (useApiRequest) {
    this._sendApiRequest(requestName, args, caller, this._handleResponse, this._handleError);
  } else {
    this._sendCosmosRequest(requestName, args, caller, this._handleResponse, this._handleError);
  }
};


/**
 * Talk to bridge directly from Cosmos
 * TODO: Move to the separate module
 */
NativeResolver.prototype._sendCosmosRequest = function(requestName, args, caller, onSuccess, onError) {
  var message = JSON.stringify({
    name: requestName,
    args: args
  });

  this._sendBridgeRequest(message, {
    onSuccess: function(data) {
      onSuccess.call(caller, JSON.parse(data));
    },
    onFailure: function(data) {
      data = JSON.parse(data);
      onError.call(caller, data);
    }
  });

  this._prepareCoreFlush();
};

/**
 * Send message to the bridge
 * @param {string} message The message to send to the bridge.
 * @param {Object.<string, function>} callbackMap The `onSuccess`
 * and `onFailure` functions to be executed after request is completed.
 * TODO: Use proxy that will handle Cosmos/Stitch calls for the resolver.
 */
NativeResolver.prototype._sendBridgeRequest = function(message, callbackMap) {
  this._bridge.executeRequest(message, callbackMap || {});
};

/**
 * Use old API to send messages to the bridge.
 * TODO: Move to the separate module
 */
NativeResolver.prototype._sendApiRequest = function(requestName, args, caller, onSuccess, onError) {
  SpotifyApi.api.request(
      requestName,
      args,
      caller,
      onSuccess,
      onError
  );
};

/**
 * Handles successful responses from the bridge
 * @param {Object} data The response data.
 */
NativeResolver.prototype._handleResponse = function(data) {
  this.self._dispatchResponse(this.id, this.type, data.responses && data.responses[0] || data);
};

/**
 * Handles failed responses from the bridge
 * @param {Object} error The error data.
 */
NativeResolver.prototype._handleError = function(error) {
  this.self._dispatchResponse(this.id, this.type, error);
};

/**
 * Resolves a single request (represented by the data) through the transport.
 * Single requests need to be closed immediately after the response is
 * received.
 *
 * @param {Object} data The data representing the request.
 * @param {function} onsuccess The success handler for the request.
 * @param {function} onerror The error handler for the request.
 */
NativeResolver.prototype.resolve = function(data, onsuccess, onerror) {
  function onResult(callback, response) {
    this._defer(this, callback.bind(this, response));
    request.close();
  }

  var request = this._resolve(data, onResult.bind(this, onsuccess), onResult.bind(this, onerror));
  return request;
};

/**
 * Resolves a  subscription request (represented by the data) through the transport.
 * Subscriptions stay open until they're explicitly closed.
 * Every time the request returns some data pull for next
 * batch is sent.
 *
 * @param {Object} data The data representing the request.
 * @param {function} onsuccess The success handler for the request.
 * @param {function} onerror The error handler for the request.
 */
NativeResolver.prototype.subscribe = function(data, onsuccess, onerror) {
  function onResult(callback, response) {
    callback.call(this, response);
    request.pull();
  }

  var request = this._resolve(data, onResult.bind(this, onsuccess), onResult.bind(this, onerror));
  return request;
};

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"./bootstrap":107,"spotify-deferred":113}],110:[function(require,module,exports){
(function (global){
/*jslint node: true */

'use strict';

var defer = require('spotify-deferred');
var Resolver = require('./bootstrap').Resolver;

/**
 * A resolver for a web-based environment.
 *
 * This resolver uses postMessage as a transport.
 *
 * @constructs Cosmos.WebResolver
 * @extends Cosmos.Resolver
 * @type {string=} opt_target The optional target for the postMessage calls.
 */
function WebResolver(opt_target) {
  if (!(this instanceof WebResolver))
    return new WebResolver(opt_target);
  Resolver.call(this);

  /**
   * The target for postMessage calls.
   *
   * @type {string}
   * @protected
   */
  this._target = opt_target || '*';

  // rebind the _handleResponse method so that we can reuse it for both
  // addEventListener and removeEventListener
  this._handleResponse = this._handleResponse.bind(this);

  /**
   * The identifier for request messages.
   *
   * @type {string}
   * @protected
   */
  this._requestMessageType = 'cosmos-request';

  /**
   * The identifier for response messages.
   *
   * @type {string}
   * @protected
   */
  this._responseMessageType = 'cosmos-response';

  /**
   * Prefix for the requests ids to prevent clashes
   * with bridge requests in webplayer
   *
   * @type {string}
   * @private
   */
  this._requestIdPrefix = 'cosmos_';

  // attach the handler
  this.attach();
}
WebResolver.prototype = new Resolver();
WebResolver.prototype.constructor = WebResolver;
exports.WebResolver = WebResolver;

/**
 * @inheritDoc
 */
WebResolver.prototype._sendRequest = function(requestName, requestID, data) {
  var top = global.window.top;

  var message = {
    type: this._requestMessageType,
    resolver: this._id,
    id: this._requestIdPrefix + requestID,
    name: requestName,
    payload: data.serialize ? data.serialize() : data
  };
  top.postMessage(JSON.stringify(message), this._target);
};

/**
 * @inheritDoc
 */
WebResolver.prototype._handleResponse = function(response) {
  var data = response.data;
  if (typeof data == 'string') {
    try {
      data = JSON.parse(response.data);
    } catch (e) {
      return;
    }
  }
  if (data.type != this._responseMessageType ||
      data.resolver != this._id ||
      !data.payload) return;
  var id = data.id || '';
  var requestID = parseInt(id.replace(this._requestIdPrefix, ''), 10);
  var requestName = data.name || '';
  if (!requestID || !requestName) return;
  this._dispatchResponse(requestID, requestName, data.payload);
};

/**
 * Attaches the resolver so that it could process postMessage calls.
 */
WebResolver.prototype.attach = function() {
  var win = global.window;
  if (win.addEvent && !win.addEventListener) {
    win.addEvent('onmessage', this._handleResponse);
  } else {
    win.addEventListener('message', this._handleResponse, false);
  }
};

/**
 * Detaches the resolver so that it doesn't process postMessage calls.
 */
WebResolver.prototype.detach = function() {
  var win = global.window;
  if (win.removeEvent && !win.removeEventListener) {
    win.removeEvent('onmessage', this._handleResponse);
  } else {
    win.removeEventListener('message', this._handleResponse, false);
  }
};

/**
 * Resolves a single request (represented by the data) through the transport.
 * Single requests need to be closed immediately after the response is
 * received.
 *
 * @param {Object} data The data representing the request.
 * @param {function} onsuccess The success handler for the request.
 * @param {function} onerror The error handler for the request.
 */
WebResolver.prototype.resolve = function(data, onsuccess, onerror) {
  function onResult(callback, response) {
    defer(callback.bind(this, response));
    request.close();
  }

  var request = this._resolve(data, onResult.bind(this, onsuccess), onResult.bind(this, onerror));
  return request;
};

/**
 * Resolves a  subscription request (represented by the data) through the transport.
 * Subscriptions stay open until they're explicitly closed.
 * Every time the request returns some data pull for next
 * batch is sent.
 *
 * @param {Object} data The data representing the request.
 * @param {function} onsuccess The success handler for the request.
 * @param {function} onerror The error handler for the request.
 */
WebResolver.prototype.subscribe = function(data, onsuccess, onerror) {
  return this._resolve(data, onsuccess, onerror);
};

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"./bootstrap":107,"spotify-deferred":113}],111:[function(require,module,exports){
/*jslint node: true */

'use strict';

var defer = require('spotify-deferred');

/**
 * The representation of the connection to the client.
 * With introduction of Cosmos subscription the model of making
 * client requests changed.
 * Each Cosmos requests now needs to be explicitly cancelled to
 * close the connection.
 * Simple requests that only send or retrieve data (e.g POST and GET)
 * need to send 'cosmos_request_cancel' message immediately after the response
 * is received.
 * Subscription requests need to send a 'cosmos_request_pull' message every time
 * they receive data. The consumer of the subscription needs to cancel the subscription
 * when no more data should be sent from the provider.
 */
function ClientRequest(resolver, requestId, data, onsuccess, onerror) {

  /**
   * Request identifier.
   * @type {number}
   */
  this._requestId = requestId;

  /**
   * Either web or native request resolver.
   * @type {Cosmos.Resolver}
   */
  this._resolver = resolver;

  /**
   * Data that should be passed with every request.
   * @type {*}
   */
  this._requestData = data;

  /**
   * Triggered on success
   * @type {function}
   */
  this._successCallback = onsuccess;

  /**
   * Triggered on error
   * @type {function}
   */
  this._errorCallback = onerror;

  /**
   * Current state of the request.
   * @type {ClientRequest.status}
   */
  this._status = ClientRequest.status.INITIALIZED;
}
exports.ClientRequest = ClientRequest;

/**
 * Possible state of the ClientRequest instance.
 */
ClientRequest.status = {
  INITIALIZED: 'INITIALIZED',
  CLOSED: 'CLOSED',
  OPEN: 'OPEN'
};

/**
 * Possible desktop bridge messages.
 */
ClientRequest.messages = {
  OPEN: 'cosmos_request_create',
  PULL: 'cosmos_request_pull',
  CLOSE: 'cosmos_request_cancel'
};

/**
 * Opens the connection with the client.
 */
ClientRequest.prototype.open = function() {
  if (this._status === ClientRequest.status.INITIALIZED) {
    this._status = ClientRequest.status.OPEN;
    this._sendRequest(ClientRequest.messages.OPEN, this._requestData);
  }
};

/**
 * Send pull request for the open connection.
 * For subscriptions pull should resolve to a
 * piece of data.
 */
ClientRequest.prototype.pull = function() {
  if (this._status === ClientRequest.status.OPEN) {
    this._sendRequest(ClientRequest.messages.PULL, this._requestData);
  }
  return this._status;
};

/**
 * Closes the connection with the client.
 */
ClientRequest.prototype.close = function() {
  if (this._status === ClientRequest.status.OPEN) {
    this._status = ClientRequest.status.CLOSE;
    this._sendRequest(ClientRequest.messages.CLOSE);
  }
};

ClientRequest.prototype.onClose = function() {};

/**
 * Sends the request to the platform specific resolver
 * @param {string} requestName The message type. One of the {ClientRequest.messages}.
 * @param {object?} data The data to send with the request.
 */
ClientRequest.prototype._sendRequest = function(requestName, data) {
  this._resolver._sendRequest(requestName, this._requestId, data || {});
};

/**
 * Handles the response for the given request
 * @param {String} requestName The message type. One of the {ClientRequest.messages}.
 * @param {Object} data The response data.
 */
ClientRequest.prototype._handleResponse = function(requestName, data) {
  var self = this;
  var status = data && data.status;
  var callback;

  if (requestName === ClientRequest.messages.CLOSE) {
    this._successCallback = null;
    this._errorCallback = null;
    this._requestData = null;
    this.onClose(this._requestId);
    return;
  }

  callback = this._successCallback;
  callback = typeof callback === 'function' ? callback : function() {};
  defer(callback.bind(this, data));
};

},{"spotify-deferred":113}],112:[function(require,module,exports){
(function (global){
'use strict';

var window = global.window || {};
var process = global.process;

var common = require('cosmos-common-js');
var Resolver = require('./scripts/resolver').Resolver;

var SPResolver = null;
var spResolver = null;

var hasNativeBridge = window._getSpotifyModule &&
    typeof window._getSpotifyModule === 'function' &&
    window._getSpotifyModule('bridge');

var nodeRegex = /(node)|(grunt)|(iojs)(\.exe)*$/;
var isNodeJs = process && process.title && nodeRegex.test(process.argv[0]);

if (!isNodeJs) {
  if (hasNativeBridge) {
    SPResolver = require('./env/bootstrap.native.js').NativeResolver;
    spResolver = new SPResolver(hasNativeBridge);
  } else {
    SPResolver = require('./env/bootstrap.web.js').WebResolver;
    spResolver = new SPResolver();
  }
} else {
  SPResolver = require('./env/bootstrap.mock.js').MockResolver;
  spResolver = new SPResolver();

  exports.mockResolver = {
    addHandler: spResolver.addHandler.bind(spResolver),
    removeHandler: spResolver.removeHandler.bind(spResolver),
    clearHandlers: spResolver.clearHandlers.bind(spResolver)
  };
}

exports.Resolver = Resolver;
exports.Action = common.request.Action;
exports.Request = common.request.Request;
exports.Response = common.response.Response;
exports.resolver = spResolver ? new Resolver(spResolver) : null;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"./env/bootstrap.mock.js":108,"./env/bootstrap.native.js":109,"./env/bootstrap.web.js":110,"./scripts/resolver":114,"cosmos-common-js":84}],113:[function(require,module,exports){
/**
 * @file
 * Introduces a function called "defer" that allows functions to be
 * executed in the next available tick.
 *
 * Unlike "setTimeout", "defer" executes the function at the nearest
 * possible time without clamping.
 *
 * @see Spotify.defer
 */
'use strict';

var PostRouter = require('spotify-postrouter');


/**
 * Storage for deferred functions to be executed.
 *
 * @type {Array.<function()>}
 * @private
 */
var deferred = [];


/**
 * A bound version of the postMessage routine used to trigger deferred
 * execution.
 *
 * @type {function()}
 * @private
 */
var send = function () {
  PostRouter.sendLocalMessage('execute_deferreds');
};


/**
 * Executes the deferred functions when the window
 * receives an 'execute_deferreds' message.
 *
 * @private
 */
function executeDeferreds() {
  var fns = deferred.splice(0);
  if (!fns.length) return;
  for (var i = 0, l = fns.length; i < l; i++) {
    try {
      fns[i]();
    } finally {
      // Do nothing.
      null;
    }
  }
}

PostRouter.addMessageHandler('execute_deferreds', executeDeferreds);


/**
 * Executes the function applied at the nearest possible time without
 * clamping.
 *
 * @param {function()} fn The function to execute.
 */
var defer = function(fn) {
  var trigger = !deferred.length;
  deferred.push(fn);
  if (trigger) send();
};


/**
 * Export public interface
 */
module.exports = defer;

},{"spotify-postrouter":119}],114:[function(require,module,exports){
var common = require('cosmos-common-js');

var Request = common.request.Request;
var Action = common.request.Action;
var Response = common.response.Response;

/**
 * Checks whether a status is successful.
 *
 * We define a successful status to be something within the 200 to 299 range.
 *
 * @param {number} status The status to check.
 */
function _isSuccessStatus(status) {
  // This constitutes a successfull status.
  return (status >= 200 && status <= 299);
};


function Resolver(spResolver) {
  if (!spResolver || typeof spResolver.resolve !== 'function') {
    throw TypeError('Incorrect resolver argument');
  }

  this._resolver = spResolver;
}

/**
 * The basic, generic method of sending the requests.
 *
 * For params description:
 * @borrows Resolver#_resolve as Resolver#resolve
 */
Resolver.prototype.resolve = function(request, callback) {
  return this._resolve(request, callback);
};

/**
 * Convenience method for doing GET requests.
 * resolver.get('sp://player') is an equivalent of
 * resolver.resolve(new Request('GET', 'sp://player')).
 *
 * @param {string|Object.<string, object>} options If is a string
 * will be parsed as url. If more data is needed, object notation
 * should be used.
 *  param options.url {string} The url of the request.
 *  param options.body {object=} The request body.
 *  param options.headers {object=} The request headers.
 * @param {function(error=, object?)} callback The function
 * executed after the request has been completed.
 *
 * @return {RequestHandler} The cancellable request handler.
 */
Resolver.prototype.get = function(options, callback) {
  return this._resolveFromParams(Action.GET, options, callback);
};

/**
 * Convenience method for doing POST requests.
 * resolver.post('sp://player') is an equivalent of
 * resolver.resolve(new Request('POST', 'sp://player'))
 *
 * @see Resolver#get for params description and returned value.
 */
Resolver.prototype.post = function(options, callback) {
  return this._resolveFromParams(Action.POST, options, callback);
};

/**
 * Convenience method for doing SUB requests.
 * resolver.subscribe('sp://player') is an equivalent of
 * resolver.resolve(new Request('SUB', 'sp://player'))
 *
 * @see Resolver#get for params description and returned value.
 */
Resolver.prototype.subscribe = function(options, callback) {
  return this._resolveFromParams(Action.SUB, options, callback);
};

/**
 * Convenience method for doing PUT requests.
 * resolver.put('sp://ads/v1/settings/session') is an equivalent of
 * resolver.resolve(new Request('PUT', 'sp://ads/v1/settings/session'))
 *
 * @see Resolver#get for params description and returned value.
 */
Resolver.prototype.put = function(options, callback) {
  return this._resolveFromParams(Action.PUT, options, callback);
};

/**
 * Convenience method for doing PATCH requests.
 * resolver.patch('sp://ads/v1/settings/session') is an equivalent of
 * resolver.resolve(new Request('PATCH', 'sp://ads/v1/settings/session'))
 *
 * @see Resolver#get for params description and returned value.
 */
Resolver.prototype.patch = function(options, callback) {
  return this._resolveFromParams(Action.PATCH, options, callback);
};

/**
 * Convenience method for doing DELETE requests.
 * resolver.delete('sp://player') is an equivalent of
 * resolver.resolve(new Request('DELETE', 'sp://player'))
 *
 * @see Resolver#get for params description and returned value.
 */
Resolver.prototype.delete = function(options, callback) {
  return this._resolveFromParams(Action.DELETE, options, callback);
};

/**
 * @private
 * Sends the request to the platform specific request resolver.
 * If the request action is 'SUB' it will send subscribe request
 * In any other case it will send simple resolve request.
 *
 * @param {Cosmos.Request} request A request object.
 * @param {function(error=, object?)} callback The function
 * executed after the request has been completed.
 *
 * @return {RequestHandler} The cancellable request handler.
 */
Resolver.prototype._resolve = function(request, callback) {
  if (!callback || typeof callback !== 'function') {
    callback = function() {};
  }

  var requestHandler;

  function onSuccess(serverResponse) {
    if (!requestHandler._request) {
      return;
    }

    var response = Response.fromObject(serverResponse);
    if (!response) {
      var error = new Error(
        'Failed to parse response: ' + JSON.stringify(serverResponse));
      return callback(error);
    }

    if (_isSuccessStatus(response.getStatusCode())) {
      return callback(null, response);
    } else {
      // Extract just the initial part of the request uri. It's good to have something
      // but it is also good to avoid having everything, since that can hurt dashboards
      // that group error messages.
      var requestEndpoint = request.toJSON().uri.match(/[^\:]*(\:\/\/)?[^\/]*/)[0];
      var errorMessage = (
        response.getHeader("error") ||
        "Request to " + requestEndpoint + " failed with status code " + response.getStatusCode());
      var error = new Error(errorMessage);
      error.response = response;
      return callback(error, response);
    }
  }

  function onError(serverResponse) {
    return callback(serverResponse instanceof Error ?
      serverResponse :
      new Error('Request failed: ' + JSON.stringify(serverResponse)));
  }

  var resolveFn = request.getAction() === Action.SUB ?
      this._resolver.subscribe : this._resolver.resolve;

  var clientRequest = resolveFn.call(this._resolver, request, onSuccess, onError);

  requestHandler = new RequestHandler(clientRequest);
  return requestHandler;
};

/**
 * @private
 * Creates Request object from supplied params.
 * @param {string} method Request method. One of the Request.Action.
 * @param {string|Object.<string, object>} options If is a string
 * will be parsed as url. If more data is needed, object notation
 * should be used.
 *  param options.url {string} The url of the request.
 *  param options.body {object=} The request body.
 *  param options.headers {object=} The request headers.
 * @param {function(error=, object?)} callback The function
 * executed after the request has been completed.
 *
 * @return {RequestHandler} The cancellable request handler.
 */
Resolver.prototype._resolveFromParams = function(method, options, callback) {
  options = options || {};

  var url = typeof options === 'string' ? options : options.url;
  var headers = options.headers;
  var body = options.body;

  var request = new Request(method, url, headers, body);

  return this._resolve(request, callback);
};

/**
 * The object that wraps the clientRequest
 * in a very simple interface.
 * Separates the implementation of the ClientRequest
 * from the request handler returned by Cosmos API.
 *
 * @param {Cosmos.ClientRequest} request The object
 * representing the newly opened request to the client.
 * Usually a request will be a subscription that
 * needs a close handler.
 */
function RequestHandler(request) {
  if (!request || typeof request.close !== 'function')
    throw new TypeError('Invalid `request` argument.');

  this._request = request;
}

/**
 * Closes the request and removes the object.
 */
RequestHandler.prototype.cancel = function() {
  if (this._request) {
    this._request.close();
    this._request = null;
  }
};

exports.Resolver = Resolver;

},{"cosmos-common-js":84}],115:[function(require,module,exports){
(function() {
  /**
   * @file
   * Introduces a function called "defer" that allows functions to be
   * executed in the next available tick.
   *
   * Unlike "setTimeout", "defer" executes the function at the nearest
   * possible time without clamping.
   *
   * @see Spotify.defer
   */
  'use strict';

  var hasWindow = typeof window != 'undefined';
  var hasDefineProperty = typeof Object.defineProperty == 'function';

  if (hasWindow && window.__modDefFn) {
    // If deferred has been attached to the global scope
    module.exports = window.__modDefFn;
    return;
  }

  /**
   * Storage for deferred functions to be executed.
   *
   * @type {Array.<function()>}
   * @private
   */
  var deferred = [];


  /**
   * A bound version of the postMessage routine used to trigger deferred
   * execution.
   *
   * @type {function()}
   * @private
   */
  var send;
  var origin;

  if (hasWindow && window.postMessage) {
    origin = (window.location.origin ||
          window.location.protocol + '//' + window.location.hostname);
    send = window.postMessage.bind(window, '@execute_deferreds', origin);
    if (!window.__hasDeferredHandler) {
      if (hasDefineProperty) {
        Object.defineProperty(window, '__hasDeferredHandler', {value: 1});
      } else {
        window.__hasDeferredHandler = 1;
      }
      var handler = function(e) {
        if (e.origin != origin && e.data != '@execute_deferreds') {
          return;
        }
        executeDeferreds();
      };
      if (window.addEventListener) {
        window.addEventListener('message', handler);
      } else {
        window.attachEvent('onmessage', handler);
      }
    }
  } else if (typeof setImmediate != 'undefined') {
    send = setImmediate.bind(null, executeDeferreds);
  } else {
    send = setTimeout.bind(null, executeDeferreds, 10);
  }


  /**
   * Executes the deferred functions when the window
   * receives an 'execute_deferreds' message.
   *
   * @private
   */
  function executeDeferreds() {
    var fns = deferred.splice(0);
    if (!fns.length) return;
    for (var i = 0, l = fns.length; i < l; i++) {
      try {
        fns[i]();
      } finally {
        // Do nothing.
        null;
      }
    }
  }


  /**
   * Executes the function applied at the nearest possible time without
   * clamping.
   *
   * @param {function()} fn The function to execute.
   */
  var defer = function(fn) {
    var trigger = !deferred.length;
    deferred.push(fn);
    if (trigger) send();
  };

  if (hasWindow && !window.__modDefFn) {
    if (hasDefineProperty) {
      Object.defineProperty(window, '__modDefFn', {value: defer});
    } else {
      window.__modDefFn = defer;
    }
  }

  /**
   * Export public interface
   */
  module.exports = defer;

})();

},{}],116:[function(require,module,exports){
'use strict';

/**
 * Function to add properties to an object
 * @param {Object} obj The input object
 * @param {Object} args The objects which are going to be injected
 * @return {Object} The extended object
 */
var extend = function(obj, args) {
  var source;

  for (var i = 1; i < arguments.length; i++) {
    source = arguments[i];
    if (source) {
      for (var prop in source) {
        if (source.hasOwnProperty(prop)) {
          obj[prop] = source[prop];
        }
      }
    }
  }
  return obj;
};


/**
 * Export public interface
 */
module.exports = extend;

},{}],117:[function(require,module,exports){
'use strict';

module.exports = {
  inherit: require('./inherit'),
  extend: require('./extend')
};

},{"./extend":116,"./inherit":118}],118:[function(require,module,exports){
'use strict';

/**
 * Makes a class inherit from a superclass' prototype indirectly.
 *
 * @param {Spotify.ClassLike} Sub The class that will inherit.
 * @param {Spotify.ClassLike} Super The class to inherit from.
 */
var inherit = function(Sub, Super) {
  var superProto = Super.prototype;
  function Superclass() {}
  Superclass.prototype = Sub._super = superProto;
  Superclass.prototype.constructor = Super;
  Sub.prototype = new Superclass();
};


/**
 * Export public interface
 */
module.exports = inherit;

},{}],119:[function(require,module,exports){
/**
 * @file
 * Unified window messaging facility.
 *
 * This module exports two functions to the Spotify
 * namespace which allows other subsystems to handle
 * particular types of messages sent through the native
 * window.postMessage method.
 *
 * @see Spotify.addMessageHandler
 * @see Spotify.removeMessageHandler
 */
'use strict';

var POST_ROUTER_ID = 'post-router-msg-' + new Date().getTime();

var hasStructuredClone = false;

var setImmediate = setImmediate ? setImmediate : setTimeout;

var CURRENT_WINDOW_ORIGIN = undefined;

if (typeof window !== 'undefined') {
  CURRENT_WINDOW_ORIGIN = (window.location.origin ||
      window.location.protocol + '//' + window.location.hostname);

  // Hacky solution to make it work for the webplayer.
  if (!window.__forceNoStructuredClone) {
    // Check if the platform has support for structured cloning.
    //
    // In platforms where this is supported, sending a postMessage with an
    // object that contains a function will throw an error, as it is not
    // cloneable.
    try {
      window.postMessage({
        toString: function() {
          return "clone-test";
        }
      }, CURRENT_WINDOW_ORIGIN);
      hasStructuredClone = false;
    } catch(e) {
      hasStructuredClone = true;
    }
  }
}

/**
 * Storage for message handlers.
 *
 * @type {Object.<string, Spotify.Shell.MessageHandler>}
 * @private
 */
var handlers = {};


/**
 * Variable to check if the window is already listening to postMessage events
 *
 * @type {bool}
 * @private
 */
var isListening = false;


function handleImmediateMessage(data) {
  var handler = handlers[data.type];
  if (!handler) return;
  handler.fn.call(this, data);
}


/**
 * Main event handler for the window message event.
 *
 * @param {Event} event The message event object.
 * @private
 */
function handlePostMessage(event) {
  var data = event.data;
  if (!hasStructuredClone) {
    if (typeof data == 'string') {
      try {
        data = JSON.parse(data);
      } catch (e) {
        return;
      }
    } else {
      // We only expect strings.
      return;
    }
  }
  if (event.origin == CURRENT_WINDOW_ORIGIN) {
    data = data[POST_ROUTER_ID];
    if (!data) {
      // Not our data, return immediately.
      return;
    }
  }
  var handler = handlers[data.type];
  if (!handler || handler.origin != '*' && event.origin !== handler.origin) {
    return;
  }
  handler.fn.call(this, data, event);
}

/**
 * Attaches the handlePostMessage function to PostMessage events
 *
 * @private
 */
var startListening = function() {
  if (window.attachEvent && !window.addEventListener) {
    // IE8 and Below
    window.attachEvent('onmessage', handlePostMessage);
  } else if (window.attachEvent && window.addEventListener) {
    // IE9
    window.addEventListener('message', handlePostMessage, false);
  } else if (window.addEventListener) {
    // Everyone else
    window.addEventListener('message', handlePostMessage, false);
  }
};


/**
 * Adds a message handler for a particular message type.
 *
 * The message handler function will be invoked when the window receives
 * a message marked as a particular type, receiving an argument. The
 * argument will be the data payload of the event decoded from JSON.
 *
 * @param {string} type The type of the message to handle.
 * @param {function} fn The handler function.
 * @param {string} origin needed
 * @throws {Error} Thrown if the message type being handled already has
 *     a handler function.
 */
var addMessageHandler = function(type, fn, origin) {
  if (typeof window !== 'undefined' && !isListening) {
    startListening();
    isListening = true;
  }

  if (!origin) {
    origin = CURRENT_WINDOW_ORIGIN;
  }

  if (handlers[type]) {
    throw new Error('Rehandling of message "' + type + '" not allowed.');
  }
  handlers[type] = {
    fn: fn,
    origin: origin
  };
  return;
};


/**
 * Removes a message handler for a particular message type.
 *
 * @param {string} type The type of the message to remove.
 * @param {Spotify.Shell.MessageHandler} fn The handler function.
 * @return {boolean} True if the handler function was succesfully removed.
 */
var removeMessageHandler = function(type, fn) {
  if (handlers[type] && (!fn || handlers[type].fn === fn)) {
    handlers[type] = null;
    return true;
  }
  return false;
};


/**
 * Sends a message to the event handler
 *
 * @param {string} type The type of the message to remove.
 * @param {Object} data JSON object to pass to the handler
 */
var sendMessage = function(type, data, destWindow, origin) {
  data = data || {};
  data.type = type;

  if (typeof window === 'undefined') {
    return setImmediate(handleImmediateMessage.bind(null, data));
  }

  destWindow = destWindow || window;

  if (!origin) {
    origin = CURRENT_WINDOW_ORIGIN;
  }

  destWindow.postMessage(JSON.stringify(data), origin);
};

var sendLocalMessage = function(type, data) {
  data = data || {};
  data.type = type;

  if (typeof window === 'undefined') {
    return setImmediate(handleImmediateMessage.bind(null, data));
  }

  // Wrap the data in a custom object to quickly identify the message.
  var wrapper = {};
  wrapper[POST_ROUTER_ID] = data;

  window.postMessage(hasStructuredClone ?
                     wrapper :
                     JSON.stringify(wrapper), CURRENT_WINDOW_ORIGIN);
};


/**
 * Export public interface
 */
module.exports = {
  addMessageHandler: addMessageHandler,
  removeMessageHandler: removeMessageHandler,
  sendMessage: sendMessage,
  sendLocalMessage: sendLocalMessage,
  WINDOW_ORIGIN: CURRENT_WINDOW_ORIGIN
};

},{}]},{},[23]);
